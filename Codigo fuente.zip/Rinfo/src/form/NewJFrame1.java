/*    */ package form;
/*    */ 
/*    */ import java.awt.EventQueue;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ import javax.swing.GroupLayout;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.UnsupportedLookAndFeelException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NewJFrame1
/*    */   extends JFrame
/*    */ {
/*    */   public NewJFrame1() {
/* 19 */     initComponents();
/*    */   }
/*    */   
/*    */   private void initComponents() {
/* 23 */     setDefaultCloseOperation(3);
/* 24 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 25 */     getContentPane().setLayout(layout);
/* 26 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 400, 32767));
/* 27 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 300, 32767));
/* 28 */     pack();
/*    */   }
/*    */   
/*    */   public static void main(String[] args) {
/*    */     try {
/* 33 */       for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
/* 34 */         if ("Nimbus".equals(info.getName())) {
/* 35 */           UIManager.setLookAndFeel(info.getClassName());
/*    */           
/*    */           break;
/*    */         } 
/*    */       } 
/* 40 */     } catch (ClassNotFoundException ex) {
/* 41 */       Logger.getLogger(NewJFrame1.class.getName()).log(Level.SEVERE, (String)null, ex);
/*    */     }
/* 43 */     catch (InstantiationException ex2) {
/* 44 */       Logger.getLogger(NewJFrame1.class.getName()).log(Level.SEVERE, (String)null, ex2);
/*    */     }
/* 46 */     catch (IllegalAccessException ex3) {
/* 47 */       Logger.getLogger(NewJFrame1.class.getName()).log(Level.SEVERE, (String)null, ex3);
/*    */     }
/* 49 */     catch (UnsupportedLookAndFeelException ex4) {
/* 50 */       Logger.getLogger(NewJFrame1.class.getName()).log(Level.SEVERE, (String)null, ex4);
/*    */     } 
/* 52 */     EventQueue.invokeLater(new Runnable()
/*    */         {
/*    */           public void run() {
/* 55 */             (new NewJFrame1()).setVisible(true);
/*    */           }
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\NewJFrame1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */