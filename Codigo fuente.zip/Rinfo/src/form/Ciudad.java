/*     */ package form;
/*     */ 
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyChangeSupport;
/*     */ import java.util.ArrayList;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.JOptionPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Ciudad
/*     */ {
/*     */   MonitorActualizarVentana esperarRefresco;
/*     */   boolean ok;
/*     */   private int numAv;
/*     */   private int numCa;
/*     */   public int cantidad_robots;
/*     */   public Bolsa[][] ciudad;
/*     */   ArrayList<Robot> robots;
/*     */   ArrayList<Area> areas;
/*     */   ArrayList<Thread> hilos;
/*     */   private final PropertyChangeSupport pcs;
/*     */   Main form;
/*     */   
/*     */   public Ciudad(Main city) throws Exception {
/*  30 */     this.esperarRefresco = MonitorActualizarVentana.getInstance();
/*  31 */     this.cantidad_robots = 1;
/*  32 */     this.ciudad = new Bolsa[101][101];
/*  33 */     this.robots = new ArrayList<>();
/*  34 */     this.areas = new ArrayList<>();
/*  35 */     this.hilos = new ArrayList<>();
/*  36 */     this.pcs = new PropertyChangeSupport(this);
/*  37 */     setNumAv(100);
/*  38 */     setNumCa(100);
/*  39 */     for (int i = 0; i < this.ciudad.length; i++) {
/*  40 */       for (int j = 0; j < (this.ciudad[0]).length; j++) {
/*  41 */         this.ciudad[i][j] = new Bolsa();
/*     */       }
/*     */     } 
/*  44 */     this.form = city;
/*  45 */     this.ok = false;
/*     */   }
/*     */   
/*     */   public void agregarHilo(Thread t) {
/*  49 */     this.hilos.add(t);
/*     */   }
/*     */   
/*     */   public void setNumAv(int num) {
/*  53 */     this.numAv = num;
/*     */   }
/*     */   
/*     */   public void setNumCa(int num) {
/*  57 */     this.numCa = num;
/*     */   }
/*     */   
/*     */   public int getNumAv() {
/*  61 */     return this.numAv;
/*     */   }
/*     */   
/*     */   public int getNumCa() {
/*  65 */     return this.numCa;
/*     */   }
/*     */   
/*     */   public boolean getOk() {
/*  69 */     return this.ok;
/*     */   }
/*     */   
/*     */   public void setOk(boolean ok) {
/*  73 */     this.ok = ok;
/*     */   }
/*     */   
/*     */   public int getCantidad_robots() {
/*  77 */     return this.cantidad_robots;
/*     */   }
/*     */   
/*     */   public void setCantidad_robots(int cantidad_robots) {
/*  81 */     this.cantidad_robots = cantidad_robots;
/*     */   }
/*     */   
/*     */   public boolean isFreePos(int ca, int av) throws Exception {
/*  85 */     if (ca < 1 || ca > getNumCa()) {
/*  86 */       parseError("No se puede ejecutar la instrucción \"mover\" debido a que el robot se caería de la ciudad");
/*  87 */       throw new Exception("No se puede ejecutar la instrucción \"mover\" debido a que el robot se caería de la ciudad");
/*     */     } 
/*  89 */     if (av < 1 || av > getNumAv()) {
/*  90 */       parseError("No se puede ejecutar la instrucción \"mover\" debido a que el robot se caería de la ciudad");
/*  91 */       throw new Exception("No se puede ejecutar la instrucción \"mover\" debido a que hay un obstáculo");
/*     */     } 
/*  93 */     return !this.ciudad[av][ca].getObstaculo();
/*     */   }
/*     */   
/*     */   public boolean isFreePosRobot(int ca, int av) {
/*  97 */     return this.ciudad[av][ca].isOcupado();
/*     */   }
/*     */   
/*     */   public boolean levantarFlor(int Av, int Ca) {
/* 101 */     boolean res = true;
/* 102 */     if (HayFlorEnLaEsquina(Av, Ca)) {
/* 103 */       this.ciudad[Av][Ca].setFlores(this.ciudad[Av][Ca].getFlores() - 1);
/*     */     } else {
/*     */       
/* 106 */       res = false;
/* 107 */       JOptionPane.showMessageDialog(null, "Run Time Error: No se puede ejecutar la instrucción \"tomarFlor\" debido a que no hay ninguna flor en la esquina ", "error", 0);
/*     */     } 
/* 109 */     this.form.jsp.refresh();
/* 110 */     return res;
/*     */   }
/*     */   
/*     */   public boolean HayFlorEnLaEsquina(int Av, int Ca) {
/* 114 */     return (getFlores(Av, Ca) > 0);
/*     */   }
/*     */   
/*     */   public boolean HayObstaculoEnLaEsquina(int Av, int Ca) throws Exception {
/* 118 */     switch (((Robot)this.robots.get(0)).getDireccion()) {
/*     */       case 0:
/* 120 */         return (Av < 100 && this.ciudad[Av + 1][Ca].getObstaculo());
/*     */       
/*     */       case 180:
/* 123 */         return (Av > 1 && this.ciudad[Av - 1][Ca].getObstaculo());
/*     */       
/*     */       case 90:
/* 126 */         return (Ca < 100 && this.ciudad[Av][Ca + 1].getObstaculo());
/*     */       
/*     */       case 270:
/* 129 */         return (Ca > 1 && this.ciudad[Av][Ca - 1].getObstaculo());
/*     */     } 
/*     */     
/* 132 */     System.out.println("Fallo en la direccion de Ciudad");
/* 133 */     throw new Exception("Fallo en la direccion de Ciudad");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFlores(int Av, int Ca) {
/* 139 */     return this.ciudad[Av][Ca].getFlores();
/*     */   }
/*     */   
/*     */   public boolean HayPapelEnLaEsquina(int Av, int Ca) {
/* 143 */     return (getPapeles(Av, Ca) > 0);
/*     */   }
/*     */   
/*     */   public int getPapeles(int Av, int Ca) {
/* 147 */     return this.ciudad[Av][Ca].getPapeles();
/*     */   }
/*     */   
/*     */   public boolean levantarPapel(int Av, int Ca) {
/* 151 */     boolean res = true;
/* 152 */     if (HayPapelEnLaEsquina(Av, Ca)) {
/* 153 */       this.ciudad[Av][Ca].setPapeles(this.ciudad[Av][Ca].getPapeles() - 1);
/*     */     } else {
/*     */       
/* 156 */       res = false;
/* 157 */       JOptionPane.showMessageDialog(null, "Run Time Error: No se puede ejecutar la instrucción \"tomarPapel\" debido a que no hay ningun papel en la esquina", "error", 0);
/*     */     } 
/* 159 */     this.form.jsp.refresh();
/* 160 */     return res;
/*     */   }
/*     */   
/*     */   public void dejarPapel(int Av, int Ca) {
/* 164 */     int old = getPapeles(Av, Ca);
/* 165 */     this.ciudad[Av][Ca].setPapeles(old + 1);
/* 166 */     this.pcs.firePropertyChange("EsquinaPapeles", old, getPapeles(Av, Ca));
/* 167 */     this.form.jsp.refresh();
/*     */   }
/*     */   
/*     */   public void dejarFlor(int Av, int Ca) {
/* 171 */     int old = getFlores(Av, Ca);
/* 172 */     this.ciudad[Av][Ca].setFlores(old + 1);
/* 173 */     this.pcs.firePropertyChange("EsquinaFlores", old, getFlores(Av, Ca));
/* 174 */     this.form.jsp.refresh();
/*     */   }
/*     */   
/*     */   public void parseError(String msg) {
/* 178 */     JOptionPane.showMessageDialog(null, "Run Time Error: " + msg, "error", 0);
/*     */   }
/*     */   
/*     */   public void addRobot(String name) {
/*     */     try {
/* 183 */       int old = this.robots.size();
/* 184 */       this.robots.add(new Robot(this, name));
/* 185 */       this.esperarRefresco.setCant_robots(this.robots.size());
/* 186 */       this.esperarRefresco.setCant_ejecutandose(this.robots.size());
/* 187 */       this.pcs.firePropertyChange("numRobots", old, this.robots.size());
/*     */     }
/* 189 */     catch (Exception ex) {
/* 190 */       Logger.getLogger(Ciudad.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean estaRobot(String str) {
/* 195 */     boolean ok = false;
/* 196 */     for (int cant = this.robots.size(), i = 0; i < cant; i++) {
/* 197 */       if (((Robot)this.robots.get(i)).nombre.equals(str)) {
/* 198 */         ok = true;
/*     */       }
/*     */     } 
/* 201 */     return ok;
/*     */   }
/*     */   
/*     */   public boolean estaRobotConId(int id) {
/* 205 */     boolean ok = false;
/* 206 */     for (int cant = this.robots.size(), i = 0; i < cant; i++) {
/* 207 */       if (((Robot)this.robots.get(i)).getId() == id) {
/* 208 */         ok = true;
/*     */       }
/*     */     } 
/* 211 */     return ok;
/*     */   }
/*     */   
/*     */   public Robot getRobotByNombre(String str) throws Exception {
/* 215 */     for (int cant = this.robots.size(), i = 0; i < cant; i++) {
/* 216 */       if (((Robot)this.robots.get(i)).getNombre().equals(str)) {
/* 217 */         return this.robots.get(i);
/*     */       }
/*     */     } 
/* 220 */     parseError("El robot " + str + " no se encuentra en la ciudad");
/* 221 */     throw new Exception("El robot " + str + " no se encuentra en la ciudad");
/*     */   }
/*     */   
/*     */   public Robot getRobotById(int id) throws Exception {
/* 225 */     for (int cant = this.robots.size(), i = 0; i < cant; i++) {
/* 226 */       if (((Robot)this.robots.get(i)).getId() == id) {
/* 227 */         return this.robots.get(i);
/*     */       }
/*     */     } 
/* 230 */     throw new Exception("El robot con id " + id + " no se encuentra en la ciudad");
/*     */   }
/*     */   
/*     */   public Area getAreaByNombre(String str) throws Exception {
/* 234 */     for (int cant = this.areas.size(), i = 0; i < cant; i++) {
/* 235 */       if (((Area)this.areas.get(i)).getName().equals(str)) {
/* 236 */         return this.areas.get(i);
/*     */       }
/*     */     } 
/* 239 */     throw new Exception("El area " + str + " no se encuentra declarada");
/*     */   }
/*     */   
/*     */   public void Informar(String args, int id) {
/* 243 */     this.form.mostrarMensaje(args, "Informar", 1);
/*     */   }
/*     */   
/*     */   public void addPropertyChangeListener(PropertyChangeListener listener) {
/* 247 */     this.pcs.addPropertyChangeListener(listener);
/*     */   }
/*     */   
/*     */   public void removePropertyChangeListener(PropertyChangeListener listener) {
/* 251 */     this.pcs.removePropertyChangeListener(listener);
/*     */   }
/*     */   
/*     */   public boolean HayObstaculo(int Av, int Ca) throws Exception {
/* 255 */     return this.ciudad[Av][Ca].getObstaculo();
/*     */   }
/*     */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\Ciudad.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */