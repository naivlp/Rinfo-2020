/*     */ package form;
/*     */ 
/*     */ import arbol.Identificador;
/*     */ import java.util.ArrayList;
/*     */ import java.util.concurrent.locks.Condition;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MonitorMensajes
/*     */ {
/*     */   public ArrayList<Dato> datos;
/*     */   private static MonitorMensajes instance;
/*     */   private final ReentrantLock lock;
/*     */   final Condition condicion;
/*     */   final Condition pause;
/*     */   private int cant_robots;
/*     */   private boolean en_ejecucion;
/*     */   private boolean[] resultado;
/*     */   final Condition[] espera;
/*     */   final Condition esperaCualquiera;
/*     */   private boolean apretoF7;
/*     */   final Condition barrera;
/*     */   private boolean pasoAPaso;
/*     */   private int bar;
/*     */   private int cant_ejecutandose;
/*     */   private boolean timerOn;
/*     */   private int time;
/*     */   private boolean sistemaPausado;
/*     */   public Robot r;
/*     */   
/*     */   private MonitorMensajes(int cant, Robot r) {
/*  36 */     this.lock = new ReentrantLock();
/*  37 */     this.condicion = this.lock.newCondition();
/*  38 */     this.pause = this.lock.newCondition();
/*  39 */     this.cant_robots = 0;
/*  40 */     this.en_ejecucion = false;
/*  41 */     this.esperaCualquiera = this.lock.newCondition();
/*  42 */     this.apretoF7 = false;
/*  43 */     this.barrera = this.lock.newCondition();
/*  44 */     this.pasoAPaso = false;
/*  45 */     this.bar = 0;
/*  46 */     this.cant_ejecutandose = 0;
/*  47 */     this.timerOn = false;
/*  48 */     this.time = 50;
/*  49 */     this.sistemaPausado = false;
/*  50 */     this.r = r;
/*  51 */     this.datos = new ArrayList<>();
/*  52 */     this.espera = new Condition[cant];
/*  53 */     this.resultado = new boolean[cant];
/*  54 */     for (int i = 0; i < cant; i++) {
/*  55 */       this.espera[i] = this.lock.newCondition();
/*  56 */       this.resultado[i] = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void waitAgain() {
/*     */     try {
/*  62 */       Thread.sleep(this.time);
/*     */     }
/*  64 */     catch (InterruptedException interruptedException) {}
/*  65 */     if (!this.sistemaPausado) {
/*  66 */       despertar();
/*     */     }
/*  68 */     if (this.timerOn) {
/*  69 */       waitAgain();
/*     */     }
/*     */   }
/*     */   
/*     */   public static MonitorMensajes getInstance() {
/*  74 */     return instance;
/*     */   }
/*     */   
/*     */   public static MonitorMensajes crearMonitorActualizarVentana(int cantidadClientes, Robot r) {
/*  78 */     return instance = new MonitorMensajes(cantidadClientes, r);
/*     */   }
/*     */   
/*     */   public void recibirMensaje(Identificador nombreVariable, int id, Identificador NombreRobot) throws Exception {
/*  82 */     this.lock.lock();
/*     */     try {
/*  84 */       if (estaNombreRobotEnDatos(NombreRobot.toString())) {
/*  85 */         String valor = getValorByNombreRobot(NombreRobot.toString());
/*  86 */         getRobot().getVariables().findByName(nombreVariable.toString()).setValue(valor);
/*     */       }
/*  88 */       else if (NombreRobot.toString().equals("*")) {
/*  89 */         String str = getValorByComodin();
/*  90 */         if (str == null) {
/*  91 */           (getRobot()).esperarRefresco.esperaMensaje();
/*  92 */           System.out.println("Me duermo");
/*  93 */           this.esperaCualquiera.await();
/*  94 */           System.out.println("Me despierto");
/*  95 */           str = getValorByComodin();
/*  96 */           getRobot().getVariables().findByName(nombreVariable.toString()).setValue(str);
/*  97 */           int x = (getRobot()).esperarRefresco.getCant_ejecutandose();
/*  98 */           (getRobot()).esperarRefresco.setCant_ejecutandose(x + 1);
/*  99 */           (getRobot()).esperarRefresco.setDormidos((getRobot()).esperarRefresco.getDormidos() - 1);
/*     */         } else {
/*     */           
/* 102 */           getRobot().getVariables().findByName(nombreVariable.toString()).setValue(str);
/*     */         } 
/*     */       } else {
/*     */         
/* 106 */         (getRobot()).esperarRefresco.esperaMensaje();
/* 107 */         this.espera[id].await();
/* 108 */         if (estaNombreRobotEnDatos(NombreRobot.toString())) {
/* 109 */           String valor = getValorByNombreRobot(NombreRobot.toString());
/* 110 */           getRobot().getVariables().findByName(nombreVariable.toString()).setValue(valor);
/* 111 */           int x = (getRobot()).esperarRefresco.getCant_ejecutandose();
/* 112 */           (getRobot()).esperarRefresco.setCant_ejecutandose(x + 1);
/* 113 */           (getRobot()).esperarRefresco.setDormidos((getRobot()).esperarRefresco.getDormidos() - 1);
/*     */         }
/*     */       
/*     */       } 
/* 117 */     } catch (InterruptedException e) {
/* 118 */       System.out.println("Interrupted Exc ");
/* 119 */       throw new RuntimeException();
/*     */     } finally {
/*     */       
/* 122 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getValorByNombreRobot(String nombre) {
/* 127 */     int i = getIndexByNombreRobot(nombre);
/* 128 */     String valor = ((Dato)this.datos.get(i)).valor;
/* 129 */     this.datos.remove(i);
/* 130 */     return valor;
/*     */   }
/*     */   
/*     */   private String getValorByComodin() throws InterruptedException {
/* 134 */     String valor = null;
/* 135 */     int i = 0;
/* 136 */     if (0 < this.datos.size()) {
/* 137 */       valor = ((Dato)this.datos.get(0)).valor;
/* 138 */       this.datos.remove(0);
/*     */     } 
/* 140 */     return valor;
/*     */   }
/*     */   
/*     */   private int getIndexByNombreRobot(String nombre) {
/* 144 */     int i = 0;
/* 145 */     for (Dato d : this.datos) {
/* 146 */       if (d.NombreRobot.equals(nombre)) {
/* 147 */         return i;
/*     */       }
/* 149 */       i++;
/*     */     } 
/* 151 */     System.out.println("Algo anda mal en getIndexByNombreRobot");
/* 152 */     return i;
/*     */   }
/*     */   
/*     */   public void llegoMensaje(int id, Dato d) {
/* 156 */     this.lock.lock();
/*     */     try {
/* 158 */       this.datos.add(d);
/* 159 */       this.espera[id].signal();
/* 160 */       this.esperaCualquiera.signal();
/*     */     } finally {
/*     */       
/* 163 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean estaNombreRobotEnDatos(String nombre) {
/* 168 */     boolean ok = false;
/* 169 */     for (Dato d : this.datos) {
/* 170 */       if (d.NombreRobot.equals(nombre)) {
/* 171 */         ok = true;
/*     */       }
/*     */     } 
/* 174 */     return ok;
/*     */   }
/*     */   
/*     */   public Robot getRobot() {
/* 178 */     return this.r;
/*     */   }
/*     */   
/*     */   public void dormir() {
/* 182 */     this.lock.lock();
/*     */     try {
/* 184 */       this.pause.await();
/*     */     }
/* 186 */     catch (InterruptedException e) {
/* 187 */       System.out.println("Interrupted Exc ");
/* 188 */       throw new RuntimeException();
/*     */     } finally {
/*     */       
/* 191 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void arrancar() {
/* 196 */     this.lock.lock();
/*     */     try {
/* 198 */       this.pause.signal();
/*     */     } finally {
/*     */       
/* 201 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void despertar() {
/* 206 */     this.lock.lock();
/*     */     try {
/* 208 */       this.apretoF7 = true;
/* 209 */       for (int i = 0; i < this.cant_robots; i++) {
/* 210 */         this.espera[i].signal();
/*     */       }
/*     */     } finally {
/*     */       
/* 214 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void despertarPause() {
/* 219 */     this.lock.lock();
/*     */     try {
/* 221 */       this.sistemaPausado = false;
/*     */     } finally {
/*     */       
/* 224 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\MonitorMensajes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */