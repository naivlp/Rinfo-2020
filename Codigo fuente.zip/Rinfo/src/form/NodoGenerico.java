/*    */ package form;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NodoGenerico<T>
/*    */ {
/*    */   private T dato;
/*    */   private NodoGenerico<T> siguiente;
/*    */   
/*    */   public T getDato() {
/* 13 */     return this.dato;
/*    */   }
/*    */   
/*    */   public void setDato(T dato) {
/* 17 */     this.dato = dato;
/*    */   }
/*    */   
/*    */   public NodoGenerico<T> getSiguiente() {
/* 21 */     return this.siguiente;
/*    */   }
/*    */   
/*    */   public void setSiguiente(NodoGenerico<T> siguiente) {
/* 25 */     this.siguiente = siguiente;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\NodoGenerico.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */