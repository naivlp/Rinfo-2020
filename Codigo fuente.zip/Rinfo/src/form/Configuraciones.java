/*     */ package form;
/*     */ 
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.KeyListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.border.TitledBorder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Configuraciones
/*     */   extends JPanel
/*     */ {
/*     */   Ciudad city;
/*     */   JButton bot1;
/*     */   JButton bot2;
/*     */   JButton bot3;
/*     */   JButton bot4;
/*     */   JComboBox com;
/*     */   JComboBox com1;
/*     */   JComboBox com2;
/*     */   JTextField jf1;
/*     */   JTextField jf2;
/*     */   public JTextField jf3;
/*     */   JLabel lab1;
/*     */   JLabel lab2;
/*     */   JLabel lab3;
/*     */   JLabel lab4;
/*     */   JLabel lab5;
/*     */   JLabel lab6;
/*     */   GridBagConstraints gbc;
/*     */   JPanel JP;
/*     */   private int limite;
/*     */   
/*     */   Configuraciones(Ciudad city) {
/*  52 */     this.bot1 = new JButton("Agregar");
/*  53 */     this.bot2 = new JButton("OK");
/*  54 */     this.bot3 = new JButton("OK");
/*  55 */     this.bot4 = new JButton("Agregar");
/*  56 */     this.com = new JComboBox();
/*  57 */     this.com1 = new JComboBox();
/*  58 */     this.com2 = new JComboBox();
/*  59 */     this.jf1 = new JTextField(3);
/*  60 */     this.jf2 = new JTextField(3);
/*  61 */     this.jf3 = new JTextField(3);
/*  62 */     this.lab1 = new JLabel("Avenida: ");
/*  63 */     this.lab2 = new JLabel("Calle:   ");
/*  64 */     this.lab3 = new JLabel("Elemento:      ");
/*  65 */     this.lab4 = new JLabel("Bolsa de Flores ");
/*  66 */     this.lab5 = new JLabel("Bolsa de Papeles  ");
/*  67 */     this.lab6 = new JLabel("Cantidad:    ");
/*  68 */     this.gbc = new GridBagConstraints();
/*  69 */     this.limite = 4;
/*  70 */     this.jf3.addKeyListener(new KeyListener()
/*     */         {
/*     */           public void keyTyped(KeyEvent e) {
/*  73 */             if (Configuraciones.this.jf3.getText().length() == Configuraciones.this.limite) {
/*  74 */               e.consume();
/*     */             }
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public void keyPressed(KeyEvent arg0) {}
/*     */ 
/*     */ 
/*     */           
/*     */           public void keyReleased(KeyEvent arg0) {}
/*     */         });
/*  86 */     TitledBorder ti = new TitledBorder("Configuraciones");
/*  87 */     this.city = city;
/*  88 */     this.jf1.setText("0");
/*  89 */     this.jf2.setText("0");
/*  90 */     this.jf3.setText("0");
/*  91 */     this.jf3.addKeyListener(new KeyAdapter()
/*     */         {
/*     */           public void keyTyped(KeyEvent e) {
/*  94 */             char c = e.getKeyChar();
/*  95 */             if (!Character.isDigit(c) && c != '\b' && c != '') {
/*  96 */               Configuraciones.this.getToolkit().beep();
/*  97 */               e.consume();
/*     */             } 
/*     */           }
/*     */         });
/* 101 */     setLayout(new GridBagLayout());
/* 102 */     this.com.setModel(new DefaultComboBoxModel<>(new String[] { "Flores", "Papeles", "Obstaculos" }));
/* 103 */     this.com2.setModel(new DefaultComboBoxModel<>(new String[] { "*", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "100" }));
/* 104 */     this.com1.setModel(new DefaultComboBoxModel<>(new String[] { "*", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "100" }));
/* 105 */     this.gbc.anchor = 17;
/* 106 */     this.gbc.insets = new Insets(2, 10, 0, 0);
/* 107 */     this.gbc.gridx = 0;
/* 108 */     this.gbc.gridy = 0;
/* 109 */     add(this.lab3, this.gbc);
/* 110 */     this.gbc.gridx = 1;
/* 111 */     this.gbc.gridy = 0;
/* 112 */     add(this.lab1, this.gbc);
/* 113 */     this.gbc.gridx = 2;
/* 114 */     this.gbc.gridy = 0;
/* 115 */     add(this.lab2, this.gbc);
/* 116 */     this.gbc.gridx = 0;
/* 117 */     this.gbc.gridy = 1;
/* 118 */     add(this.com, this.gbc);
/* 119 */     this.gbc.gridx = 1;
/* 120 */     this.gbc.gridy = 1;
/* 121 */     add(this.com1, this.gbc);
/* 122 */     this.gbc.gridx = 2;
/* 123 */     this.gbc.gridy = 1;
/* 124 */     add(this.com2, this.gbc);
/* 125 */     this.gbc.gridx = 0;
/* 126 */     this.gbc.gridy = 2;
/* 127 */     add(this.lab6, this.gbc);
/* 128 */     this.gbc.gridx = 0;
/* 129 */     this.gbc.gridy = 3;
/* 130 */     this.gbc.gridwidth = 1;
/* 131 */     this.gbc.fill = 1;
/* 132 */     add(this.jf3, this.gbc);
/* 133 */     this.gbc.gridwidth = 0;
/* 134 */     this.gbc.fill = 0;
/* 135 */     this.gbc.gridx = 1;
/* 136 */     this.gbc.gridy = 3;
/* 137 */     this.gbc.weighty = 1.0D;
/* 138 */     this.gbc.gridheight = 1;
/* 139 */     this.gbc.weightx = 1.0D;
/* 140 */     add(this.bot4, this.gbc);
/* 141 */     this.gbc.fill = 2;
/* 142 */     this.gbc.gridx = 0;
/* 143 */     this.gbc.gridy = 4;
/* 144 */     (this.JP = new TablaRobot(this.city)).setBorder(new TitledBorder("ROBOTS"));
/* 145 */     add(this.JP, this.gbc);
/* 146 */     revalidate();
/* 147 */     this.bot4.addMouseListener(new MouseAdapter()
/*     */         {
/*     */           public void mouseClicked(MouseEvent evt) {
/* 150 */             Configuraciones.this.jButton4MouseClicked(evt);
/*     */           }
/*     */         });
/* 153 */     this.bot2.addMouseListener(new MouseAdapter()
/*     */         {
/*     */           public void mouseClicked(MouseEvent evt) {
/* 156 */             Configuraciones.this.jtest(evt);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private void jtest(MouseEvent evt) {}
/*     */   
/*     */   private void jButton4MouseClicked(MouseEvent evt) {
/* 165 */     int x1 = this.com1.getSelectedIndex();
/* 166 */     int x2 = this.com2.getSelectedIndex();
/* 167 */     int aux = Integer.parseInt(this.jf3.getText());
/* 168 */     if (aux > 0) {
/* 169 */       for (int i = 0; i < aux; i++) {
/*     */         int aux2; int aux3;
/* 171 */         if (x1 == 0) {
/* 172 */           aux2 = (int)(Math.random() * 100.0D) + 1;
/*     */         } else {
/*     */           
/* 175 */           aux2 = this.com1.getSelectedIndex();
/*     */         } 
/*     */         
/* 178 */         if (x2 == 0) {
/* 179 */           aux3 = (int)(Math.random() * 100.0D) + 1;
/*     */         } else {
/*     */           
/* 182 */           aux3 = this.com2.getSelectedIndex();
/*     */         } 
/* 184 */         if (this.com.getSelectedItem().toString().equals("Flores") && x1 == 0 && x2 == 0) {
/* 185 */           this.city.ciudad[aux2][aux3].setFlores(this.city.ciudad[aux2][aux3].getFlores() + 1);
/*     */         }
/* 187 */         else if (this.com.getSelectedItem().toString().equals("Flores") && x1 != 0 && x2 != 0) {
/* 188 */           this.city.ciudad[aux2][aux3].setFlores(aux);
/*     */         }
/* 190 */         else if (this.com.getSelectedItem().toString().equals("Flores")) {
/* 191 */           this.city.ciudad[aux2][aux3].setFlores(this.city.ciudad[aux2][aux3].getFlores() + 1);
/*     */         } 
/* 193 */         if (this.com.getSelectedItem().toString().equals("Papeles") && x1 == 0 && x2 == 0) {
/* 194 */           this.city.ciudad[aux2][aux3].setPapeles(this.city.ciudad[aux2][aux3].getPapeles() + 1);
/*     */         }
/* 196 */         else if (this.com.getSelectedItem().toString().equals("Papeles") && x1 != 0 && x2 != 0) {
/* 197 */           this.city.ciudad[aux2][aux3].setPapeles(aux);
/*     */         }
/* 199 */         else if (this.com.getSelectedItem().toString().equals("Papeles")) {
/* 200 */           this.city.ciudad[aux2][aux3].setPapeles(this.city.ciudad[aux2][aux3].getPapeles() + 1);
/*     */         } 
/* 202 */         if (this.com.getSelectedItem().toString().equals("Obstaculos")) {
/* 203 */           this.city.ciudad[aux2][aux3].setObstaculo(true);
/*     */         }
/*     */       } 
/*     */     }
/* 207 */     this.city.form.jsp.refresh();
/*     */   }
/*     */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\Configuraciones.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */