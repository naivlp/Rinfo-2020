/*     */ package form;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListaEnlazadaGenerica<T>
/*     */   extends ListaGenerica<T>
/*     */ {
/*     */   private NodoGenerico<T> inicio;
/*     */   private NodoGenerico<T> actual;
/*     */   
/*     */   public void comenzar() {
/*  14 */     this.actual = this.inicio;
/*     */   }
/*     */ 
/*     */   
/*     */   public void proximo() {
/*  19 */     this.actual = this.actual.getSiguiente();
/*     */   }
/*     */ 
/*     */   
/*     */   public T elemento() {
/*  24 */     return this.actual.getDato();
/*     */   }
/*     */ 
/*     */   
/*     */   public T elemento(int pos) {
/*  29 */     comenzar();
/*  30 */     while (pos-- > 0) {
/*  31 */       proximo();
/*     */     }
/*  33 */     return this.actual.getDato();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean agregar(T elem, int pos) {
/*  38 */     if (pos < 0 || pos > tamanio()) {
/*  39 */       return false;
/*     */     }
/*  41 */     this.tamanio++;
/*  42 */     NodoGenerico<T> aux = new NodoGenerico<>();
/*  43 */     aux.setDato(elem);
/*  44 */     if (pos == 0) {
/*  45 */       aux.setSiguiente(this.inicio);
/*  46 */       this.inicio = aux;
/*     */     } else {
/*     */       
/*  49 */       comenzar();
/*  50 */       while (--pos > 0) {
/*  51 */         proximo();
/*     */       }
/*  53 */       aux.setSiguiente(this.actual.getSiguiente());
/*  54 */       this.actual.setSiguiente(aux);
/*     */     } 
/*  56 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean eliminar() {
/*  61 */     if (this.actual == null) {
/*  62 */       return false;
/*     */     }
/*  64 */     this.tamanio--;
/*  65 */     if (this.actual == this.inicio) {
/*  66 */       this.inicio = this.inicio.getSiguiente();
/*  67 */       return true;
/*     */     } 
/*     */     NodoGenerico<T> p;
/*  70 */     for (p = this.inicio; p.getSiguiente() != this.actual; p = p.getSiguiente());
/*  71 */     p.setSiguiente(this.actual.getSiguiente());
/*  72 */     this.actual = p.getSiguiente();
/*  73 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean eliminar(int pos) {
/*  78 */     if (pos < 0 || pos >= tamanio()) {
/*  79 */       return false;
/*     */     }
/*  81 */     this.tamanio--;
/*  82 */     if (pos == 0) {
/*  83 */       this.inicio = this.inicio.getSiguiente();
/*  84 */       return true;
/*     */     } 
/*  86 */     comenzar();
/*  87 */     while (--pos > 0) {
/*  88 */       proximo();
/*     */     }
/*  90 */     this.actual.setSiguiente(this.actual.getSiguiente().getSiguiente());
/*  91 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean incluye(T elem) {
/*  96 */     comenzar();
/*  97 */     while (!fin() && !elemento().equals(elem)) {
/*  98 */       proximo();
/*     */     }
/* 100 */     return !fin();
/*     */   }
/*     */ 
/*     */   
/*     */   public int tamanio() {
/* 105 */     return this.tamanio;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean fin() {
/* 110 */     return (this.actual == null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean esVacia() {
/* 115 */     return (tamanio() == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean agregar(T elem) {
/* 120 */     if (this.actual == null && tamanio() > 0) {
/* 121 */       return false;
/*     */     }
/* 123 */     this.tamanio++;
/* 124 */     NodoGenerico<T> aux = new NodoGenerico<>();
/* 125 */     if (this.actual == this.inicio) {
/* 126 */       aux.setSiguiente(this.inicio);
/* 127 */       (this.inicio = aux).setDato(elem);
/*     */     } else {
/*     */       
/* 130 */       T temp = this.actual.getDato();
/* 131 */       aux.setSiguiente(this.actual.getSiguiente());
/* 132 */       this.actual.setSiguiente(aux);
/* 133 */       aux.setDato(temp);
/* 134 */       this.actual.setDato(elem);
/*     */     } 
/* 136 */     this.actual = aux;
/* 137 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\ListaEnlazadaGenerica.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */