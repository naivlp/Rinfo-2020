/*     */ package form;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Scanner
/*     */ {
/*     */   public char currentChar;
/*     */   public byte currentKind;
/*     */   public StringBuffer currentSpelling;
/*     */   String cadena;
/*     */   String parametro;
/*     */   int pos;
/*     */   int indent;
/*     */   int dedent;
/*     */   int numeroEspaciosLineaActual;
/*     */   int numeroEspaciosLineaAnterior;
/*     */   int fil;
/*     */   int col;
/*     */   boolean contarEspacios;
/*     */   
/*     */   Scanner(String cadena) throws Exception {
/*  24 */     this.cadena = cadena + "\n";
/*  25 */     this.pos = 0;
/*  26 */     this.indent = 0;
/*  27 */     this.dedent = 0;
/*  28 */     this.numeroEspaciosLineaActual = 0;
/*  29 */     this.numeroEspaciosLineaAnterior = 0;
/*  30 */     this.fil = 1;
/*  31 */     this.col = 1;
/*  32 */     this.contarEspacios = true;
/*     */     try {
/*  34 */       nextchar();
/*     */     }
/*  36 */     catch (Exception e) {
/*  37 */       reportScanError(this.fil + " " + this.col + "FATAL Error!!!!!!!!!!!!!!!!!");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void reportScanError(String str) throws Exception {
/*  42 */     throw new Exception(str);
/*     */   }
/*     */   
/*     */   public void nextchar() throws Exception {
/*  46 */     if (this.pos < this.cadena.length()) {
/*  47 */       this.currentChar = this.cadena.charAt(this.pos);
/*  48 */       this.pos++;
/*  49 */       this.col++;
/*     */       return;
/*     */     } 
/*  52 */     throw new FinArchivo();
/*     */   }
/*     */   
/*     */   private void take(char expectedChar) throws Exception {
/*  56 */     if (this.currentChar == expectedChar) {
/*  57 */       this.currentSpelling.append(this.currentChar);
/*  58 */       nextchar();
/*     */     } else {
/*     */       
/*  61 */       reportScanError("Error");
/*     */     } 
/*     */   }
/*     */   
/*     */   public void takeIt() throws Exception {
/*  66 */     this.currentSpelling.append(this.currentChar);
/*  67 */     nextchar();
/*     */   }
/*     */   
/*     */   private boolean isDigit(char c) {
/*  71 */     return Character.isDigit(c);
/*     */   }
/*     */   
/*     */   public boolean isLetter(char c) {
/*  75 */     return Character.isLetter(c);
/*     */   }
/*     */   
/*     */   public byte scanToken() throws Exception {
/*  79 */     if (Token.spellings[61].equals(String.valueOf(this.currentChar)))
/*     */       while (true) {
/*  81 */         takeIt();
/*  82 */         if (Token.spellings[62].equals(String.valueOf(this.currentChar))) {
/*  83 */           takeIt();
/*  84 */           return 74;
/*     */         } 
/*  86 */       }   if (this.currentChar == '\'') {
/*  87 */       takeIt();
/*  88 */       return 78;
/*     */     } 
/*  90 */     if (isLetter(this.currentChar)) {
/*  91 */       takeIt();
/*  92 */       while (isLetter(this.currentChar) || isDigit(this.currentChar) || isPunto(this.currentChar) || isGuion(this.currentChar)) {
/*  93 */         takeIt();
/*     */       }
/*  95 */       return 0;
/*     */     } 
/*  97 */     if (this.currentChar == '(') {
/*  98 */       takeIt();
/*  99 */       return 21;
/*     */     } 
/* 101 */     if (this.currentChar == ';') {
/* 102 */       takeIt();
/* 103 */       return 60;
/*     */     } 
/* 105 */     if (this.currentChar == ':') {
/* 106 */       takeIt();
/* 107 */       if (this.currentChar == '=') {
/* 108 */         takeIt();
/* 109 */         return 31;
/*     */       } 
/* 111 */       return 28;
/*     */     } 
/*     */     
/* 114 */     if (this.currentChar == ')') {
/* 115 */       takeIt();
/* 116 */       return 22;
/*     */     } 
/* 118 */     if (this.currentChar == ',') {
/* 119 */       takeIt();
/* 120 */       return 24;
/*     */     } 
/* 122 */     if (this.currentChar == '+') {
/* 123 */       takeIt();
/* 124 */       return 45;
/*     */     } 
/* 126 */     if (this.currentChar == '-') {
/* 127 */       takeIt();
/* 128 */       return 46;
/*     */     } 
/* 130 */     if (this.currentChar == '/') {
/* 131 */       takeIt();
/* 132 */       return 47;
/*     */     } 
/* 134 */     if (this.currentChar == '*') {
/* 135 */       takeIt();
/* 136 */       return 48;
/*     */     } 
/* 138 */     if (this.currentChar == '~') {
/* 139 */       takeIt();
/* 140 */       return 49;
/*     */     } 
/* 142 */     if (this.currentChar == '&') {
/* 143 */       takeIt();
/* 144 */       return 50;
/*     */     } 
/* 146 */     if (this.currentChar == '|') {
/* 147 */       takeIt();
/* 148 */       return 51;
/*     */     } 
/* 150 */     if (this.currentChar == '=') {
/* 151 */       takeIt();
/* 152 */       return 30;
/*     */     } 
/* 154 */     if (this.currentChar == '<') {
/* 155 */       takeIt();
/* 156 */       if (this.currentChar == '=') {
/* 157 */         takeIt();
/* 158 */         return 56;
/*     */       } 
/* 160 */       if (this.currentChar == '>') {
/* 161 */         takeIt();
/* 162 */         return 54;
/*     */       } 
/* 164 */       return 52;
/*     */     } 
/* 166 */     if (this.currentChar == '>') {
/* 167 */       takeIt();
/* 168 */       if (this.currentChar == '=') {
/* 169 */         takeIt();
/* 170 */         return 55;
/*     */       } 
/* 172 */       return 53;
/*     */     } 
/*     */     
/* 175 */     if (isDigit(this.currentChar)) {
/* 176 */       takeIt();
/* 177 */       while (isDigit(this.currentChar)) {
/* 178 */         takeIt();
/*     */       }
/* 180 */       return 23;
/*     */     } 
/* 182 */     System.out.println("ESPACIOS LIBRES");
/* 183 */     this.currentSpelling.append("ERROR scanToken");
/* 184 */     throw new Exception("ERROR scanToken");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Token scan() throws Exception {
/*     */     try {
/* 191 */       if (this.currentChar == '\r') {
/* 192 */         nextchar();
/*     */       }
/* 194 */       if (this.currentChar == '\n') {
/* 195 */         this.numeroEspaciosLineaAnterior = this.numeroEspaciosLineaActual;
/* 196 */         this.col = 1;
/*     */         while (true) {
/* 198 */           nextchar();
/* 199 */           this.fil++;
/* 200 */           if (this.currentChar != '\n') {
/* 201 */             this.numeroEspaciosLineaActual = 0;
/* 202 */             while (this.currentChar == ' ') {
/* 203 */               takeIt();
/* 204 */               this.numeroEspaciosLineaActual++;
/*     */             } 
/* 206 */             if (this.currentChar != '\n') {
/*     */               break;
/*     */             }
/*     */           } 
/*     */         } 
/*     */         
/* 212 */         if (Token.spellings[61].equals(String.valueOf(this.currentChar))) {
/* 213 */           this.numeroEspaciosLineaActual = this.numeroEspaciosLineaAnterior;
/*     */         }
/* 215 */         else if (this.numeroEspaciosLineaActual % 2 == 0) {
/* 216 */           if (this.numeroEspaciosLineaActual != this.numeroEspaciosLineaAnterior) {
/* 217 */             if (this.numeroEspaciosLineaActual > this.numeroEspaciosLineaAnterior) {
/* 218 */               this.indent = (this.numeroEspaciosLineaActual - this.numeroEspaciosLineaAnterior) / 2;
/*     */             } else {
/*     */               
/* 221 */               this.dedent = (this.numeroEspaciosLineaAnterior - this.numeroEspaciosLineaActual) / 2;
/*     */             } 
/*     */           }
/*     */         } else {
/*     */           
/* 226 */           reportScanError("Error de indentación! cantidad de espacios : " + this.numeroEspaciosLineaActual + ", linumeroEspaciosLineaAnterior anterior : " + this.numeroEspaciosLineaAnterior);
/*     */         } 
/*     */       } 
/* 229 */       if (this.indent > 0) {
/* 230 */         this.indent--;
/* 231 */         return new Token((byte)42, "INDENT");
/*     */       } 
/* 233 */       if (this.dedent > 0) {
/* 234 */         this.dedent--;
/* 235 */         return new Token((byte)43, "DEDENT");
/*     */       } 
/* 237 */       this.currentSpelling = new StringBuffer("");
/* 238 */       this.currentKind = scanToken();
/* 239 */       while (this.currentChar == ' ') {
/* 240 */         nextchar();
/*     */       }
/* 242 */       return new Token(this.currentKind, this.currentSpelling.toString());
/*     */     }
/* 244 */     catch (FinArchivo e) {
/* 245 */       return new Token((byte)26, "EOT");
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isPunto(char cc) {
/* 250 */     return (cc == '.');
/*     */   }
/*     */   
/*     */   private boolean isGuion(char cc) {
/* 254 */     return (cc == '_' || cc == '-');
/*     */   }
/*     */   
/*     */   private boolean isComilla(char cc) {
/* 258 */     return (cc == '\'');
/*     */   }
/*     */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\Scanner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */