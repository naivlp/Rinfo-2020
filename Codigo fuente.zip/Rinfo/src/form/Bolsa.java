/*    */ package form;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Bolsa
/*    */ {
/* 15 */   private int papeles = 0;
/* 16 */   private int flores = 0;
/*    */   
/*    */   private boolean obstaculo = false;
/*    */   private boolean ocupado = false;
/*    */   
/*    */   public int getPapeles() {
/* 22 */     return this.papeles;
/*    */   }
/*    */   
/*    */   public void setPapeles(int algo) {
/* 26 */     this.papeles = algo;
/*    */   }
/*    */   
/*    */   public int getFlores() {
/* 30 */     return this.flores;
/*    */   }
/*    */   
/*    */   public void setFlores(int algo) {
/* 34 */     this.flores = algo;
/*    */   }
/*    */   
/*    */   public boolean getObstaculo() {
/* 38 */     return this.obstaculo;
/*    */   }
/*    */   
/*    */   public void setObstaculo(boolean algo) {
/* 42 */     this.obstaculo = algo;
/*    */   }
/*    */   
/*    */   public boolean isOcupado() {
/* 46 */     return this.ocupado;
/*    */   }
/*    */   
/*    */   public void ocupar() {
/* 50 */     this.ocupado = true;
/*    */   }
/*    */   
/*    */   public void desocupar() {
/* 54 */     this.ocupado = false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\Bolsa.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */