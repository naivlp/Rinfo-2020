package form;

public abstract class ListaGenerica<T> {
  protected int tamanio;
  
  public abstract void comenzar();
  
  public abstract void proximo();
  
  public abstract boolean fin();
  
  public abstract T elemento();
  
  public abstract T elemento(int paramInt);
  
  public abstract boolean agregar(T paramT);
  
  public abstract boolean agregar(T paramT, int paramInt);
  
  public abstract boolean eliminar();
  
  public abstract boolean eliminar(int paramInt);
  
  public abstract boolean esVacia();
  
  public abstract boolean incluye(T paramT);
  
  public abstract int tamanio();
}


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\ListaGenerica.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */