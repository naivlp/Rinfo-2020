/*     */ package form;
/*     */ 
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseWheelEvent;
/*     */ import java.awt.event.MouseWheelListener;
/*     */ import java.util.ArrayList;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JScrollBar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CiudadView
/*     */   extends JComponent
/*     */   implements MouseListener, MouseWheelListener
/*     */ {
/*     */   MonitorActualizarVentana esperarRefresco;
/*     */   private Color colorManzana;
/*     */   private int cityWidth;
/*     */   private int cityHeight;
/*     */   private int blockSize;
/*     */   private ImageIcon flor;
/*     */   private ImageIcon papel;
/*     */   private ImageIcon obstaculo;
/*     */   Ciudad city;
/*     */   Graphics lienzo;
/*     */   
/*     */   public CiudadView(Ciudad city) {
/*  42 */     this.esperarRefresco = MonitorActualizarVentana.getInstance();
/*  43 */     this.flor = new ImageIcon(getClass().getResource("/images/flor.png"));
/*  44 */     this.papel = new ImageIcon(getClass().getResource("/images/papel.png"));
/*  45 */     this.obstaculo = new ImageIcon(getClass().getResource("/images/obstaculo.png"));
/*  46 */     setDoubleBuffered(true);
/*  47 */     setOpaque(true);
/*  48 */     this.city = city;
/*  49 */     addMouseListener(this);
/*  50 */     this.colorManzana = Color.GRAY;
/*  51 */     setBlockSize(10);
/*  52 */     addMouseWheelListener(this);
/*     */   }
/*     */   
/*     */   public void setBlockSize(int blockSize) {
/*  56 */     if (blockSize < 1) {
/*  57 */       blockSize = 1;
/*     */     }
/*  59 */     if (blockSize > 30) {
/*  60 */       blockSize = 30;
/*     */     }
/*  62 */     this.blockSize = blockSize;
/*  63 */     this.cityHeight = this.city.getNumCa() * blockSize * 2;
/*  64 */     this.cityWidth = this.city.getNumAv() * blockSize * 2;
/*     */   }
/*     */   
/*     */   public int getBlockSize() {
/*  68 */     return this.blockSize;
/*     */   }
/*     */   
/*     */   public Color getColorManzana() {
/*  72 */     return this.colorManzana;
/*     */   }
/*     */   
/*     */   public void paintComponent(Graphics g) {
/*  76 */     super.paintComponent(g);
/*  77 */     this.lienzo = g;
/*     */     try {
/*  79 */       dibujarCiudad();
/*     */     }
/*  81 */     catch (Exception e) {
/*  82 */       System.out.println("Error en Paint Component" + e.getMessage());
/*     */     } 
/*  84 */     for (int i = 0; i < this.city.robots.size(); i++) {
/*     */       try {
/*  86 */         this.esperarRefresco.pintarRuta(this.city.robots.get(i));
/*     */       }
/*  88 */       catch (Exception ex) {
/*  89 */         System.out.println("Error en Paint Component en la clase CiudadView");
/*  90 */         Logger.getLogger(CiudadView.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public int x2Av(int x) {
/*  96 */     int pos = (x + 4) / this.blockSize * 2 + 1;
/*  97 */     if (pos < 1) {
/*  98 */       pos = 1;
/*     */     }
/* 100 */     if (pos > this.city.getNumAv()) {
/* 101 */       pos = this.city.getNumAv();
/*     */     }
/* 103 */     return pos;
/*     */   }
/*     */   
/*     */   public int y2Ca(int y) {
/* 107 */     int pos = this.city.getNumCa() - (y + 4) / this.blockSize * 2;
/* 108 */     if (pos < 1) {
/* 109 */       pos = 1;
/*     */     }
/* 111 */     if (pos > this.city.getNumCa()) {
/* 112 */       pos = this.city.getNumCa();
/*     */     }
/* 114 */     return pos;
/*     */   }
/*     */   
/*     */   public int Av2x(int Av) {
/* 118 */     return this.blockSize * 2 * (Av - 1) + this.blockSize / 2;
/*     */   }
/*     */   
/*     */   public int Ca2y(int Ca) {
/* 122 */     Ca = this.city.getNumCa() + 1 - Ca;
/* 123 */     return this.blockSize * 2 * (Ca - 1) + this.blockSize + this.blockSize / 2;
/*     */   }
/*     */   
/*     */   protected void dibujarCiudad() throws Exception {
/* 127 */     this.lienzo.setColor(Color.white);
/* 128 */     this.lienzo.fillRect(0, 0, getWidth(), getHeight());
/* 129 */     this.lienzo.setColor(Color.black);
/* 130 */     this.lienzo.setColor(getColorManzana());
/* 131 */     for (int ca = 1; ca <= this.city.getNumCa(); ca++) {
/* 132 */       for (int av = 1; av <= this.city.getNumAv(); av++) {
/* 133 */         if (ca == 1 || av == 100) {
/* 134 */           this.lienzo.setColor(Color.WHITE);
/*     */         }
/* 136 */         dibujarManzana(av, ca);
/* 137 */         dibujarEsquina(av, ca);
/* 138 */         this.lienzo.setColor(this.colorManzana);
/*     */       } 
/*     */     } 
/* 141 */     dibujarArea();
/*     */   }
/*     */   
/*     */   protected void dibujarCiudadVentanita() throws Exception {
/* 145 */     this.lienzo.setColor(Color.white);
/* 146 */     this.lienzo.fillRect(0, 0, getWidth(), getHeight());
/* 147 */     this.lienzo.setColor(Color.black);
/* 148 */     this.lienzo.drawRect(0, getBlockSize(), this.city.getNumAv() * getBlockSize() * 2 + getBlockSize(), this.city.getNumCa() * getBlockSize() * 2 + getBlockSize());
/* 149 */     this.lienzo.setColor(getColorManzana());
/* 150 */     for (int ca = 1; ca <= this.city.getNumCa(); ca++) {
/* 151 */       for (int av = 1; av <= this.city.getNumAv(); av++) {
/* 152 */         if (ca == 0 || av == 100) {
/* 153 */           this.lienzo.setColor(Color.WHITE);
/*     */         }
/* 155 */         dibujarManzana(av, ca);
/* 156 */         dibujarEsquina(av, ca);
/* 157 */         this.lienzo.setColor(this.colorManzana);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void dibujarArea() throws Exception {
/* 163 */     Graphics2D g2 = (Graphics2D)this.lienzo;
/* 164 */     Stroke strokeBefore = g2.getStroke();
/* 165 */     int av = 1;
/* 166 */     int ca = 1;
/* 167 */     for (Area area : this.city.areas) {
/* 168 */       int x = Av2x(area.getAv1());
/* 169 */       int y = Ca2y(area.getCa2());
/* 170 */       int width = (area.getAv2() - area.getAv1()) * getBlockSize() * 2;
/* 171 */       int height = (area.getCa2() - area.getCa1()) * getBlockSize() * 2;
/* 172 */       g2.setStroke(strokeBefore);
/* 173 */       g2.setColor(Color.WHITE);
/* 174 */       g2.fillRect(x, y, width, height);
/* 175 */       g2.setColor(area.getColor());
/* 176 */       for (ca = area.getCa1() + 1; ca <= area.getCa2(); ca++) {
/* 177 */         for (av = area.getAv1(); av < area.getAv2(); av++) {
/* 178 */           if (ca == 1 || av == 100) {
/* 179 */             this.lienzo.setColor(Color.WHITE);
/*     */           }
/* 181 */           this.lienzo.setColor(area.getColor());
/* 182 */           dibujarManzana(av, ca);
/* 183 */           dibujarEsquina(av, ca);
/*     */         } 
/*     */       } 
/* 186 */       g2.setColor(area.getColor());
/* 187 */       g2.setStroke(new BasicStroke(3.0F));
/* 188 */       g2.drawRect(x, y, width, height);
/* 189 */       this.lienzo.setColor(this.colorManzana);
/*     */     } 
/* 191 */     g2.setStroke(strokeBefore);
/*     */   }
/*     */   
/*     */   private void dibujarManzana(int av, int ca) {
/* 195 */     int xCoord = Av2x(av) + this.blockSize / 2;
/* 196 */     int yCoord = Ca2y(ca) + this.blockSize / 2;
/* 197 */     this.lienzo.fillRect(xCoord, yCoord, this.blockSize, this.blockSize);
/*     */   }
/*     */   
/*     */   private void dibujarEsquina(int av, int ca) throws Exception {
/* 201 */     ImageIcon image = null;
/* 202 */     int xCoord = Av2x(av) - this.blockSize / 2;
/* 203 */     int yCoord = Ca2y(ca) - this.blockSize / 2;
/* 204 */     if (!this.city.isFreePos(ca, av)) {
/* 205 */       image = this.obstaculo;
/*     */     } else {
/*     */       
/* 208 */       if (this.city.HayPapelEnLaEsquina(av, ca)) {
/* 209 */         image = this.papel;
/*     */       }
/* 211 */       if (this.city.HayFlorEnLaEsquina(av, ca)) {
/* 212 */         image = this.flor;
/*     */       }
/*     */     } 
/* 215 */     if (image != null) {
/* 216 */       this.lienzo.drawImage(image.getImage(), xCoord, yCoord, this.blockSize, this.blockSize, null);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void dibujarRuta(Robot robot) throws Exception {
/* 221 */     synchronized (this) {
/*     */       try {
/* 223 */         int c = 0;
/* 224 */         Graphics2D g2 = (Graphics2D)this.lienzo;
/* 225 */         ArrayList<ArrayList<Coord>> items = robot.getRutas();
/* 226 */         for (ArrayList<Coord> item : items) {
/* 227 */           c = 0;
/* 228 */           int[] x = new int[item.size()];
/* 229 */           int[] y = new int[item.size()];
/* 230 */           g2.setColor(robot.getColor());
/* 231 */           g2.setStroke(new BasicStroke(2.0F));
/* 232 */           for (Coord punto : item) {
/* 233 */             x[c] = Av2x(punto.getX());
/* 234 */             y[c] = Ca2y(punto.getY());
/* 235 */             c++;
/*     */           } 
/* 237 */           g2.drawPolyline(x, y, c);
/* 238 */           int xCoord = Av2x(robot.PosAv()) - this.blockSize / 2;
/* 239 */           int yCoord = Ca2y(robot.PosCa()) - this.blockSize / 2;
/* 240 */           this.lienzo.drawImage(robot.getImage(), xCoord, yCoord, this.blockSize, this.blockSize, null);
/*     */         } 
/* 242 */         c = 0;
/* 243 */         ArrayList<Coord> itemx = robot.getRuta();
/* 244 */         int[] x2 = new int[itemx.size()];
/* 245 */         int[] y2 = new int[itemx.size()];
/* 246 */         g2.setColor(robot.getColor());
/* 247 */         g2.setStroke(new BasicStroke(2.0F));
/* 248 */         for (Coord punto2 : itemx) {
/* 249 */           x2[c] = Av2x(punto2.getX());
/* 250 */           y2[c] = Ca2y(punto2.getY());
/* 251 */           c++;
/*     */         } 
/* 253 */         g2.drawPolyline(x2, y2, c);
/* 254 */         int xCoord2 = Av2x(robot.PosAv()) - this.blockSize / 2;
/* 255 */         int yCoord2 = Ca2y(robot.PosCa()) - this.blockSize / 2;
/* 256 */         this.lienzo.fillRect(xCoord2, yCoord2, this.blockSize, this.blockSize);
/* 257 */         this.lienzo.drawImage(robot.getImage(), xCoord2, yCoord2, this.blockSize, this.blockSize, null);
/*     */       }
/* 259 */       catch (Exception ex) {
/* 260 */         throw new Exception("Algo anda mal en dibujarRuta  " + ex.getMessage());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize() {
/* 267 */     return new Dimension(this.cityHeight, this.cityWidth);
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMinimumSize() {
/* 272 */     return getPreferredSize();
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMaximumSize() {
/* 277 */     return getPreferredSize();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void mousePressed(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseDragged(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseEntered(MouseEvent e) {}
/*     */ 
/*     */   
/*     */   public void mouseExited(MouseEvent e) {}
/*     */ 
/*     */   
/*     */   public void mouseMoved(MouseEvent e) {}
/*     */ 
/*     */   
/*     */   public void mouseReleased(MouseEvent e) {}
/*     */ 
/*     */   
/*     */   public int getHeight2(int offset) {
/* 303 */     int h = this.city.getNumCa() * (getBlockSize() + offset) * 2;
/* 304 */     return h;
/*     */   }
/*     */   
/*     */   public int getHeight2() {
/* 308 */     return getHeight2(0);
/*     */   }
/*     */   
/*     */   public int getWidth2(int offset) {
/* 312 */     int w = this.city.getNumAv() * (getBlockSize() + offset) * 2;
/* 313 */     return w;
/*     */   }
/*     */   
/*     */   public int getWidth2() {
/* 317 */     return getWidth2(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseWheelMoved(MouseWheelEvent e) {
/* 322 */     Container tmp = getParent();
/* 323 */     for (int c = 0; c < 100 && !(tmp instanceof CityScroll); ) { tmp = tmp.getParent(); c++; }
/* 324 */      CityScroll tmp2 = (CityScroll)tmp;
/* 325 */     if (e.isControlDown()) {
/* 326 */       Rectangle rr = tmp2.getViewport().getBounds();
/* 327 */       if (getHeight2(e.getWheelRotation()) > rr.height && getWidth2(e.getWheelRotation()) > rr.width) {
/* 328 */         setBlockSize(getBlockSize() + e.getWheelRotation());
/*     */       }
/*     */     } else {
/*     */       
/* 332 */       JScrollBar vbar = this.city.form.jsp.getVerticalScrollBar();
/* 333 */       int newValue = vbar.getValue() + e.getWheelRotation() * getBlockSize() * 5;
/* 334 */       vbar.setValue(newValue);
/*     */     } 
/* 336 */     tmp2.refresh();
/*     */   }
/*     */   
/*     */   public void mouseClicked(MouseEvent e) {}
/*     */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\CiudadView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */