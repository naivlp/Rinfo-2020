/*    */ package form;
/*    */ 
/*    */ import javax.swing.text.AttributeSet;
/*    */ import javax.swing.text.BadLocationException;
/*    */ import javax.swing.text.DocumentFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DocumentTabFilter
/*    */   extends DocumentFilter
/*    */ {
/*    */   public void insertString(DocumentFilter.FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
/* 15 */     string = string.replace("\t", "  ");
/* 16 */     string = string.replace("\r", "");
/* 17 */     string = string.replace("^M", "");
/* 18 */     super.insertString(fb, offset, string, attr);
/*    */   }
/*    */ 
/*    */   
/*    */   public void replace(DocumentFilter.FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
/* 23 */     text = text.replace("\t", "  ");
/* 24 */     text = text.replace("\r", "");
/* 25 */     text = text.replace("^M", "");
/* 26 */     super.replace(fb, offset, length, text, attrs);
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\DocumentTabFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */