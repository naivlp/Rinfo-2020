/*    */ package form;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Coord
/*    */ {
/*    */   int x;
/*    */   int y;
/*    */   
/*    */   public Coord(int x, int y) {
/* 13 */     setX(x);
/* 14 */     setY(y);
/*    */   }
/*    */   
/*    */   public int getX() {
/* 18 */     return this.x;
/*    */   }
/*    */   
/*    */   public void setX(int x) {
/* 22 */     this.x = x;
/*    */   }
/*    */   
/*    */   public int getY() {
/* 26 */     return this.y;
/*    */   }
/*    */   
/*    */   public void setY(int y) {
/* 30 */     this.y = y;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\Coord.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */