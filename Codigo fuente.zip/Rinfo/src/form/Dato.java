/*    */ package form;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Dato
/*    */ {
/*    */   String valor;
/*    */   String NombreRobot;
/*    */   
/*    */   public Dato(String valor, String NombreRobot) {
/* 13 */     this.valor = valor;
/* 14 */     this.NombreRobot = NombreRobot;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\Dato.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */