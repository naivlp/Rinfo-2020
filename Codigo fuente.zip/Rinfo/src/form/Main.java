/*    */ package form;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.ComponentOrientation;
/*    */ import java.awt.FlowLayout;
/*    */ import java.beans.PropertyChangeEvent;
/*    */ import java.beans.PropertyChangeListener;
/*    */ import java.util.ArrayList;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JOptionPane;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.JSplitPane;
/*    */ import javax.swing.JTextArea;
/*    */ import javax.swing.SwingUtilities;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Main
/*    */   extends JFrame
/*    */   implements PropertyChangeListener
/*    */ {
/*    */   Ciudad cdad;
/*    */   Compedos compedos;
/*    */   public CityScroll jsp;
/*    */   MonitorActualizarVentana monitorCola;
/*    */   MonitorEsquinas esquinas;
/*    */   private JSplitPane splitPane;
/*    */   public Compe c;
/*    */   JFrame cod2;
/*    */   ArrayList<JTextArea> jt;
/*    */   
/*    */   public Main() {
/* 37 */     super(CodePanel.archivoactual + " R-info (versión 3.0)");
/* 38 */     this.monitorCola = MonitorActualizarVentana.crearMonitorActualizarVentana(4);
/* 39 */     this.esquinas = MonitorEsquinas.crearMonitorEsquinas();
/* 40 */     this.cod2 = new JFrame();
/* 41 */     this.jt = new ArrayList<>();
/*    */   }
/*    */   
/*    */   public void mostrarMensaje(String args, String titulo, int tipo) {
/* 45 */     JOptionPane.showMessageDialog(null, args, titulo, tipo);
/*    */   }
/*    */   
/*    */   public void createAndShowGUI() throws Exception {
/* 49 */     setDefaultCloseOperation(3);
/* 50 */     setExtendedState(6);
/*    */     try {
/* 52 */       this.cdad = new Ciudad(this);
/*    */     }
/* 54 */     catch (Exception ex) {
/* 55 */       Logger.getLogger(Main.class.getName()).log(Level.SEVERE, (String)null, ex);
/*    */     } 
/* 57 */     this.cdad.addPropertyChangeListener(this);
/* 58 */     this.compedos = new Compedos(this.cdad);
/* 59 */     this.jsp = new CityScroll(this.cdad);
/* 60 */     this.monitorCola.setCityScroll(this.jsp);
/* 61 */     FlowLayout exLay = new FlowLayout();
/* 62 */     this.cod2.setLayout(exLay);
/* 63 */     this.cod2.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
/* 64 */     this.cod2.pack();
/* 65 */     JPanel contentPane = (JPanel)getContentPane();
/* 66 */     JPanel contentPaneLeft = new JPanel(new BorderLayout(1, 2));
/* 67 */     contentPaneLeft.add(this.c = new Compe(this.cdad), "North");
/* 68 */     contentPaneLeft.add(this.compedos, "Center");
/* 69 */     contentPane.add(contentPaneLeft, "West");
/* 70 */     JSplitPane splitPane2 = new JSplitPane(0, new CodePanel(this.cdad), this.jsp);
/* 71 */     splitPane2.setOneTouchExpandable(true);
/* 72 */     splitPane2.setDividerLocation(300);
/* 73 */     JPanel contentPaneDerecho = new JPanel();
/* 74 */     contentPaneDerecho.add(this.compedos.iv.tempPanelRobots);
/* 75 */     (this.splitPane = new JSplitPane(1, splitPane2, contentPaneDerecho)).setOneTouchExpandable(true);
/* 76 */     this.splitPane.setDividerLocation(750);
/* 77 */     this.splitPane.addPropertyChangeListener("dividerLocation", new PropertyChangeListener()
/*    */         {
/*    */           public void propertyChange(PropertyChangeEvent pce) {
/* 80 */             Main.this.jsp.refresh();
/*    */           }
/*    */         });
/* 83 */     contentPane.add(this.splitPane, "Center");
/* 84 */     pack();
/* 85 */     setVisible(true);
/*    */   }
/*    */   
/*    */   public static void main(String[] args) {
/* 89 */     SwingUtilities.invokeLater(new Runnable()
/*    */         {
/*    */           public void run() {
/*    */             try {
/* 93 */               (new Main()).createAndShowGUI();
/*    */             }
/* 95 */             catch (Exception ex) {
/* 96 */               Logger.getLogger(Main.class.getName()).log(Level.SEVERE, (String)null, ex);
/*    */             } 
/*    */           }
/*    */         });
/*    */   }
/*    */   
/*    */   public void propertyChange(PropertyChangeEvent evt) {}
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */