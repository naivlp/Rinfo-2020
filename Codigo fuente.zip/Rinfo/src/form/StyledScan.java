/*     */ package form;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StyledScan
/*     */ {
/*     */   Ciudad city;
/*     */   String text;
/*     */   char currentChar;
/*     */   byte currentKind;
/*     */   int pos;
/*     */   int col;
/*     */   StringBuffer currentSpelling;
/*     */   private int fil;
/*     */   boolean ok;
/*     */   boolean comillas;
/*     */   ArrayList<StyledToken> currentArea;
/*     */   
/*     */   public StyledScan(String text, Ciudad city) {
/*  24 */     this.currentArea = new ArrayList<>();
/*  25 */     this.city = city;
/*  26 */     this.text = text.replace("\r", "");
/*  27 */     this.pos = 1;
/*  28 */     this.col = 0;
/*  29 */     this.currentChar = this.text.charAt(0);
/*  30 */     this.ok = false;
/*  31 */     this.comillas = false;
/*     */   }
/*     */   
/*     */   public void nextchar() {
/*  35 */     if (this.pos < this.text.length()) {
/*  36 */       this.currentChar = this.text.charAt(this.pos);
/*  37 */       this.pos++;
/*  38 */       this.col++;
/*     */     } else {
/*     */       
/*  41 */       this.currentChar = '#';
/*     */     } 
/*     */   }
/*     */   
/*     */   public char peakNextChar() {
/*  46 */     if (this.pos + 1 < this.text.length()) {
/*  47 */       return this.text.charAt(this.pos + 1);
/*     */     }
/*  49 */     System.out.println("Fin de archivo en el peakNextChar");
/*  50 */     return '#';
/*     */   }
/*     */   
/*     */   private void take(char expectedChar) throws Exception {
/*  54 */     if (this.currentChar == expectedChar) {
/*  55 */       this.currentSpelling.append(this.currentChar);
/*  56 */       nextchar();
/*     */       return;
/*     */     } 
/*  59 */     throw new Exception("Se esperaba el caracter " + expectedChar);
/*     */   }
/*     */   
/*     */   public void takeIt() throws Exception {
/*  63 */     if (this.currentChar != '\r') {
/*  64 */       this.currentSpelling.append(this.currentChar);
/*     */     } else {
/*     */       
/*  67 */       System.out.println("Era barra r en el takeit");
/*     */     } 
/*  69 */     nextchar();
/*     */   }
/*     */   
/*     */   public StyledToken scan() throws Exception {
/*  73 */     while (this.currentChar == '\n' || this.currentChar == ' ') {
/*  74 */       if (this.currentChar == '\n');
/*  75 */       nextchar();
/*     */     } 
/*  77 */     this.currentSpelling = new StringBuffer("");
/*  78 */     int from = this.pos - 1;
/*  79 */     this.currentKind = scanToken();
/*  80 */     StyledToken myTkn = new StyledToken(this.currentKind, from, this.currentSpelling.toString(), this.ok, this.comillas);
/*  81 */     this.currentArea.add(myTkn);
/*  82 */     return myTkn;
/*     */   }
/*     */   
/*     */   public byte scanToken() throws Exception {
/*  86 */     if (Character.isLetter(this.currentChar)) {
/*  87 */       takeIt();
/*  88 */       while (Character.isLetter(this.currentChar) || Character.isDigit(this.currentChar)) {
/*  89 */         takeIt();
/*     */       }
/*  91 */       return StyledToken.IDENTIFER;
/*     */     } 
/*  93 */     if (Character.isDigit(this.currentChar)) {
/*  94 */       takeIt();
/*  95 */       while (Character.isDigit(this.currentChar)) {
/*  96 */         takeIt();
/*     */       }
/*  98 */       return StyledToken.LITERAL;
/*     */     } 
/* 100 */     byte kind = -1;
/*     */     
/* 102 */     switch (this.currentChar) {
/*     */       case '(':
/* 104 */         kind = StyledToken.OPERADOR;
/*     */         break;
/*     */       
/*     */       case ';':
/* 108 */         kind = StyledToken.OPERADOR;
/*     */         break;
/*     */       
/*     */       case ':':
/* 112 */         if (peakNextChar() == '=') {
/* 113 */           takeIt();
/* 114 */           kind = StyledToken.OPERADOR;
/*     */           break;
/*     */         } 
/* 117 */         kind = StyledToken.OPERADOR;
/*     */         break;
/*     */       
/*     */       case '{':
/* 121 */         kind = StyledToken.COMENTARIO;
/* 122 */         this.ok = true;
/*     */         break;
/*     */       
/*     */       case '"':
/* 126 */         kind = StyledToken.LITERAL;
/* 127 */         this.comillas = !this.comillas;
/*     */         break;
/*     */       
/*     */       case '}':
/* 131 */         kind = StyledToken.COMENTARIO;
/* 132 */         this.ok = false;
/*     */         break;
/*     */       
/*     */       case ')':
/* 136 */         kind = StyledToken.OPERADOR;
/*     */         break;
/*     */       
/*     */       case ',':
/* 140 */         kind = StyledToken.OPERADOR;
/*     */         break;
/*     */       
/*     */       case '+':
/* 144 */         kind = StyledToken.OPERADOR;
/*     */         break;
/*     */       
/*     */       case '-':
/* 148 */         kind = StyledToken.OPERADOR;
/*     */         break;
/*     */       
/*     */       case '/':
/* 152 */         kind = StyledToken.OPERADOR;
/*     */         break;
/*     */       
/*     */       case '*':
/* 156 */         kind = StyledToken.OPERADOR;
/*     */         break;
/*     */       
/*     */       case '~':
/* 160 */         kind = StyledToken.OPERADOR;
/*     */         break;
/*     */       
/*     */       case '&':
/* 164 */         kind = StyledToken.OPERADOR;
/*     */         break;
/*     */       
/*     */       case '|':
/* 168 */         kind = StyledToken.OPERADOR;
/*     */         break;
/*     */       
/*     */       case '=':
/* 172 */         kind = StyledToken.OPERADOR;
/*     */         break;
/*     */       
/*     */       case '<':
/* 176 */         switch (peakNextChar()) {
/*     */           case '=':
/* 178 */             takeIt();
/* 179 */             kind = StyledToken.OPERADOR;
/*     */             break;
/*     */           
/*     */           case '>':
/* 183 */             takeIt();
/* 184 */             kind = StyledToken.OPERADOR;
/*     */             break;
/*     */         } 
/*     */         
/* 188 */         kind = StyledToken.OPERADOR;
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case '>':
/* 194 */         if (peakNextChar() == '=') {
/* 195 */           takeIt();
/* 196 */           kind = StyledToken.OPERADOR;
/*     */           break;
/*     */         } 
/* 199 */         kind = StyledToken.OPERADOR;
/*     */         break;
/*     */       
/*     */       case '#':
/* 203 */         kind = StyledToken.EOF;
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 208 */     takeIt();
/* 209 */     return kind;
/*     */   }
/*     */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\StyledScan.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */