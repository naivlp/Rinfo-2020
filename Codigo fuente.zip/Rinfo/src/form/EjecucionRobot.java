/*    */ package form;
/*    */ 
/*    */ import java.beans.PropertyChangeEvent;
/*    */ import java.beans.PropertyChangeListener;
/*    */ import java.beans.PropertyChangeSupport;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EjecucionRobot
/*    */   implements Runnable, PropertyChangeListener
/*    */ {
/*    */   Robot prgAST;
/*    */   MonitorActualizarVentana esperarRefresco;
/*    */   boolean pasoAPaso;
/*    */   CodePanel codigo;
/*    */   private final PropertyChangeSupport pcs;
/*    */   
/*    */   public EjecucionRobot(Robot prg, boolean paso_a_paso, CodePanel code) {
/* 22 */     this.esperarRefresco = MonitorActualizarVentana.getInstance();
/* 23 */     this.pasoAPaso = false;
/* 24 */     this.pcs = new PropertyChangeSupport(this);
/* 25 */     this.pasoAPaso = paso_a_paso;
/* 26 */     this.prgAST = prg;
/* 27 */     this.codigo = code;
/*    */   }
/*    */ 
/*    */   
/*    */   public void run() {
/*    */     try {
/* 33 */       System.out.println("ejecutando robot: " + this.prgAST.getNombre());
/* 34 */       this.prgAST.setEstado("ejecutandose");
/* 35 */       this.prgAST.getCuerpo().ejecutar();
/* 36 */       if (this.esperarRefresco.termine_ejecucion()) {
/* 37 */         System.out.println("SOY EL ULTIMO" + this.prgAST.getNombre());
/* 38 */         this.esperarRefresco.setEn_ejecucion(false);
/* 39 */         this.esperarRefresco.setApretoF7(false);
/* 40 */         this.esperarRefresco.setTimerOn(false);
/* 41 */         this.codigo.habilitarTodo();
/*    */       } else {
/*    */         
/* 44 */         System.out.println("No soy el ultimo, pero termine :" + this.prgAST.getNombre());
/*    */       } 
/* 46 */       this.prgAST.setEstado("finalizado");
/* 47 */       System.out.println("nombre de robot : " + this.prgAST.getNombre() + " termino ");
/*    */     }
/* 49 */     catch (Exception e) {
/* 50 */       System.out.println(e);
/*    */       try {
/* 52 */         this.codigo.doStopStepByStep();
/*    */       }
/* 54 */       catch (Exception ex) {
/* 55 */         System.out.println(ex);
/* 56 */         Logger.getLogger(Ejecucion.class.getName()).log(Level.SEVERE, (String)null, ex);
/*    */       } 
/* 58 */       this.codigo.habilitarTodo();
/*    */     } 
/*    */   }
/*    */   
/*    */   public void dormir() {
/* 63 */     this.esperarRefresco.dormir();
/*    */   }
/*    */   
/*    */   public void arrancar() {
/* 67 */     this.esperarRefresco.arrancar();
/*    */   }
/*    */ 
/*    */   
/*    */   public void propertyChange(PropertyChangeEvent evt) {
/* 72 */     System.out.println("HOLA");
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\EjecucionRobot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */