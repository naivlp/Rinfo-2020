/*    */ package form;
/*    */ 
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Image;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PanelImg
/*    */   extends JPanel
/*    */ {
/*    */   private Image imagen;
/*    */   
/*    */   PanelImg(Image img) {
/* 18 */     this.imagen = img;
/* 19 */     setMaximumSize(new Dimension(16, 16));
/* 20 */     setMinimumSize(new Dimension(16, 16));
/*    */   }
/*    */   
/*    */   public void setImage(Image img) {
/* 24 */     this.imagen = img;
/* 25 */     repaint();
/*    */   }
/*    */ 
/*    */   
/*    */   public void paint(Graphics g) {
/* 30 */     g.drawImage(this.imagen, 0, 0, getWidth(), getHeight(), this);
/* 31 */     setOpaque(true);
/* 32 */     super.paint(g);
/* 33 */     g.drawImage(this.imagen, 0, 0, getWidth(), getHeight(), this);
/* 34 */     setOpaque(false);
/* 35 */     super.paint(g);
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\PanelImg.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */