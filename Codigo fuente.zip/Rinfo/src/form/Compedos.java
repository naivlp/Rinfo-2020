/*    */ package form;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.GridBagConstraints;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Compedos
/*    */   extends JPanel
/*    */ {
/*    */   Ciudad city;
/*    */   InspectorVariables iv;
/*    */   GridBagConstraints gbc;
/*    */   
/*    */   Compedos(Ciudad city) {
/* 20 */     this.gbc = new GridBagConstraints();
/* 21 */     this.city = city;
/* 22 */     this.iv = new InspectorVariables(this.city);
/* 23 */     setLayout(new BorderLayout());
/* 24 */     add(this.iv, "North");
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\Compedos.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */