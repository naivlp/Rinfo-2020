/*    */ package form;
/*    */ 
/*    */ import java.awt.Color;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Area
/*    */ {
/*    */   protected String name;
/*    */   protected int ca1;
/*    */   protected int av1;
/*    */   protected int ca2;
/*    */   protected int av2;
/*    */   protected Color color;
/*    */   
/*    */   public Area(int av1, int ca1, int av2, int ca2, String nombre) {
/* 19 */     this.color = null;
/* 20 */     this.ca1 = ca1;
/* 21 */     this.av1 = av1;
/* 22 */     this.ca2 = ca2;
/* 23 */     this.av2 = av2;
/* 24 */     setName(nombre);
/*    */   }
/*    */   
/*    */   public String getName() {
/* 28 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 32 */     this.name = name;
/*    */   }
/*    */   
/*    */   public int getAv1() {
/* 36 */     return this.av1;
/*    */   }
/*    */   
/*    */   public void setAv1(int av1) {
/* 40 */     this.av1 = av1;
/*    */   }
/*    */   
/*    */   public int getAv2() {
/* 44 */     return this.av2;
/*    */   }
/*    */   
/*    */   public void setAv2(int av2) {
/* 48 */     this.av2 = av2;
/*    */   }
/*    */   
/*    */   public int getCa1() {
/* 52 */     return this.ca1;
/*    */   }
/*    */   
/*    */   public void setCa1(int ca1) {
/* 56 */     this.ca1 = ca1;
/*    */   }
/*    */   
/*    */   public int getCa2() {
/* 60 */     return this.ca2;
/*    */   }
/*    */   
/*    */   public void setCa2(int ca2) {
/* 64 */     this.ca2 = ca2;
/*    */   }
/*    */   
/*    */   public Color getColor() {
/* 68 */     return this.color;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\Area.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */