/*    */ package form;
/*    */ 
/*    */ import java.awt.GridBagConstraints;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Compe
/*    */   extends JPanel
/*    */ {
/*    */   public Configuraciones conf;
/*    */   Ciudad city;
/*    */   GridBagConstraints gbc;
/*    */   
/*    */   Compe(Ciudad city) {
/* 18 */     this.city = city;
/* 19 */     GridBagConstraints gbc = new GridBagConstraints();
/* 20 */     this.conf = new Configuraciones(this.city);
/* 21 */     gbc.fill = 1;
/* 22 */     gbc.anchor = 10;
/* 23 */     add(this.conf, gbc);
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\Compe.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */