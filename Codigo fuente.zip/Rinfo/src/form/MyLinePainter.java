/*     */ package form;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Shape;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.event.CaretEvent;
/*     */ import javax.swing.event.CaretListener;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Highlighter;
/*     */ import javax.swing.text.JTextComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MyLinePainter
/*     */   implements Highlighter.HighlightPainter, CaretListener, MouseListener, MouseMotionListener
/*     */ {
/*     */   private JTextComponent component;
/*     */   private Color color;
/*     */   private Rectangle lastView;
/*     */   
/*     */   public MyLinePainter(JTextComponent component) {
/*  28 */     this(component, null);
/*  29 */     setLighter(component.getSelectionColor());
/*     */   }
/*     */   
/*     */   public MyLinePainter(JTextComponent component, Color color) {
/*  33 */     this.component = component;
/*  34 */     setColor(color);
/*  35 */     component.addCaretListener(this);
/*  36 */     component.addMouseListener(this);
/*  37 */     component.addMouseMotionListener(this);
/*     */     try {
/*  39 */       component.getHighlighter().addHighlight(0, 0, this);
/*     */     }
/*  41 */     catch (BadLocationException badLocationException) {}
/*     */   }
/*     */   
/*     */   public void setColor(Color color) {
/*  45 */     this.color = color;
/*     */   }
/*     */   
/*     */   public void setLighter(Color color) {
/*  49 */     int red = Math.min(255, (int)(color.getRed() * 1.2D));
/*  50 */     int green = Math.min(255, (int)(color.getGreen() * 1.2D));
/*  51 */     int blue = Math.min(255, (int)(color.getBlue() * 1.2D));
/*  52 */     setColor(new Color(red, green, blue));
/*     */   }
/*     */ 
/*     */   
/*     */   public void paint(Graphics g, int p0, int p1, Shape bounds, JTextComponent c) {
/*     */     try {
/*  58 */       Rectangle r = c.modelToView(c.getCaretPosition());
/*  59 */       g.setColor(this.color);
/*  60 */       g.fillRect(0, r.y, c.getWidth(), r.height);
/*  61 */       if (this.lastView == null) {
/*  62 */         this.lastView = r;
/*     */       }
/*     */     }
/*  65 */     catch (BadLocationException ble) {
/*  66 */       System.out.println(ble);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void resetHighlight() {
/*  71 */     SwingUtilities.invokeLater(new Runnable()
/*     */         {
/*     */           public void run() {
/*     */             try {
/*  75 */               int offset = MyLinePainter.this.component.getCaretPosition();
/*  76 */               Rectangle currentView = MyLinePainter.this.component.modelToView(offset);
/*  77 */               if (MyLinePainter.this.lastView != null && MyLinePainter.this.lastView.y != currentView.y) {
/*  78 */                 MyLinePainter.this.component.repaint(0, MyLinePainter.this.lastView.y, MyLinePainter.this.component.getWidth(), MyLinePainter.this.lastView.height);
/*  79 */                 MyLinePainter.this.lastView = currentView;
/*     */               }
/*     */             
/*  82 */             } catch (BadLocationException badLocationException) {}
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public void caretUpdate(CaretEvent e) {
/*  89 */     resetHighlight();
/*     */   }
/*     */ 
/*     */   
/*     */   public void mousePressed(MouseEvent e) {
/*  94 */     resetHighlight();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseClicked(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseEntered(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseExited(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseReleased(MouseEvent e) {}
/*     */ 
/*     */   
/*     */   public void mouseDragged(MouseEvent e) {
/* 115 */     resetHighlight();
/*     */   }
/*     */   
/*     */   public void mouseMoved(MouseEvent e) {}
/*     */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\MyLinePainter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */