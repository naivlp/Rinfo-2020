/*    */ package form;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.expresion.Expresion;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JOptionPane;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LeerVentana
/*    */   extends JFrame
/*    */ {
/*    */   public DeclaracionVariable DV;
/*    */   public Expresion E;
/*    */   
/*    */   public LeerVentana(DeclaracionVariable DV, Expresion E) throws Exception {
/* 20 */     this.E = E;
/* 21 */     this.DV = DV;
/* 22 */     String nombre = E.getI().toString();
/* 23 */     if (E.getT().getTipo() == 20) {
/* 24 */       Object[] possibilities = { "V", "F" };
/* 25 */       String s = (String)JOptionPane.showInputDialog(this, "Seleccione valor booleano para la variable: " + nombre, "leer", 3, null, possibilities, null);
/* 26 */       if (s == null) {
/* 27 */         JOptionPane.showMessageDialog(null, "Se debe elegir un valor booleano para la variable : " + nombre, "ERROR", 0);
/* 28 */         throw new Exception("Se debe elegir un valor booleano para la variable : " + nombre);
/*    */       } 
/* 30 */       this.DV.findByName(nombre).setValue(s);
/*    */     } else {
/*    */       
/* 33 */       if (E.getT().getTipo() == 19) {
/* 34 */         String s = (String)JOptionPane.showInputDialog(this, "Ingrese un valor numerico para la variable: " + nombre, "leer", 3, null, null, null);
/* 35 */         if (s != null) {
/*    */           try {
/* 37 */             int x = Integer.parseInt(s);
/* 38 */             System.out.println("la variable desde teclado fue :  " + x);
/* 39 */             System.out.println("el nombre de la varibles es :  " + nombre);
/* 40 */             System.out.println(s);
/* 41 */             this.DV.findByName(nombre).setValue(s);
/*    */             
/*    */             return;
/* 44 */           } catch (Exception e) {
/* 45 */             JOptionPane.showMessageDialog(null, "Se debe elegir un valor numerico para la variable : " + nombre, "ERROR", 0);
/* 46 */             throw new Exception("Se debe elegir un valor numerico para la variable : " + nombre);
/*    */           } 
/*    */         }
/* 49 */         JOptionPane.showMessageDialog(null, "Se debe elegir un valor numerico para la variable : " + nombre, "ERROR", 0);
/* 50 */         throw new Exception("Se debe elegir un valor numerico para la variable : " + nombre);
/*    */       } 
/* 52 */       JOptionPane.showMessageDialog(null, "No existe variable : " + nombre, "ERROR", 0);
/* 53 */       throw new Exception("No existe variable : " + nombre);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\LeerVentana.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */