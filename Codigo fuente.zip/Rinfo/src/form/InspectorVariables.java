/*     */ package form;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.border.TitledBorder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InspectorVariables
/*     */   extends JPanel
/*     */   implements PropertyChangeListener
/*     */ {
/*     */   public Ciudad city;
/*     */   Ventanita vent;
/*     */   JScrollPane ttt;
/*     */   public ArrayList<Datos> datos_robots;
/*     */   JPanel tempPanel;
/*     */   JScrollPane robotsData;
/*     */   RobotsEnEjecucion robotsEnEjecutando;
/*     */   public JPanel tempPanelRobots;
/*     */   
/*     */   public InspectorVariables(Ciudad city) {
/*  36 */     this.datos_robots = new ArrayList<>();
/*  37 */     this.robotsEnEjecutando = new RobotsEnEjecucion(this.datos_robots);
/*  38 */     (this.city = city).addPropertyChangeListener(this);
/*  39 */     for (Robot rr : city.robots) {
/*  40 */       System.out.println("ENTRE");
/*  41 */       Datos tmp = new Datos(this.city, rr);
/*  42 */       rr.addPropertyChangeListener(tmp);
/*  43 */       this.city.addPropertyChangeListener(tmp);
/*  44 */       this.datos_robots.add(tmp);
/*     */     } 
/*  46 */     add(this.tempPanel = form());
/*  47 */     add(this.tempPanelRobots = form2());
/*     */   }
/*     */   
/*     */   public JPanel form() {
/*  51 */     JPanel panel = new JPanel();
/*  52 */     GridBagConstraints gbc = new GridBagConstraints();
/*  53 */     panel.setLayout(new GridBagLayout());
/*  54 */     gbc.gridx = 0;
/*  55 */     gbc.gridy = 0;
/*  56 */     gbc.gridy = 0;
/*  57 */     gbc.fill = 3;
/*  58 */     panel.add(this.ttt = ventanita(), gbc);
/*  59 */     for (int i = 0; i < this.datos_robots.size(); i++) {
/*  60 */       gbc.gridy = i + 2;
/*  61 */       gbc.fill = 1;
/*  62 */       panel.add(this.datos_robots.get(i), gbc);
/*     */     } 
/*  64 */     return panel;
/*     */   }
/*     */   
/*     */   public JScrollPane ventanita() {
/*  68 */     this.vent = new Ventanita(this.city);
/*  69 */     JScrollPane panel = new JScrollPane(this.vent);
/*  70 */     panel.setOpaque(false);
/*  71 */     panel.setBorder(new TitledBorder("Miniatura..."));
/*  72 */     panel.setPreferredSize(new Dimension(212, 228));
/*  73 */     panel.setViewportView(this.vent);
/*  74 */     panel.setHorizontalScrollBarPolicy(31);
/*  75 */     panel.setVerticalScrollBarPolicy(21);
/*  76 */     panel.setVisible(true);
/*  77 */     panel.repaint();
/*  78 */     return panel;
/*     */   }
/*     */ 
/*     */   
/*     */   public void propertyChange(PropertyChangeEvent evt) {
/*  83 */     String propertyName = evt.getPropertyName();
/*  84 */     String propertyValue = evt.getNewValue().toString();
/*  85 */     if (propertyName.equals("numRobots")) {
/*  86 */       int i = Integer.parseInt(propertyValue) - 1;
/*  87 */       GridBagConstraints gbc = new GridBagConstraints();
/*  88 */       Robot rr = this.city.robots.get(i);
/*  89 */       Datos tmp = new Datos(this.city, rr);
/*  90 */       rr.addPropertyChangeListener(tmp);
/*  91 */       this.city.addPropertyChangeListener(tmp);
/*  92 */       this.datos_robots.add(tmp);
/*  93 */       gbc.gridx = 0;
/*  94 */       gbc.fill = 3;
/*  95 */       gbc.gridy = i + 2;
/*  96 */       gbc.fill = 1;
/*  97 */       this.tempPanel.add(this.datos_robots.get(i), gbc);
/*  98 */       this.tempPanel.revalidate();
/*  99 */       ((RobotsEnEjecucion)this.tempPanelRobots).panel.add(this.datos_robots.get(i), gbc);
/*     */     } 
/*     */   }
/*     */   
/*     */   public JPanel form2() {
/* 104 */     this.robotsEnEjecutando.initComponents(this.datos_robots);
/* 105 */     return this.robotsEnEjecutando;
/*     */   }
/*     */   
/*     */   public class RobotsEnEjecucion
/*     */     extends JPanel {
/*     */     public JPanel panel;
/*     */     public JScrollPane scrollPane;
/*     */     
/*     */     public RobotsEnEjecucion(ArrayList<Datos> datos_robots) {
/* 114 */       Dimension dim = getToolkit().getScreenSize();
/* 115 */       dim.width = 230;
/* 116 */       dim.height -= 100;
/* 117 */       setPreferredSize(dim);
/* 118 */       setLayout(new BoxLayout(this, 1));
/* 119 */       initComponents(datos_robots);
/* 120 */       setBorder(new TitledBorder("ROBOTS EN EJECUCION"));
/*     */     }
/*     */     
/*     */     private void initComponents(ArrayList<Datos> datos_robots) {
/* 124 */       (this.panel = new JPanel()).setLayout(new BoxLayout(this.panel, 1));
/* 125 */       (this.scrollPane = new JScrollPane(this.panel)).setBorder(BorderFactory.createEmptyBorder());
/* 126 */       add(this.scrollPane, "Center");
/* 127 */       for (int i = 0; i < datos_robots.size(); i++) {
/* 128 */         this.panel.add(datos_robots.get(i));
/*     */       }
/* 130 */       this.panel.revalidate();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\InspectorVariables.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */