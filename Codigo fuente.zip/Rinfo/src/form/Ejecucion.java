/*    */ package form;
/*    */ 
/*    */ import arbol.Programa;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Ejecucion
/*    */   implements Runnable
/*    */ {
/*    */   Programa prgAST;
/*    */   MonitorActualizarVentana esperarRefresco;
/*    */   boolean pasoAPaso;
/*    */   CodePanel codigo;
/*    */   
/*    */   public Ejecucion(Programa prg, boolean paso_a_paso, CodePanel code) {
/* 19 */     this.prgAST = null;
/* 20 */     this.esperarRefresco = MonitorActualizarVentana.getInstance();
/* 21 */     this.pasoAPaso = false;
/* 22 */     this.pasoAPaso = paso_a_paso;
/* 23 */     this.prgAST = prg;
/* 24 */     this.esperarRefresco.setApretoF7(!paso_a_paso);
/* 25 */     this.esperarRefresco.setPasoAPaso(paso_a_paso);
/* 26 */     this.codigo = code;
/*    */   }
/*    */ 
/*    */   
/*    */   public void run() {
/*    */     try {
/* 32 */       this.esperarRefresco.setEn_ejecucion(true);
/* 33 */       this.prgAST.ejecutar();
/*    */     }
/* 35 */     catch (Exception e) {
/* 36 */       System.out.println(e);
/* 37 */       this.prgAST.getCity().parseError(e.toString());
/*    */       try {
/* 39 */         this.codigo.doStopStepByStep();
/*    */       }
/* 41 */       catch (Exception ex) {
/* 42 */         Logger.getLogger(Ejecucion.class.getName()).log(Level.SEVERE, (String)null, ex);
/*    */       } 
/* 44 */       this.esperarRefresco.setEn_ejecucion(false);
/* 45 */       this.codigo.habilitarTodo();
/*    */     } 
/*    */   }
/*    */   
/*    */   public void dormir() {
/* 50 */     this.esperarRefresco.dormir();
/*    */   }
/*    */   
/*    */   public void arrancar() {
/* 54 */     this.esperarRefresco.arrancar();
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\Ejecucion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */