/*    */ package form;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NodoBinario<T>
/*    */ {
/*    */   private T dato;
/*    */   private NodoBinario<T> hijoIzquierdo;
/*    */   private NodoBinario<T> hijoDerecho;
/*    */   
/*    */   public NodoBinario(T dato) {
/* 14 */     this.dato = dato;
/* 15 */     this.hijoIzquierdo = null;
/* 16 */     this.hijoDerecho = null;
/*    */   }
/*    */   
/*    */   public T getDato() {
/* 20 */     return this.dato;
/*    */   }
/*    */   
/*    */   public NodoBinario<T> getHijoIzquierdo() {
/* 24 */     return this.hijoIzquierdo;
/*    */   }
/*    */   
/*    */   public NodoBinario<T> getHijoDerecho() {
/* 28 */     return this.hijoDerecho;
/*    */   }
/*    */   
/*    */   public void setDato(T dato) {
/* 32 */     this.dato = dato;
/*    */   }
/*    */   
/*    */   public void setHijoIzquierdo(NodoBinario<T> hijoIzq) {
/* 36 */     this.hijoIzquierdo = hijoIzq;
/*    */   }
/*    */   
/*    */   public void setHijoDerecho(NodoBinario<T> hijoDer) {
/* 40 */     this.hijoDerecho = hijoDer;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\NodoBinario.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */