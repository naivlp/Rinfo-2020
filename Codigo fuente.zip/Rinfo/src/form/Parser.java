/*      */ package form;
/*      */ 
/*      */ import arbol.Cuerpo;
/*      */ import arbol.DeclaracionAreas;
/*      */ import arbol.DeclaracionProcesos;
/*      */ import arbol.DeclaracionRobots;
/*      */ import arbol.DeclaracionVariable;
/*      */ import arbol.Identificador;
/*      */ import arbol.ParametroFormal;
/*      */ import arbol.Proceso;
/*      */ import arbol.Programa;
/*      */ import arbol.RobotAST;
/*      */ import arbol.Tipo;
/*      */ import arbol.Variable;
/*      */ import arbol.expresion.Expresion;
/*      */ import arbol.expresion.ExpresionBinaria;
/*      */ import arbol.expresion.ExpresionUnaria;
/*      */ import arbol.expresion.HayFlorEnLaBolsa;
/*      */ import arbol.expresion.HayFlorEnLaEsquina;
/*      */ import arbol.expresion.HayObstaculo;
/*      */ import arbol.expresion.HayPapelEnLaBolsa;
/*      */ import arbol.expresion.HayPapelEnLaEsquina;
/*      */ import arbol.expresion.PosAv;
/*      */ import arbol.expresion.PosCa;
/*      */ import arbol.expresion.ValorBooleano;
/*      */ import arbol.expresion.ValorNumerico;
/*      */ import arbol.expresion.operador.Operador;
/*      */ import arbol.expresion.operador.aritmetico.Division;
/*      */ import arbol.expresion.operador.aritmetico.Multiplicacion;
/*      */ import arbol.expresion.operador.aritmetico.Resta;
/*      */ import arbol.expresion.operador.aritmetico.Suma;
/*      */ import arbol.expresion.operador.booleano.And;
/*      */ import arbol.expresion.operador.booleano.Not;
/*      */ import arbol.expresion.operador.booleano.Or;
/*      */ import arbol.expresion.operador.relacional.Distinto;
/*      */ import arbol.expresion.operador.relacional.Igual;
/*      */ import arbol.expresion.operador.relacional.Mayor;
/*      */ import arbol.expresion.operador.relacional.MayorIgual;
/*      */ import arbol.expresion.operador.relacional.Menor;
/*      */ import arbol.expresion.operador.relacional.MenorIgual;
/*      */ import arbol.llamada.IdentificadorLlamada;
/*      */ import arbol.llamada.Informar;
/*      */ import arbol.llamada.Llamada;
/*      */ import arbol.llamada.Pos;
/*      */ import arbol.sentencia.Asignacion;
/*      */ import arbol.sentencia.Invocacion;
/*      */ import arbol.sentencia.IteradorCondicional;
/*      */ import arbol.sentencia.IteradorIncondicional;
/*      */ import arbol.sentencia.Seleccion;
/*      */ import arbol.sentencia.Sentencia;
/*      */ import arbol.sentencia.primitiva.AsignarArea;
/*      */ import arbol.sentencia.primitiva.BloquearEsquina;
/*      */ import arbol.sentencia.primitiva.DepositarFlor;
/*      */ import arbol.sentencia.primitiva.DepositarPapel;
/*      */ import arbol.sentencia.primitiva.Derecha;
/*      */ import arbol.sentencia.primitiva.EnviarMensaje;
/*      */ import arbol.sentencia.primitiva.Iniciar;
/*      */ import arbol.sentencia.primitiva.Leer;
/*      */ import arbol.sentencia.primitiva.LiberarEsquina;
/*      */ import arbol.sentencia.primitiva.Mover;
/*      */ import arbol.sentencia.primitiva.Primitiva;
/*      */ import arbol.sentencia.primitiva.Random;
/*      */ import arbol.sentencia.primitiva.RecibirMensaje;
/*      */ import arbol.sentencia.primitiva.TomarFlor;
/*      */ import arbol.sentencia.primitiva.TomarPapel;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Stack;
/*      */ import javax.swing.JOptionPane;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Parser
/*      */ {
/*      */   public Token currentToken;
/*      */   private Scanner scanner;
/*      */   Ciudad city;
/*      */   
/*      */   Parser(String fuente, Ciudad city) throws Exception {
/*   84 */     this.city = city;
/*   85 */     this.scanner = new Scanner(fuente);
/*      */     try {
/*   87 */       nextToken();
/*      */     }
/*   89 */     catch (Exception e) {
/*   90 */       reportParseError("Fatal Error!!!");
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean isOperando(Token token) {
/*   95 */     boolean res = false;
/*   96 */     if (token.kind == 23 || token.kind == 32 || token.kind == 33) {
/*   97 */       res = true;
/*      */     }
/*   99 */     return res;
/*      */   }
/*      */   
/*      */   public boolean isVariableEntorno(Token token) {
/*  103 */     switch (token.kind) {
/*      */       case 8:
/*      */       case 9:
/*      */       case 10:
/*      */       case 11:
/*      */       case 12:
/*      */       case 13:
/*      */       case 63:
/*  111 */         return true;
/*      */     } 
/*      */     
/*  114 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isOperador(Token token) {
/*  120 */     boolean res = false;
/*  121 */     switch (token.kind)
/*      */     { case 30:
/*      */       case 45:
/*      */       case 46:
/*      */       case 47:
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*  135 */         res = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  143 */         return res; }  res = false; return res;
/*      */   }
/*      */   
/*      */   public boolean isParentesis(Token token) {
/*  147 */     boolean res = false;
/*  148 */     switch (token.kind)
/*      */     { case 21:
/*      */       case 22:
/*  151 */         res = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  159 */         return res; }  res = false; return res;
/*      */   }
/*      */   
/*      */   public boolean thereIsHighOrEqualPrecedence(Object o) {
/*  163 */     boolean res = true;
/*  164 */     Token t = (Token)o;
/*  165 */     if (t.kind == 21 || (this.currentToken.kind == 49 && t.kind == 50) || (this.currentToken.kind == 49 && t.kind == 51) || ((this.currentToken.kind == 48 || this.currentToken.kind == 47) && (t.kind == 45 || t.kind == 46))) {
/*  166 */       res = false;
/*      */     }
/*  168 */     return res; } public Expresion parseVariableEntorno(Token t) { PosAv posAv; PosCa posCa; HayFlorEnLaBolsa hayFlorEnLaBolsa;
/*      */     HayPapelEnLaBolsa hayPapelEnLaBolsa;
/*      */     HayFlorEnLaEsquina hayFlorEnLaEsquina;
/*      */     HayPapelEnLaEsquina hayPapelEnLaEsquina;
/*  172 */     Expresion expAST = null;
/*  173 */     switch (t.kind)
/*      */     { case 8:
/*  175 */         return (Expresion)new PosAv();
/*      */ 
/*      */       
/*      */       case 9:
/*  179 */         return (Expresion)new PosCa();
/*      */ 
/*      */       
/*      */       case 11:
/*  183 */         return (Expresion)new HayFlorEnLaBolsa();
/*      */ 
/*      */       
/*      */       case 13:
/*  187 */         return (Expresion)new HayPapelEnLaBolsa();
/*      */ 
/*      */       
/*      */       case 10:
/*  191 */         return (Expresion)new HayFlorEnLaEsquina();
/*      */ 
/*      */       
/*      */       case 12:
/*  195 */         return (Expresion)new HayPapelEnLaEsquina();
/*      */ 
/*      */       
/*      */       case 63:
/*  199 */         hayObstaculo = new HayObstaculo();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  207 */         return (Expresion)hayObstaculo; }  HayObstaculo hayObstaculo = null; return (Expresion)hayObstaculo; } public Operador parseOperador(Token t) { Division division; Multiplicacion multiplicacion; Resta resta; Suma suma; And and; Or or; Not not; Distinto distinto; Igual igual;
/*      */     Mayor mayor;
/*      */     MayorIgual mayorIgual;
/*      */     Menor menor;
/*  211 */     Operador expAST = null;
/*  212 */     switch (t.kind)
/*      */     { case 47:
/*  214 */         return (Operador)new Division();
/*      */ 
/*      */       
/*      */       case 48:
/*  218 */         return (Operador)new Multiplicacion();
/*      */ 
/*      */       
/*      */       case 46:
/*  222 */         return (Operador)new Resta();
/*      */ 
/*      */       
/*      */       case 45:
/*  226 */         return (Operador)new Suma();
/*      */ 
/*      */       
/*      */       case 50:
/*  230 */         return (Operador)new And();
/*      */ 
/*      */       
/*      */       case 51:
/*  234 */         return (Operador)new Or();
/*      */ 
/*      */       
/*      */       case 49:
/*  238 */         return (Operador)new Not();
/*      */ 
/*      */       
/*      */       case 54:
/*  242 */         return (Operador)new Distinto();
/*      */ 
/*      */       
/*      */       case 30:
/*  246 */         return (Operador)new Igual();
/*      */ 
/*      */       
/*      */       case 53:
/*  250 */         return (Operador)new Mayor();
/*      */ 
/*      */       
/*      */       case 55:
/*  254 */         return (Operador)new MayorIgual();
/*      */ 
/*      */       
/*      */       case 52:
/*  258 */         return (Operador)new Menor();
/*      */ 
/*      */       
/*      */       case 56:
/*  262 */         menorIgual = new MenorIgual();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  270 */         return (Operador)menorIgual; }  MenorIgual menorIgual = null; return (Operador)menorIgual; }
/*      */ 
/*      */   
/*      */   public boolean isParametroFormal(Token t) {
/*  274 */     return (t.kind == 59 || t.kind == 58 || t.kind == 57);
/*      */   }
/*      */   public Expresion parseValorLiteral(Token t) {
/*      */     ValorNumerico valorNumerico;
/*  278 */     Expresion expAST = null;
/*  279 */     switch (t.kind)
/*      */     { case 23:
/*  281 */         return (Expresion)new ValorNumerico(t.spelling);
/*      */ 
/*      */       
/*      */       case 32:
/*      */       case 33:
/*  286 */         valorBooleano = new ValorBooleano(t.spelling);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  294 */         return (Expresion)valorBooleano; }  ValorBooleano valorBooleano = null; return (Expresion)valorBooleano;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Expresion parseExpresion(DeclaracionVariable DV) throws Exception {
/*      */     // Byte code:
/*      */     //   0: new java/util/Stack
/*      */     //   3: dup
/*      */     //   4: invokespecial <init> : ()V
/*      */     //   7: astore_2
/*      */     //   8: new java/util/Stack
/*      */     //   11: dup
/*      */     //   12: invokespecial <init> : ()V
/*      */     //   15: astore_3
/*      */     //   16: iconst_0
/*      */     //   17: istore #4
/*      */     //   19: aconst_null
/*      */     //   20: astore #5
/*      */     //   22: aload_0
/*      */     //   23: getfield scanner : Lform/Scanner;
/*      */     //   26: getfield fil : I
/*      */     //   29: istore #6
/*      */     //   31: aload_0
/*      */     //   32: getfield currentToken : Lform/Token;
/*      */     //   35: getfield kind : B
/*      */     //   38: ifeq -> 85
/*      */     //   41: aload_0
/*      */     //   42: aload_0
/*      */     //   43: getfield currentToken : Lform/Token;
/*      */     //   46: invokevirtual isVariableEntorno : (Lform/Token;)Z
/*      */     //   49: ifne -> 85
/*      */     //   52: aload_0
/*      */     //   53: aload_0
/*      */     //   54: getfield currentToken : Lform/Token;
/*      */     //   57: invokevirtual isOperando : (Lform/Token;)Z
/*      */     //   60: ifne -> 85
/*      */     //   63: aload_0
/*      */     //   64: aload_0
/*      */     //   65: getfield currentToken : Lform/Token;
/*      */     //   68: invokevirtual isOperador : (Lform/Token;)Z
/*      */     //   71: ifne -> 85
/*      */     //   74: aload_0
/*      */     //   75: aload_0
/*      */     //   76: getfield currentToken : Lform/Token;
/*      */     //   79: invokevirtual isParentesis : (Lform/Token;)Z
/*      */     //   82: ifeq -> 325
/*      */     //   85: aload_0
/*      */     //   86: getfield scanner : Lform/Scanner;
/*      */     //   89: getfield fil : I
/*      */     //   92: iload #6
/*      */     //   94: if_icmpne -> 325
/*      */     //   97: aload_0
/*      */     //   98: aload_0
/*      */     //   99: getfield currentToken : Lform/Token;
/*      */     //   102: invokevirtual isVariableEntorno : (Lform/Token;)Z
/*      */     //   105: ifne -> 129
/*      */     //   108: aload_0
/*      */     //   109: aload_0
/*      */     //   110: getfield currentToken : Lform/Token;
/*      */     //   113: invokevirtual isOperando : (Lform/Token;)Z
/*      */     //   116: ifne -> 129
/*      */     //   119: aload_0
/*      */     //   120: getfield currentToken : Lform/Token;
/*      */     //   123: getfield kind : B
/*      */     //   126: ifne -> 145
/*      */     //   129: aload_0
/*      */     //   130: getfield currentToken : Lform/Token;
/*      */     //   133: astore #5
/*      */     //   135: aload_3
/*      */     //   136: aload #5
/*      */     //   138: invokevirtual push : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   141: pop
/*      */     //   142: goto -> 310
/*      */     //   145: aload_0
/*      */     //   146: aload_0
/*      */     //   147: getfield currentToken : Lform/Token;
/*      */     //   150: invokevirtual isOperador : (Lform/Token;)Z
/*      */     //   153: ifeq -> 205
/*      */     //   156: aload_2
/*      */     //   157: invokevirtual empty : ()Z
/*      */     //   160: ifne -> 193
/*      */     //   163: aload_0
/*      */     //   164: aload_2
/*      */     //   165: invokevirtual peek : ()Ljava/lang/Object;
/*      */     //   168: invokevirtual thereIsHighOrEqualPrecedence : (Ljava/lang/Object;)Z
/*      */     //   171: ifeq -> 193
/*      */     //   174: aload_2
/*      */     //   175: invokevirtual pop : ()Ljava/lang/Object;
/*      */     //   178: checkcast form/Token
/*      */     //   181: astore #5
/*      */     //   183: aload_3
/*      */     //   184: aload #5
/*      */     //   186: invokevirtual push : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   189: pop
/*      */     //   190: goto -> 156
/*      */     //   193: aload_2
/*      */     //   194: aload_0
/*      */     //   195: getfield currentToken : Lform/Token;
/*      */     //   198: invokevirtual push : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   201: pop
/*      */     //   202: goto -> 310
/*      */     //   205: aload_0
/*      */     //   206: getfield currentToken : Lform/Token;
/*      */     //   209: getfield kind : B
/*      */     //   212: bipush #21
/*      */     //   214: if_icmpne -> 229
/*      */     //   217: aload_2
/*      */     //   218: aload_0
/*      */     //   219: getfield currentToken : Lform/Token;
/*      */     //   222: invokevirtual push : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   225: pop
/*      */     //   226: goto -> 310
/*      */     //   229: aload_0
/*      */     //   230: getfield currentToken : Lform/Token;
/*      */     //   233: getfield kind : B
/*      */     //   236: bipush #22
/*      */     //   238: if_icmpeq -> 251
/*      */     //   241: new java/lang/Exception
/*      */     //   244: dup
/*      */     //   245: ldc 'Situación no contemplada en Parser.java: 254'
/*      */     //   247: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   250: athrow
/*      */     //   251: aload_2
/*      */     //   252: invokevirtual empty : ()Z
/*      */     //   255: ifeq -> 261
/*      */     //   258: goto -> 325
/*      */     //   261: aload_2
/*      */     //   262: invokevirtual empty : ()Z
/*      */     //   265: ifne -> 307
/*      */     //   268: aload_2
/*      */     //   269: invokevirtual pop : ()Ljava/lang/Object;
/*      */     //   272: checkcast form/Token
/*      */     //   275: astore #5
/*      */     //   277: aload #5
/*      */     //   279: getfield kind : B
/*      */     //   282: bipush #21
/*      */     //   284: if_icmpeq -> 294
/*      */     //   287: aload_3
/*      */     //   288: aload #5
/*      */     //   290: invokevirtual push : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   293: pop
/*      */     //   294: aload #5
/*      */     //   296: getfield kind : B
/*      */     //   299: bipush #21
/*      */     //   301: if_icmpne -> 261
/*      */     //   304: goto -> 310
/*      */     //   307: iconst_1
/*      */     //   308: istore #4
/*      */     //   310: iload #4
/*      */     //   312: ifeq -> 318
/*      */     //   315: goto -> 325
/*      */     //   318: aload_0
/*      */     //   319: invokevirtual nextToken : ()V
/*      */     //   322: goto -> 31
/*      */     //   325: aload_2
/*      */     //   326: invokevirtual empty : ()Z
/*      */     //   329: ifne -> 351
/*      */     //   332: aload_2
/*      */     //   333: invokevirtual pop : ()Ljava/lang/Object;
/*      */     //   336: checkcast form/Token
/*      */     //   339: astore #5
/*      */     //   341: aload_3
/*      */     //   342: aload #5
/*      */     //   344: invokevirtual push : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   347: pop
/*      */     //   348: goto -> 325
/*      */     //   351: aload_0
/*      */     //   352: aload_3
/*      */     //   353: aload_1
/*      */     //   354: invokevirtual procesarToken : (Ljava/util/Stack;Larbol/DeclaracionVariable;)Larbol/expresion/Expresion;
/*      */     //   357: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #298	-> 0
/*      */     //   #299	-> 8
/*      */     //   #300	-> 16
/*      */     //   #301	-> 19
/*      */     //   #302	-> 22
/*      */     //   #303	-> 31
/*      */     //   #305	-> 97
/*      */     //   #306	-> 129
/*      */     //   #307	-> 135
/*      */     //   #309	-> 145
/*      */     //   #310	-> 156
/*      */     //   #311	-> 174
/*      */     //   #312	-> 183
/*      */     //   #314	-> 193
/*      */     //   #316	-> 205
/*      */     //   #317	-> 217
/*      */     //   #320	-> 229
/*      */     //   #321	-> 241
/*      */     //   #323	-> 251
/*      */     //   #324	-> 258
/*      */     //   #326	-> 261
/*      */     //   #327	-> 268
/*      */     //   #328	-> 277
/*      */     //   #329	-> 287
/*      */     //   #331	-> 294
/*      */     //   #332	-> 304
/*      */     //   #335	-> 307
/*      */     //   #338	-> 310
/*      */     //   #339	-> 315
/*      */     //   #341	-> 318
/*      */     //   #343	-> 325
/*      */     //   #344	-> 332
/*      */     //   #345	-> 341
/*      */     //   #347	-> 351
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	358	0	this	Lform/Parser;
/*      */     //   0	358	1	DV	Larbol/DeclaracionVariable;
/*      */     //   8	350	2	stackOperadores	Ljava/util/Stack;
/*      */     //   16	342	3	salida	Ljava/util/Stack;
/*      */     //   19	339	4	error	Z
/*      */     //   22	336	5	t	Lform/Token;
/*      */     //   31	327	6	fil	I
/*      */     // Local variable type table:
/*      */     //   start	length	slot	name	signature
/*      */     //   8	350	2	stackOperadores	Ljava/util/Stack<Lform/Token;>;
/*      */     //   16	342	3	salida	Ljava/util/Stack<Lform/Token;>;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Expresion procesarToken(Stack<Token> pila, DeclaracionVariable DV) throws Exception {
/*      */     Variable variable;
/*  351 */     Expresion expAST = null;
/*  352 */     Token t = pila.pop();
/*  353 */     if (isOperador(t)) {
/*  354 */       Expresion E1 = null;
/*  355 */       Expresion E2 = null;
/*  356 */       if (!pila.isEmpty()) {
/*  357 */         E2 = procesarToken(pila, DV);
/*      */       }
/*  359 */       if (!pila.isEmpty() && !esUnario(t.kind)) {
/*  360 */         E1 = procesarToken(pila, DV);
/*      */       }
/*  362 */       if (E1 == null) {
/*  363 */         ExpresionUnaria expresionUnaria = new ExpresionUnaria(parseOperador(t), E2);
/*      */       } else {
/*      */         
/*  366 */         ExpresionBinaria expresionBinaria = new ExpresionBinaria(parseOperador(t), E1, E2);
/*      */       }
/*      */     
/*  369 */     } else if (isVariableEntorno(t)) {
/*  370 */       expAST = parseVariableEntorno(t);
/*      */     }
/*  372 */     else if (isOperando(t)) {
/*  373 */       expAST = parseValorLiteral(t);
/*      */     }
/*  375 */     else if (t.kind == 0) {
/*  376 */       variable = new Variable(new Identificador(t.spelling), null, DV, null, null);
/*  377 */       variable.setI(new Identificador(t.spelling));
/*      */     } else {
/*      */       
/*  380 */       System.out.println("Algo anda mal... Parser.java:394");
/*      */     } 
/*  382 */     return (Expresion)variable;
/*      */   }
/*      */   
/*      */   public void reportParseError(String str) {
/*  386 */     JOptionPane.showMessageDialog(null, "línea " + this.scanner.fil + " columna " + this.scanner.col + ": " + str, "Error de compilación ", 0);
/*      */   }
/*      */   
/*      */   public void nextToken() throws Exception {
/*      */     do {
/*  391 */       this.currentToken = this.scanner.scan();
/*  392 */     } while (this.currentToken.kind == 74);
/*      */   }
/*      */   
/*      */   private void take(byte expectedToken) throws Exception {
/*  396 */     if (this.currentToken.kind == expectedToken) {
/*  397 */       nextToken();
/*      */       return;
/*      */     } 
/*  400 */     reportParseError("Se esperaba la palabra clave " + Token.spellings[expectedToken] + " en lugar de " + this.currentToken.spelling);
/*  401 */     throw new Exception();
/*      */   }
/*      */   
/*      */   public void takeIt() throws Exception {
/*  405 */     nextToken();
/*      */   }
/*      */   
/*      */   private Invocacion parseInformar(DeclaracionVariable DV) throws Exception {
/*  409 */     ArrayList<Expresion> E = new ArrayList<>();
/*  410 */     Expresion exp = null;
/*  411 */     String str = "";
/*  412 */     takeIt();
/*  413 */     take((byte)21);
/*  414 */     if (this.currentToken.kind == 78) {
/*  415 */       str = " ";
/*  416 */       takeIt();
/*  417 */       str = this.currentToken.spelling;
/*  418 */       take((byte)0);
/*  419 */       take((byte)78);
/*  420 */       take((byte)24);
/*      */     } 
/*      */     while (true) {
/*  423 */       exp = parseExpresion(DV);
/*  424 */       E.add(exp);
/*  425 */       if (this.currentToken.kind == 24) {
/*  426 */         takeIt();
/*      */       }
/*  428 */       if (this.currentToken.kind == 22) {
/*  429 */         take((byte)22);
/*  430 */         return new Invocacion((Llamada)new Informar(DV, str), E, DV);
/*      */       } 
/*      */     } 
/*      */   } public Invocacion parsePos(DeclaracionVariable DV) throws Exception {
/*  434 */     ArrayList<Expresion> expArray = new ArrayList<>();
/*  435 */     takeIt();
/*  436 */     take((byte)21);
/*  437 */     expArray.add(parseExpresion(DV));
/*  438 */     take((byte)24);
/*  439 */     expArray.add(parseExpresion(DV));
/*  440 */     take((byte)22);
/*  441 */     return new Invocacion((Llamada)new Pos(DV), expArray, DV);
/*      */   }
/*      */   
/*      */   private Asignacion parseAsignacion(String sVariable, DeclaracionVariable DV) throws Exception {
/*  445 */     Identificador I = null;
/*  446 */     Expresion E = null;
/*  447 */     I = new Identificador(sVariable);
/*  448 */     E = parseExpresion(DV);
/*  449 */     return new Asignacion(I, E, DV);
/*      */   }
/*      */   
/*      */   private ArrayList<Sentencia> parseSecuenciaDeSentencias(DeclaracionVariable DV) throws Exception {
/*  453 */     ArrayList<Sentencia> senAST = new ArrayList<>();
/*  454 */     Sentencia sen = null;
/*  455 */     while (this.currentToken.kind != 43 && this.currentToken.kind != 42 && this.currentToken.kind != 18) {
/*  456 */       sen = parseSentencia(DV);
/*  457 */       senAST.add(sen);
/*      */     } 
/*  459 */     return senAST;
/*      */   }
/*      */   
/*      */   private Invocacion parseInvocacionProceso(Token myToken, DeclaracionVariable DV) throws Exception {
/*  463 */     Identificador Ident = new Identificador(myToken.spelling);
/*  464 */     ArrayList<Expresion> E = new ArrayList<>();
/*  465 */     Expresion exp = null;
/*  466 */     if (this.currentToken.kind == 21) {
/*  467 */       takeIt();
/*      */       while (true) {
/*  469 */         exp = parseExpresion(DV);
/*  470 */         E.add(exp);
/*  471 */         if (this.currentToken.kind == 24) {
/*  472 */           takeIt();
/*      */         }
/*  474 */         if (this.currentToken.kind == 22)
/*  475 */         { take((byte)22); break; } 
/*      */       } 
/*  477 */     }  return new Invocacion((Llamada)new IdentificadorLlamada(Ident, DV), E, DV);
/*      */   }
/*      */   
/*      */   private Invocacion parseInvocacion(Token myToken, DeclaracionVariable DV) throws Exception {
/*  481 */     Invocacion invAST = null;
/*  482 */     switch (myToken.kind)
/*      */     { case 14:
/*  484 */         invAST = parseInformar(DV);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  500 */         return invAST;case 15: invAST = parsePos(DV); return invAST;case 0: invAST = parseInvocacionProceso(myToken, DV); return invAST; }  reportParseError("Se esperaba Invocación"); return invAST;
/*      */   }
/*      */   private Sentencia parseSentenciaSimple(DeclaracionVariable DV) throws Exception { Invocacion invocacion;
/*      */     Token sVariable;
/*  504 */     Sentencia senAST = null;
/*  505 */     switch (this.currentToken.kind) {
/*      */       case 14:
/*      */       case 15:
/*  508 */         invocacion = parseInvocacion(this.currentToken, DV);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  526 */         return (Sentencia)invocacion;case 0: sVariable = this.currentToken; takeIt(); if (this.currentToken.kind == 31) { takeIt(); Asignacion asignacion = parseAsignacion(sVariable.spelling, DV); } else { invocacion = parseInvocacion(sVariable, DV); }  return (Sentencia)invocacion;
/*      */     }  throw new Exception("Se esperaba Sentencia Simple"); } private Primitiva parsePrimitiva(DeclaracionVariable DV) throws Exception { LiberarEsquina liberarEsquina; BloquearEsquina bloquearEsquina; Leer leer; Mover mover; Derecha derecha; TomarFlor tomarFlor; TomarPapel tomarPapel; DepositarFlor depositarFlor; DepositarPapel depositarPapel; EnviarMensaje enviarMensaje; RecibirMensaje recibirMensaje; Expresion E1, E3, Ex, E5; Identificador I2, I3; Expresion E2, E4;
/*      */     Identificador I;
/*      */     Expresion E6, E7;
/*  530 */     Primitiva senAST = null;
/*  531 */     switch (this.currentToken.kind)
/*      */     { case 77:
/*  533 */         takeIt();
/*  534 */         take((byte)21);
/*  535 */         E1 = parseExpresion(DV);
/*  536 */         take((byte)24);
/*  537 */         E2 = parseExpresion(DV);
/*  538 */         take((byte)22);
/*  539 */         return (Primitiva)new LiberarEsquina(E1, E2, DV);
/*      */ 
/*      */       
/*      */       case 76:
/*  543 */         takeIt();
/*  544 */         take((byte)21);
/*  545 */         E3 = parseExpresion(DV);
/*  546 */         take((byte)24);
/*  547 */         E4 = parseExpresion(DV);
/*  548 */         take((byte)22);
/*  549 */         return (Primitiva)new BloquearEsquina(E3, E4, DV);
/*      */ 
/*      */       
/*      */       case 75:
/*  553 */         takeIt();
/*  554 */         take((byte)21);
/*  555 */         Ex = parseExpresion(DV);
/*  556 */         take((byte)22);
/*  557 */         return (Primitiva)new Leer(DV, Ex);
/*      */ 
/*      */       
/*      */       case 2:
/*  561 */         mover = new Mover();
/*  562 */         takeIt();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  630 */         return (Primitiva)mover;case 3: derecha = new Derecha(); takeIt(); return (Primitiva)derecha;case 4: tomarFlor = new TomarFlor(); takeIt(); return (Primitiva)tomarFlor;case 5: tomarPapel = new TomarPapel(); takeIt(); return (Primitiva)tomarPapel;case 6: depositarFlor = new DepositarFlor(); takeIt(); return (Primitiva)depositarFlor;case 7: depositarPapel = new DepositarPapel(); takeIt(); return (Primitiva)depositarPapel;
/*      */       case 67: takeIt(); take((byte)21); E5 = parseExpresion(DV); take((byte)24); I = new Identificador(this.currentToken.spelling); takeIt(); take((byte)22); return (Primitiva)new EnviarMensaje(E5, DV, I);
/*      */       case 68: takeIt(); take((byte)21); I2 = new Identificador(this.currentToken.spelling); takeIt(); take((byte)24); I = new Identificador(this.currentToken.spelling); takeIt(); take((byte)22); return (Primitiva)new RecibirMensaje(I2, DV, I);
/*      */       case 79:
/*  634 */         takeIt(); take((byte)21); I3 = new Identificador(this.currentToken.spelling); takeIt(); take((byte)24); E6 = parseExpresion(DV); take((byte)24); E7 = parseExpresion(DV); take((byte)22); return (Primitiva)new Random(I3, DV, E6, E7); }  throw new Exception("Se esperaba una primitiva"); } private Expresion parseVariableSistema() throws Exception { PosCa posCa; PosAv posAv; HayFlorEnLaEsquina hayFlorEnLaEsquina; HayPapelEnLaEsquina hayPapelEnLaEsquina; HayPapelEnLaBolsa hayPapelEnLaBolsa; HayFlorEnLaBolsa hayFlorEnLaBolsa; Expresion senAST = null;
/*  635 */     switch (this.currentToken.kind) {
/*      */       case 9:
/*  637 */         posCa = new PosCa();
/*  638 */         takeIt();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  670 */         return (Expresion)posCa;case 8: posAv = new PosAv(); takeIt(); return (Expresion)posAv;case 10: hayFlorEnLaEsquina = new HayFlorEnLaEsquina(); takeIt(); return (Expresion)hayFlorEnLaEsquina;case 12: hayPapelEnLaEsquina = new HayPapelEnLaEsquina(); takeIt(); return (Expresion)hayPapelEnLaEsquina;case 13: hayPapelEnLaBolsa = new HayPapelEnLaBolsa(); takeIt(); return (Expresion)hayPapelEnLaBolsa;case 11: hayFlorEnLaBolsa = new HayFlorEnLaBolsa(); takeIt(); return (Expresion)hayFlorEnLaBolsa;
/*      */     } 
/*      */     throw new Exception("Se esperaba una variable del sistema"); }
/*      */    public Seleccion parseSi(DeclaracionVariable DV) throws Exception {
/*  674 */     Expresion E = null;
/*  675 */     ArrayList<Sentencia> S1 = null;
/*  676 */     ArrayList<Sentencia> S2 = null;
/*  677 */     takeIt();
/*  678 */     E = parseExpresion(DV);
/*  679 */     take((byte)42);
/*  680 */     S1 = parseSecuenciaDeSentencias(DV);
/*  681 */     take((byte)43);
/*  682 */     if (this.currentToken.kind == 44) {
/*  683 */       takeIt();
/*  684 */       take((byte)42);
/*  685 */       S2 = parseSecuenciaDeSentencias(DV);
/*  686 */       take((byte)43);
/*      */     } 
/*  688 */     return new Seleccion(E, S1, S2, DV);
/*      */   }
/*      */   
/*      */   private IteradorIncondicional parseRepetir(DeclaracionVariable DV) throws Exception {
/*  692 */     Expresion E = null;
/*  693 */     ArrayList<Sentencia> S = null;
/*  694 */     takeIt();
/*  695 */     E = parseExpresion(DV);
/*  696 */     take((byte)42);
/*  697 */     S = parseSecuenciaDeSentencias(DV);
/*  698 */     take((byte)43);
/*  699 */     return new IteradorIncondicional(E, S, DV);
/*      */   }
/*      */   
/*      */   private IteradorCondicional parseMientras(DeclaracionVariable DV) throws Exception {
/*  703 */     Expresion E = null;
/*  704 */     ArrayList<Sentencia> S1 = null;
/*  705 */     takeIt();
/*  706 */     E = parseExpresion(DV);
/*  707 */     take((byte)42);
/*  708 */     S1 = parseSecuenciaDeSentencias(DV);
/*  709 */     take((byte)43);
/*  710 */     return new IteradorCondicional(E, S1, DV);
/*      */   } private Sentencia parseSentenciaCompuesta(DeclaracionVariable DV) throws Exception {
/*      */     Seleccion seleccion;
/*      */     IteradorIncondicional iteradorIncondicional;
/*  714 */     Sentencia senAST = null;
/*  715 */     switch (this.currentToken.kind) {
/*      */       case 34:
/*  717 */         return (Sentencia)parseSi(DV);
/*      */ 
/*      */       
/*      */       case 36:
/*  721 */         return (Sentencia)parseRepetir(DV);
/*      */ 
/*      */       
/*      */       case 37:
/*  725 */         return (Sentencia)parseMientras(DV);
/*      */     } 
/*      */ 
/*      */     
/*  729 */     throw new Exception("Default en parse Sentencia Compuesta");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Sentencia parseSentencia(DeclaracionVariable DV) throws Exception {
/*      */     Primitiva primitiva;
/*  736 */     Sentencia sentencia1, senAST = null;
/*  737 */     switch (this.currentToken.kind) {
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 67:
/*      */       case 68:
/*      */       case 75:
/*      */       case 76:
/*      */       case 77:
/*      */       case 79:
/*  750 */         primitiva = parsePrimitiva(DV);
/*      */ 
/*      */       
/*      */       case 0:
/*      */       case 14:
/*      */       case 15:
/*  756 */         sentencia1 = parseSentenciaSimple(DV);
/*      */ 
/*      */       
/*      */       case 34:
/*      */       case 36:
/*      */       case 37:
/*  762 */         sentencia1 = parseSentenciaCompuesta(DV);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 18:
/*      */       case 43:
/*  773 */         return sentencia1;
/*      */     } 
/*      */     throw new Exception("Error de sentencia " + this.currentToken.spelling + "(" + this.currentToken.kind + ")");
/*      */   } private DeclaracionVariable parseVariables(DeclaracionRobots robAST) throws Exception {
/*  777 */     ArrayList<Variable> varAST = new ArrayList<>();
/*  778 */     String nombre = "pepe";
/*  779 */     String nombreTipoRobot = "";
/*  780 */     byte tipo = 2;
/*  781 */     takeIt();
/*  782 */     take((byte)42);
/*      */     do {
/*  784 */       ArrayList<String> lista = new ArrayList<>();
/*  785 */       while (this.currentToken.kind == 0) {
/*  786 */         if (this.currentToken.kind == 0) {
/*  787 */           nombre = this.currentToken.spelling;
/*  788 */           takeIt();
/*  789 */           lista.add(nombre);
/*      */         } 
/*  791 */         if (this.currentToken.kind == 24) {
/*  792 */           takeIt();
/*      */         }
/*      */       } 
/*  795 */       take((byte)28);
/*  796 */       switch (this.currentToken.kind) {
/*      */         case 19:
/*  798 */           tipo = this.currentToken.kind;
/*  799 */           takeIt();
/*      */           break;
/*      */         
/*      */         case 20:
/*  803 */           tipo = this.currentToken.kind;
/*  804 */           takeIt();
/*      */           break;
/*      */         
/*      */         default:
/*  808 */           if (robAST.estaRobot(this.currentToken.spelling)) {
/*  809 */             tipo = 66;
/*  810 */             nombreTipoRobot = this.currentToken.spelling;
/*  811 */             takeIt();
/*      */             break;
/*      */           } 
/*  814 */           throw new Exception("Error de tipo en declaración de variables");
/*      */       } 
/*      */       
/*  817 */       for (String nombre2 : lista) {
/*      */         Variable var;
/*  819 */         if (tipo != 66) {
/*  820 */           var = new Variable(new Identificador(nombre2), new Tipo(tipo), null, robAST, null);
/*      */         } else {
/*      */           
/*  823 */           var = new Variable(new Identificador(nombre2), new Tipo(tipo), null, robAST, nombreTipoRobot);
/*  824 */           this.city.addRobot(nombre2);
/*      */         } 
/*  826 */         if (estaVariable(varAST, var)) {
/*  827 */           throw new Exception("La Variable " + nombre2 + " ya existe");
/*      */         }
/*  829 */         varAST.add(var);
/*      */       } 
/*  831 */     } while (this.currentToken.kind != 42 && this.currentToken.kind != 43);
/*  832 */     take((byte)43);
/*  833 */     return new DeclaracionVariable(varAST);
/*      */   }
/*      */   
/*      */   public boolean estaVariable(ArrayList<Variable> varAST, Variable var) {
/*  837 */     for (int x = varAST.size(), i = 0; i < x; i++) {
/*  838 */       if (((Variable)varAST.get(i)).getI().toString().equals(var.getI().toString())) {
/*  839 */         return true;
/*      */       }
/*      */     } 
/*  842 */     return false;
/*      */   }
/*      */   
/*      */   private Cuerpo parseCuerpo(DeclaracionVariable varAST) throws Exception {
/*  846 */     Cuerpo cueAST = null;
/*  847 */     ArrayList<Sentencia> senAST = null;
/*  848 */     take((byte)16);
/*  849 */     take((byte)42);
/*  850 */     senAST = parseSecuenciaDeSentencias(varAST);
/*  851 */     cueAST = new Cuerpo(senAST, varAST);
/*  852 */     take((byte)43);
/*  853 */     take((byte)18);
/*  854 */     return cueAST;
/*      */   }
/*      */   
/*      */   private Cuerpo parseCuerpoRobot(DeclaracionVariable varAST, DeclaracionProcesos procAST) throws Exception {
/*  858 */     Cuerpo cueAST = null;
/*  859 */     ArrayList<Sentencia> senAST = new ArrayList<>();
/*  860 */     take((byte)16);
/*  861 */     take((byte)42);
/*  862 */     senAST.addAll(parseSecuenciaDeSentencias(varAST));
/*  863 */     cueAST = new Cuerpo(senAST, varAST);
/*  864 */     take((byte)43);
/*  865 */     take((byte)18);
/*  866 */     return cueAST;
/*      */   }
/*      */   
/*      */   public DeclaracionRobots parseRobots(DeclaracionProcesos procAST) throws Exception {
/*  870 */     DeclaracionRobots robAST = null;
/*  871 */     ArrayList<RobotAST> robArray = new ArrayList<>();
/*  872 */     RobotAST aRobAST = null;
/*  873 */     takeIt();
/*  874 */     take((byte)42);
/*      */     do {
/*  876 */       aRobAST = parseDeclaracionDeUnRobot(procAST);
/*  877 */       robArray.add(aRobAST);
/*  878 */     } while (this.currentToken.kind != 42 && this.currentToken.kind != 43);
/*  879 */     take((byte)43);
/*  880 */     return new DeclaracionRobots(robArray);
/*      */   }
/*      */   
/*      */   public RobotAST parseDeclaracionDeUnRobot(DeclaracionProcesos procAST) throws Exception {
/*  884 */     RobotAST rob = null;
/*  885 */     DeclaracionVariable varAST = new DeclaracionVariable(new ArrayList());
/*  886 */     Cuerpo cueAST = null;
/*  887 */     take((byte)66);
/*  888 */     String nombre = this.currentToken.spelling;
/*  889 */     take((byte)0);
/*  890 */     if (this.currentToken.kind == 17) {
/*  891 */       varAST = parseVariables(null);
/*      */     }
/*  893 */     cueAST = parseCuerpoRobot(varAST, procAST);
/*  894 */     rob = new RobotAST(cueAST, varAST, nombre, procAST);
/*  895 */     rob.setDV(varAST);
/*  896 */     rob.setCuerpo(cueAST);
/*  897 */     return rob;
/*      */   }
/*      */   
/*      */   private DeclaracionProcesos parseProcesos() throws Exception {
/*  901 */     DeclaracionProcesos procAST = null;
/*  902 */     Proceso aProcAST = null;
/*  903 */     ArrayList<Proceso> procArray = new ArrayList<>();
/*  904 */     takeIt();
/*  905 */     take((byte)42);
/*      */     do {
/*  907 */       aProcAST = parseDeclaracionDeUnProceso();
/*  908 */       if (!procArray.isEmpty()) {
/*  909 */         for (Proceso p : procArray) {
/*  910 */           if (p.getI().toString().equals(aProcAST.getI().toString())) {
/*  911 */             throw new Exception("No se puede declarar procesos con el mismo nombre: " + aProcAST.getI().toString());
/*      */           }
/*      */         } 
/*      */       }
/*  915 */       procArray.add(aProcAST);
/*  916 */     } while (this.currentToken.kind != 42 && this.currentToken.kind != 43);
/*  917 */     take((byte)43);
/*  918 */     procAST = new DeclaracionProcesos(procArray);
/*  919 */     return procAST;
/*      */   }
/*      */   
/*      */   private Proceso parseDeclaracionDeUnProceso() throws Exception {
/*  923 */     Identificador I = null;
/*  924 */     Cuerpo C = null;
/*  925 */     ArrayList<ParametroFormal> PF = new ArrayList<>();
/*  926 */     DeclaracionProcesos DP = null;
/*  927 */     DeclaracionVariable DV = new DeclaracionVariable(new ArrayList());
/*  928 */     Proceso procAST = null;
/*  929 */     take((byte)39);
/*  930 */     I = new Identificador(this.currentToken.spelling);
/*  931 */     take((byte)0);
/*  932 */     C = encabezamientoDeProceso(DV, PF);
/*  933 */     procAST = new Proceso(I, PF, DP, DV, C);
/*  934 */     return procAST;
/*      */   }
/*      */   
/*      */   private Cuerpo encabezamientoDeProceso(DeclaracionVariable DV, ArrayList<ParametroFormal> PF) throws Exception {
/*  938 */     Cuerpo cueAST = null;
/*      */     
/*  940 */     if (this.currentToken.kind == 21) {
/*  941 */       takeIt(); while (true) {
/*  942 */         if (isParametroFormal(this.currentToken)) {
/*  943 */           String TA = this.currentToken.spelling;
/*  944 */           takeIt();
/*  945 */           String Ident = this.currentToken.spelling;
/*  946 */           take((byte)0);
/*  947 */           Identificador I = new Identificador(Ident);
/*  948 */           take((byte)28);
/*  949 */           if (this.currentToken.kind != 19 && this.currentToken.kind != 20) {
/*  950 */             throw new Exception("Definir tipo para el parametro formal: " + Ident);
/*      */           }
/*  952 */           Tipo T = new Tipo(this.currentToken.kind);
/*  953 */           takeIt();
/*  954 */           ParametroFormal PFormal = new ParametroFormal(I, T, TA);
/*  955 */           PF.add(PFormal);
/*  956 */           if (this.currentToken.kind == 60) {
/*  957 */             takeIt();
/*      */           }
/*  959 */           if (this.currentToken.kind == 22) {
/*  960 */             take((byte)22); break;
/*      */           } 
/*      */           continue;
/*      */         } 
/*  964 */         throw new Exception("Se esperaba Parametro formal");
/*      */       } 
/*      */     } 
/*  967 */     if (this.currentToken.kind == 17) {
/*  968 */       DeclaracionVariable DV2 = parseVariables(null);
/*  969 */       for (int x = DV2.variables.size(), i = 0; i < x; i++) {
/*  970 */         if (DV.EstaVariable(((Variable)DV2.variables.get(i)).getI().toString())) {
/*  971 */           throw new Exception("No se puede declarar una variable con el mismo nombre que algun parametros");
/*      */         }
/*  973 */         DV.variables.add(DV2.variables.get(i));
/*      */       } 
/*      */     } 
/*  976 */     cueAST = parseCuerpo(DV);
/*  977 */     return cueAST;
/*      */   }
/*      */   
/*      */   public Programa parseProgram(Ciudad city) throws Exception {
/*  981 */     this.city = city;
/*  982 */     Programa proAST = null;
/*  983 */     Identificador ideAST = null;
/*  984 */     DeclaracionVariable varAST = new DeclaracionVariable(new ArrayList());
/*  985 */     DeclaracionProcesos procAST = new DeclaracionProcesos(new ArrayList());
/*  986 */     DeclaracionRobots robAST = new DeclaracionRobots(new ArrayList());
/*  987 */     DeclaracionAreas areasAST = new DeclaracionAreas(new ArrayList());
/*  988 */     Cuerpo cueAST = null;
/*  989 */     take((byte)29);
/*  990 */     System.out.println("Entre al Parse Programa");
/*  991 */     ideAST = new Identificador(this.currentToken.spelling);
/*  992 */     take((byte)0);
/*  993 */     if (this.currentToken.kind == 38) {
/*  994 */       procAST = parseProcesos();
/*      */     }
/*  996 */     System.out.println("Pase Parse Procesos");
/*  997 */     if (this.currentToken.kind == 69) {
/*  998 */       areasAST = parseAreas();
/*      */     }
/* 1000 */     System.out.println("Pase Parse Areas");
/* 1001 */     if (this.currentToken.kind == 65) {
/* 1002 */       robAST = parseRobots(procAST);
/*      */     }
/* 1004 */     System.out.println("Pase Parse Robots");
/* 1005 */     if (this.currentToken.kind == 17) {
/* 1006 */       varAST = parseVariables(robAST);
/*      */     }
/* 1008 */     System.out.println("Pase Parse Variables");
/* 1009 */     cueAST = parseCuerpoPrograma(varAST, robAST);
/* 1010 */     System.out.println("Pase Parse Cuerpo");
/* 1011 */     proAST = new Programa(ideAST, procAST, varAST, robAST, this.city, cueAST, areasAST);
/* 1012 */     return proAST;
/*      */   }
/*      */   
/*      */   public DeclaracionAreas parseAreas() throws Exception {
/* 1016 */     takeIt();
/* 1017 */     take((byte)42);
/* 1018 */     while (this.currentToken.kind == 0) {
/* 1019 */       ArrayList<Expresion> E = new ArrayList<>();
/* 1020 */       String cadena = this.currentToken.spelling;
/* 1021 */       takeIt();
/* 1022 */       take((byte)28);
/* 1023 */       String tipoArea = this.currentToken.spelling;
/* 1024 */       takeIt();
/* 1025 */       take((byte)21);
/* 1026 */       E.add(parseExpresion(null));
/* 1027 */       take((byte)24);
/* 1028 */       E.add(parseExpresion(null));
/* 1029 */       take((byte)24);
/* 1030 */       E.add(parseExpresion(null));
/* 1031 */       take((byte)24);
/* 1032 */       E.add(parseExpresion(null));
/* 1033 */       take((byte)22);
/* 1034 */       int x1 = Integer.valueOf(((Expresion)E.get(0)).getValue(null)).intValue();
/* 1035 */       int x2 = Integer.valueOf(((Expresion)E.get(1)).getValue(null)).intValue();
/* 1036 */       int x3 = Integer.valueOf(((Expresion)E.get(2)).getValue(null)).intValue();
/* 1037 */       int x4 = Integer.valueOf(((Expresion)E.get(3)).getValue(null)).intValue();
/* 1038 */       if (x3 < x1 || x4 < x2 || x1 < 1 || x1 > 100 || x2 < 1 || x1 > 100 || x3 < 1 || x1 > 100 || x4 < 1 || x1 > 100) {
/* 1039 */         throw new Exception("valores no validos para el área");
/*      */       }
/* 1041 */       String s = tipoArea;
/* 1042 */       Area area = null;
/* 1043 */       switch (s) {
/*      */         case "AreaC":
/* 1045 */           area = new AreaC(x1, x2, x3, x4, cadena);
/*      */           break;
/*      */         
/*      */         case "AreaP":
/* 1049 */           area = new AreaP(x1, x2, x3, x4, cadena);
/*      */           break;
/*      */         
/*      */         case "AreaPC":
/* 1053 */           area = new AreaPC(x1, x2, x3, x4, cadena);
/*      */           break;
/*      */         
/*      */         default:
/* 1057 */           throw new Exception("Se esperaba un tipo de área");
/*      */       } 
/*      */       
/* 1060 */       for (Area a : this.city.areas) {
/* 1061 */         if (a.getName().equals(cadena)) {
/* 1062 */           throw new Exception("No se puede declarar dos areas con el mismo nombre");
/*      */         }
/* 1064 */         if (x2 <= a.getCa2() && x2 >= a.getCa1() && x1 <= a.getAv2() && x1 >= a.getAv1()) {
/* 1065 */           throw new Exception("No se puede declarar el área: " + cadena + ", al menos una calle coincide con el área: " + a.getName());
/*      */         }
/*      */       } 
/* 1068 */       this.city.areas.add(area);
/*      */     } 
/* 1070 */     take((byte)43);
/* 1071 */     return new DeclaracionAreas(this.city.areas);
/*      */   }
/*      */   
/*      */   public Programa parse() throws Exception {
/* 1075 */     Programa prgAST = null;
/* 1076 */     prgAST = parseProgram(this.city);
/* 1077 */     return prgAST;
/*      */   }
/*      */   
/*      */   private boolean esUnario(byte kind) {
/* 1081 */     return (kind == 49);
/*      */   }
/*      */   
/*      */   private Cuerpo parseCuerpoPrograma(DeclaracionVariable varAST, DeclaracionRobots robAST) throws Exception {
/* 1085 */     ArrayList<Sentencia> senAST = new ArrayList<>();
/* 1086 */     take((byte)16);
/* 1087 */     take((byte)42);
/* 1088 */     while (this.currentToken.kind == 73) {
/* 1089 */       takeIt();
/* 1090 */       take((byte)21);
/* 1091 */       Robot robo = this.city.getRobotByNombre(this.currentToken.spelling);
/* 1092 */       takeIt();
/* 1093 */       take((byte)24);
/* 1094 */       Area area = this.city.getAreaByNombre(this.currentToken.spelling);
/* 1095 */       takeIt();
/* 1096 */       take((byte)22);
/* 1097 */       AsignarArea asignarArea = new AsignarArea(robo, area);
/* 1098 */       senAST.add(asignarArea);
/*      */     } 
/* 1100 */     while (this.currentToken.kind == 1) {
/* 1101 */       ArrayList<Expresion> E = new ArrayList<>();
/* 1102 */       takeIt();
/* 1103 */       take((byte)21);
/* 1104 */       Identificador nomRobot = new Identificador(this.currentToken.spelling);
/* 1105 */       take((byte)0);
/* 1106 */       take((byte)24);
/* 1107 */       E.add(parseExpresion(varAST));
/* 1108 */       take((byte)24);
/* 1109 */       E.add(parseExpresion(varAST));
/* 1110 */       take((byte)22);
/* 1111 */       Iniciar iniciar = new Iniciar(nomRobot, Integer.parseInt(((Expresion)E.get(0)).getValue(varAST)), Integer.parseInt(((Expresion)E.get(1)).getValue(varAST)), robAST, varAST);
/* 1112 */       senAST.add(iniciar);
/*      */     } 
/* 1114 */     take((byte)43);
/* 1115 */     take((byte)18);
/* 1116 */     return new Cuerpo(senAST, varAST);
/*      */   }
/*      */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\Parser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */