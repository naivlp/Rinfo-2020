/*    */ package form;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.AbstractCellEditor;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JColorChooser;
/*    */ import javax.swing.JDialog;
/*    */ import javax.swing.JTable;
/*    */ import javax.swing.table.TableCellEditor;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ColorEditor
/*    */   extends AbstractCellEditor
/*    */   implements TableCellEditor, ActionListener
/*    */ {
/*    */   Color currentColor;
/*    */   JButton button;
/*    */   JColorChooser colorChooser;
/*    */   JDialog dialog;
/*    */   protected static final String EDIT = "edit";
/*    */   
/*    */   public ColorEditor() {
/* 27 */     (this.button = new JButton()).setActionCommand("edit");
/* 28 */     this.button.addActionListener(this);
/* 29 */     this.button.setBorderPainted(false);
/* 30 */     this.colorChooser = new JColorChooser();
/* 31 */     this.dialog = JColorChooser.createDialog(this.button, "Seleccione un color", true, this.colorChooser, this, null);
/*    */   }
/*    */ 
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 36 */     if ("edit".equals(e.getActionCommand())) {
/* 37 */       this.button.setBackground(this.currentColor);
/* 38 */       this.colorChooser.setColor(this.currentColor);
/* 39 */       this.dialog.setVisible(true);
/* 40 */       fireEditingStopped();
/*    */     } else {
/*    */       
/* 43 */       this.currentColor = this.colorChooser.getColor();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getCellEditorValue() {
/* 49 */     return this.currentColor;
/*    */   }
/*    */ 
/*    */   
/*    */   public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
/* 54 */     this.currentColor = (Color)value;
/* 55 */     return this.button;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\ColorEditor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */