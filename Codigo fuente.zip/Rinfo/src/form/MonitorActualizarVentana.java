/*     */ package form;
/*     */ 
/*     */ import java.util.concurrent.locks.Condition;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MonitorActualizarVentana
/*     */ {
/*     */   private CityScroll jsp;
/*     */   private static MonitorActualizarVentana instance;
/*     */   private final ReentrantLock lock;
/*     */   final Condition condicion;
/*     */   final Condition pause;
/*     */   private int cant_robots;
/*     */   private boolean en_ejecucion;
/*     */   private boolean[] resultado;
/*     */   Condition[] espera;
/*     */   private boolean apretoF7;
/*     */   final Condition barrera;
/*     */   private boolean pasoAPaso;
/*     */   private int bar;
/*     */   private int cant_ejecutandose;
/*     */   private boolean timerOn;
/*     */   private int dormidos;
/*     */   private int time;
/*     */   private boolean sistemaPausado;
/*     */   
/*     */   public int getBar() {
/*  32 */     return this.bar;
/*     */   }
/*     */   
/*     */   public void setBar(int bar) {
/*  36 */     this.bar = bar;
/*     */   }
/*     */   
/*     */   public int getDormidos() {
/*  40 */     return this.dormidos;
/*     */   }
/*     */   
/*     */   public void setDormidos(int dormidos) {
/*  44 */     this.dormidos = dormidos;
/*     */   }
/*     */   
/*     */   public boolean isTimerOn() {
/*  48 */     return this.timerOn;
/*     */   }
/*     */   
/*     */   public void setTimerOn(boolean timerOn) {
/*  52 */     this.timerOn = timerOn;
/*     */   }
/*     */   
/*     */   public boolean isSistemaPausado() {
/*  56 */     return this.sistemaPausado;
/*     */   }
/*     */   
/*     */   public void setSistemaPausado(boolean sistemaPausado) {
/*  60 */     this.sistemaPausado = sistemaPausado;
/*     */   }
/*     */   
/*     */   public void setSpeed(int t) {
/*  64 */     this.time = t;
/*     */   }
/*     */   
/*     */   private MonitorActualizarVentana(int cant) {
/*  68 */     this.lock = new ReentrantLock();
/*  69 */     this.condicion = this.lock.newCondition();
/*  70 */     this.pause = this.lock.newCondition();
/*  71 */     this.cant_robots = 0;
/*  72 */     this.en_ejecucion = false;
/*  73 */     this.apretoF7 = false;
/*  74 */     this.barrera = this.lock.newCondition();
/*  75 */     this.pasoAPaso = false;
/*  76 */     this.bar = 0;
/*  77 */     this.cant_ejecutandose = 0;
/*  78 */     this.timerOn = false;
/*  79 */     this.dormidos = 0;
/*  80 */     this.time = 165;
/*  81 */     this.sistemaPausado = false;
/*  82 */     setCant_robots(cant);
/*  83 */     setCant_ejecutandose(cant);
/*  84 */     setDormidos(0);
/*  85 */     this.espera = new Condition[cant];
/*  86 */     this.resultado = new boolean[cant];
/*  87 */     for (int i = 0; i < cant; i++) {
/*  88 */       this.espera[i] = this.lock.newCondition();
/*  89 */       this.resultado[i] = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setCityScroll(CityScroll jsp) {
/*  94 */     this.jsp = jsp;
/*     */   }
/*     */   
/*     */   public void setCantidad(int cant) {
/*  98 */     setCant_robots(cant);
/*  99 */     setCant_ejecutandose(cant);
/* 100 */     setDormidos(0);
/* 101 */     this.espera = new Condition[cant];
/* 102 */     this.resultado = new boolean[cant];
/* 103 */     for (int i = 0; i < cant; i++) {
/* 104 */       this.espera[i] = this.lock.newCondition();
/* 105 */       this.resultado[i] = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void startTimer() {
/* 110 */     setTimerOn(true);
/* 111 */     waitAgain();
/*     */   }
/*     */   
/*     */   private void waitAgain() {
/*     */     try {
/* 116 */       Thread.sleep(this.time);
/*     */     }
/* 118 */     catch (InterruptedException interruptedException) {}
/* 119 */     if (!this.sistemaPausado) {
/* 120 */       despertar();
/*     */     }
/* 122 */     if (isTimerOn()) {
/* 123 */       waitAgain();
/*     */     }
/*     */   }
/*     */   
/*     */   public int getCant_ejecutandose() {
/* 128 */     return this.cant_ejecutandose;
/*     */   }
/*     */   
/*     */   public void setCant_ejecutandose(int cant_ejecutandose) {
/* 132 */     this.cant_ejecutandose = cant_ejecutandose;
/*     */   }
/*     */   
/*     */   public boolean isEn_ejecucion() {
/* 136 */     return this.en_ejecucion;
/*     */   }
/*     */   
/*     */   public void setEn_ejecucion(boolean en_ejecucion) {
/* 140 */     this.en_ejecucion = en_ejecucion;
/*     */   }
/*     */   
/*     */   public boolean isPasoAPaso() {
/* 144 */     return this.pasoAPaso;
/*     */   }
/*     */   
/*     */   public void setPasoAPaso(boolean pasoAPaso) {
/* 148 */     this.pasoAPaso = pasoAPaso;
/*     */   }
/*     */   
/*     */   public boolean isApretoF7() {
/* 152 */     return this.apretoF7;
/*     */   }
/*     */   
/*     */   public void setApretoF7(boolean apretoF7) {
/* 156 */     this.apretoF7 = apretoF7;
/*     */   }
/*     */   
/*     */   public int getCant_robots() {
/* 160 */     return this.cant_robots;
/*     */   }
/*     */   
/*     */   public void setCant_robots(int cant_robots) {
/* 164 */     this.cant_robots = cant_robots;
/*     */   }
/*     */   
/*     */   public static MonitorActualizarVentana getInstance() {
/* 168 */     return instance;
/*     */   }
/*     */   
/*     */   public static MonitorActualizarVentana crearMonitorActualizarVentana(int cantidadClientes) {
/* 172 */     return instance = new MonitorActualizarVentana(cantidadClientes);
/*     */   }
/*     */   
/*     */   public void esperaMensaje() {
/* 176 */     this.lock.lock();
/*     */     try {
/* 178 */       if (getCant_ejecutandose() - getBar() == 1) {
/* 179 */         this.barrera.signalAll();
/*     */       }
/* 181 */       setCant_ejecutandose(getCant_ejecutandose() - 1);
/* 182 */       setDormidos(getDormidos() + 1);
/*     */     } finally {
/*     */       
/* 185 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void esperaEsquina() {
/* 190 */     this.lock.lock();
/*     */     try {
/* 192 */       if (this.cant_ejecutandose - this.bar == 1) {
/* 193 */         this.barrera.signalAll();
/*     */       }
/* 195 */       this.cant_ejecutandose--;
/*     */     } finally {
/*     */       
/* 198 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void esperar(int id) {
/* 203 */     this.lock.lock();
/*     */     try {
/* 205 */       while (!this.apretoF7) {
/* 206 */         this.espera[id].await();
/*     */       }
/* 208 */       setBar(getBar() + 1);
/* 209 */       if (getBar() < getCant_ejecutandose()) {
/* 210 */         this.barrera.await();
/*     */       } else {
/*     */         
/* 213 */         this.barrera.signalAll();
/* 214 */         setApretoF7(false);
/* 215 */         setBar(0);
/*     */       }
/*     */     
/* 218 */     } catch (InterruptedException e) {
/* 219 */       System.out.println("Interrupted Exc ");
/* 220 */       throw new RuntimeException();
/*     */     } finally {
/*     */       
/* 223 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void pintarRuta(Robot r) throws Exception {
/* 228 */     this.lock.lock();
/*     */     try {
/* 230 */       this.jsp.jc.dibujarRuta(r);
/* 231 */       this.jsp.city.form.compedos.iv.vent.dibujarRuta(r);
/*     */     } finally {
/*     */       
/* 234 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void dormir() {
/* 239 */     this.lock.lock();
/*     */     try {
/* 241 */       this.pause.await();
/*     */     }
/* 243 */     catch (InterruptedException e) {
/* 244 */       System.out.println("Interrupted Exc ");
/* 245 */       throw new RuntimeException();
/*     */     } finally {
/*     */       
/* 248 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void arrancar() {
/* 253 */     this.lock.lock();
/*     */     try {
/* 255 */       this.pause.signal();
/*     */     } finally {
/*     */       
/* 258 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void despertar() {
/* 263 */     this.lock.lock();
/*     */     try {
/* 265 */       setApretoF7(true);
/* 266 */       for (int i = 0; i < this.cant_robots; i++) {
/* 267 */         this.espera[i].signal();
/*     */       }
/*     */     } finally {
/*     */       
/* 271 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void despertarPause() {
/* 276 */     this.lock.lock();
/*     */     try {
/* 278 */       this.sistemaPausado = false;
/*     */     } finally {
/*     */       
/* 281 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean termine_ejecucion() {
/* 286 */     this.lock.lock();
/*     */     try {
/* 288 */       System.out.println("Termine ejecucion");
/* 289 */       boolean resultado = false;
/* 290 */       int canti = getCant_ejecutandose();
/* 291 */       setCant_ejecutandose(getCant_ejecutandose() - 1);
/* 292 */       resultado = (getCant_ejecutandose() == 0 && getDormidos() == 0);
/* 293 */       System.out.println("ejecutandose 0 y dormidos 0,el resultado es : " + resultado);
/* 294 */       if (getBar() == getCant_ejecutandose()) {
/* 295 */         System.out.println("termine y desperte a todos ");
/* 296 */         this.barrera.signalAll();
/* 297 */         setBar(0);
/*     */       } 
/* 299 */       return resultado;
/*     */     } finally {
/*     */       
/* 302 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void pausar_ejecucion() {
/* 307 */     this.lock.lock();
/*     */     try {
/* 309 */       this.sistemaPausado = true;
/*     */     } finally {
/*     */       
/* 312 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\MonitorActualizarVentana.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */