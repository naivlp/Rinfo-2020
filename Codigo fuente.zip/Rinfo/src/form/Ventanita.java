/*    */ package form;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Point;
/*    */ import java.awt.event.MouseEvent;
/*    */ import java.awt.event.MouseWheelEvent;
/*    */ import javax.swing.JViewport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Ventanita
/*    */   extends CiudadView
/*    */ {
/*    */   private int rectanguloAncho;
/*    */   private int rectanguloAlto;
/*    */   int xCoord;
/*    */   int yCoord;
/*    */   
/*    */   public Ventanita(Ciudad city) {
/* 21 */     super(city);
/* 22 */     setBlockSize(1);
/*    */   }
/*    */   
/*    */   public int getXrect() {
/* 26 */     JViewport vp = this.city.form.jsp.getViewport();
/* 27 */     Point p = vp.getViewPosition();
/* 28 */     CiudadView cv = (CiudadView)vp.getComponent(0);
/* 29 */     int nx = (int)(p.x / cv.getWidth2() * getWidth2());
/* 30 */     return nx;
/*    */   }
/*    */   
/*    */   public int getYrect() {
/* 34 */     JViewport vp = this.city.form.jsp.getViewport();
/* 35 */     Point p = vp.getViewPosition();
/* 36 */     CiudadView cv = (CiudadView)vp.getComponent(0);
/* 37 */     int ny = (int)(p.y / cv.getHeight2() * getHeight2());
/* 38 */     return ny;
/*    */   }
/*    */   
/*    */   public int getRectWidth() {
/* 42 */     return this.rectanguloAncho;
/*    */   }
/*    */   
/*    */   public int getRectHeight() {
/* 46 */     return this.rectanguloAlto;
/*    */   }
/*    */   
/*    */   public void updateRectWidth() {
/* 50 */     double blockVisible = this.city.form.jsp.jc.getVisibleRect().getWidth() / this.city.form.jsp.jc.getWidth2();
/* 51 */     this.rectanguloAncho = (int)(getWidth2() * blockVisible);
/*    */   }
/*    */   
/*    */   public void updateRectHeight() {
/* 55 */     double blockVisible = this.city.form.jsp.jc.getVisibleRect().getHeight() / this.city.form.jsp.jc.getHeight2();
/* 56 */     this.rectanguloAlto = (int)(getHeight2() * blockVisible);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void dibujarCiudad() throws Exception {
/* 61 */     dibujarCiudadVentanita();
/* 62 */     updateRectHeight();
/* 63 */     updateRectWidth();
/* 64 */     this.lienzo.setColor(Color.black);
/* 65 */     this.lienzo.drawRect(getXrect(), getYrect(), getRectWidth(), getRectHeight());
/*    */   }
/*    */ 
/*    */   
/*    */   protected void dibujarRuta(Robot robot) {
/* 70 */     this.xCoord = Av2x(robot.PosAv()) - getBlockSize() / 2;
/* 71 */     this.yCoord = Ca2y(robot.PosCa()) - getBlockSize() / 2;
/* 72 */     this.lienzo.setColor(robot.getColor());
/* 73 */     if (this.yCoord != 201) {
/* 74 */       this.lienzo.fillOval(this.xCoord, this.yCoord, 4, 4);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void mouseClicked(MouseEvent e) {
/* 80 */     double x = (e.getX() - getRectWidth() / 2) / getWidth();
/* 81 */     double y = (e.getY() - getRectHeight() / 2) / getHeight();
/* 82 */     this.city.form.jsp.view(x, y);
/*    */   }
/*    */   
/*    */   public void Camarita() {
/* 86 */     double x = (this.xCoord - getRectWidth() / 2) / getWidth();
/* 87 */     double y = (this.yCoord - getRectHeight() / 2) / getHeight();
/* 88 */     this.city.form.jsp.view(x, y);
/*    */   }
/*    */   
/*    */   public void mouseWheelMoved(MouseWheelEvent e) {}
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\Ventanita.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */