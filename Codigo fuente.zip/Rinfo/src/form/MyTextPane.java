/*     */ package form;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.KeyStroke;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.event.DocumentListener;
/*     */ import javax.swing.event.UndoableEditEvent;
/*     */ import javax.swing.text.AbstractDocument;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.Element;
/*     */ import javax.swing.undo.CannotUndoException;
/*     */ import javax.swing.undo.UndoManager;
/*     */ 
/*     */ class MyTextPane
/*     */   extends JScrollPane
/*     */   implements DocumentListener {
/*     */   public myTextBox text;
/*     */   private JTextArea lines;
/*     */   private int linesCount;
/*     */   Ciudad city;
/*     */   MyLinePainter painter;
/*     */   public String contiene;
/*     */   
/*     */   public MyTextPane(Ciudad city) {
/*  32 */     this.city = city;
/*  33 */     this.text = new myTextBox(city, this);
/*  34 */     this.text.getDocument().addDocumentListener(this);
/*  35 */     this.text.addKeyListener(this.text);
/*  36 */     final UndoManager undo = new UndoManager();
/*  37 */     Document doc = this.text.getDocument();
/*  38 */     doc.addUndoableEditListener(evt -> {
/*     */           if (!evt.getEdit().toString().contains("Styled")) {
/*     */             undo.addEdit(evt.getEdit());
/*     */           }
/*     */         });
/*  43 */     this.text.getActionMap().put("Undo", new AbstractAction("Undo")
/*     */         {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             try {
/*  47 */               if (undo.canUndo()) {
/*  48 */                 undo.undo();
/*  49 */                 if (MyTextPane.this.text.getDocument().getLength() == 0) {
/*  50 */                   undo.redo();
/*     */                 }
/*     */               } 
/*  53 */             } catch (CannotUndoException cannotUndoException) {}
/*     */           }
/*     */         });
/*     */ 
/*     */     
/*  58 */     this.text.getInputMap().put(KeyStroke.getKeyStroke("control Z"), "Undo");
/*     */     
/*  60 */     this.text.getActionMap().put("Redo", new AbstractAction("Redo")
/*     */         {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             try {
/*  64 */               if (undo.canRedo()) {
/*  65 */                 undo.redo();
/*     */               }
/*  67 */             } catch (CannotUndoException cannotUndoException) {}
/*     */           }
/*     */         });
/*     */ 
/*     */     
/*  72 */     this.text.getInputMap().put(KeyStroke.getKeyStroke("control R"), "Redo");
/*     */ 
/*     */     
/*  75 */     this.painter = new MyLinePainter(this.text, new Color(233, 239, 248, 255));
/*  76 */     ((AbstractDocument)this.text.getDocument()).setDocumentFilter(new DocumentTabFilter());
/*  77 */     this.lines = new JTextArea("  1.");
/*  78 */     this.linesCount = 1;
/*  79 */     this.lines.setBackground(new Color(233, 232, 226, 255));
/*  80 */     this.lines.setEditable(false);
/*     */     try {
/*  82 */       this.lines.setFont(new Font("JetBrainsMono-Bold", 0, 13));
/*  83 */       this.text.setFont(new Font("JetBrainsMono-Bold", 0, 13));
/*     */     }
/*  85 */     catch (Exception ex) {
/*  86 */       this.lines.setFont(new Font("Monospaced", 0, 13));
/*  87 */       this.text.setFont(new Font("Monospaced", 0, 13));
/*     */     } 
/*  89 */     this.lines.setBorder(BorderFactory.createMatteBorder(3, 0, 0, 1, Color.LIGHT_GRAY));
/*  90 */     getViewport().add(this.text);
/*  91 */     setRowHeaderView(this.lines);
/*     */   }
/*     */   
/*     */   void setText(String t) {
/*  95 */     this.text.setText(t);
/*  96 */     setLineNumbers();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getText() {
/* 103 */     return this.text.getText();
/*     */   }
/*     */   
/*     */   String getText(int offs, int len) throws BadLocationException {
/* 107 */     return this.text.getText(offs, len);
/*     */   }
/*     */   
/*     */   int getCaretPosition() {
/* 111 */     return this.text.getCaretPosition();
/*     */   }
/*     */   
/*     */   public void setCaretPosition(int position) {
/* 115 */     this.text.setCaretPosition(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void changedUpdate(DocumentEvent de) {}
/*     */ 
/*     */   
/*     */   public void insertUpdate(DocumentEvent de) {
/* 124 */     setLineNumbers();
/* 125 */     updateSyntaxHighlighting();
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeUpdate(DocumentEvent de) {
/* 130 */     setLineNumbers();
/* 131 */     updateSyntaxHighlighting();
/*     */   }
/*     */   
/*     */   public void setLineNumbers() {
/* 135 */     Element root = this.text.getDocument().getDefaultRootElement();
/* 136 */     int untilLine = root.getElementCount();
/* 137 */     int chars = (untilLine > 99) ? ("" + untilLine).length() : 3;
/* 138 */     String t = "         1".substring(10 - chars) + ".";
/* 139 */     if (untilLine != this.linesCount) {
/* 140 */       this.linesCount = untilLine;
/* 141 */       for (int i = 2; i <= untilLine; i++) {
/* 142 */         String tmp = "          " + i;
/* 143 */         t = t + "\n" + tmp.substring(tmp.length() - chars) + ".";
/*     */       } 
/* 145 */       this.lines.setText(t);
/* 146 */       this.lines.setCaretPosition(0);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void updateSyntaxHighlighting() {
/* 151 */     Element root = this.text.getDocument().getDefaultRootElement();
/* 152 */     int paragraph = root.getElementIndex(this.text.getCaretPosition());
/* 153 */     int from = root.getElement(paragraph).getStartOffset();
/* 154 */     int length = root.getElement(paragraph).getEndOffset() - from;
/* 155 */     this.text.updateStyles(from, length);
/*     */   }
/*     */   
/*     */   Object getDocument() {
/* 159 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\MyTextPane.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */