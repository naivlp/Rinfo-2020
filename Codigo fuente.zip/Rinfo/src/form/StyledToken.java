/*     */ package form;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import javax.swing.text.SimpleAttributeSet;
/*     */ import javax.swing.text.StyleConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StyledToken
/*     */ {
/*     */   String spelling;
/*     */   byte kind;
/*     */   int from;
/*     */   SimpleAttributeSet attributes;
/*     */   
/*     */   StyledToken(byte currentKind, int from, String spelling, boolean ok, boolean comillas) {
/*  37 */     this.kind = currentKind;
/*  38 */     this.spelling = spelling;
/*  39 */     this.from = from;
/*  40 */     this.attributes = new SimpleAttributeSet();
/*  41 */     this.spelling = spelling.replace("\r", " ");
/*  42 */     if (ok) {
/*  43 */       StyleConstants.setForeground(this.attributes, new Color(100, 100, 100, 255));
/*     */     }
/*  45 */     else if (comillas) {
/*  46 */       StyleConstants.setForeground(this.attributes, new Color(253, 1, 254, 255));
/*     */     } else {
/*     */       
/*  49 */       if (this.kind == IDENTIFER) {
/*  50 */         for (String type : primitivas) {
/*  51 */           if (type.equals(spelling)) {
/*  52 */             this.kind = PRIMITIVA;
/*  53 */             StyleConstants.setItalic(this.attributes, true);
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/*  58 */       if (this.kind == IDENTIFER) {
/*  59 */         for (String type : variables) {
/*  60 */           if (type.equals(spelling)) {
/*  61 */             this.kind = VARIABLE;
/*  62 */             StyleConstants.setForeground(this.attributes, new Color(0, 153, 0, 255));
/*     */           } 
/*     */         } 
/*     */       }
/*  66 */       if (this.kind == IDENTIFER) {
/*  67 */         for (String type : palabrasClave) {
/*  68 */           if (type.equals(spelling)) {
/*  69 */             this.kind = PALABRACLAVE;
/*  70 */             StyleConstants.setBold(this.attributes, true);
/*  71 */             StyleConstants.setForeground(this.attributes, Color.RED);
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/*  76 */       if (this.kind == IDENTIFER) {
/*  77 */         if ("V".equals(spelling)) {
/*  78 */           this.kind = LITERAL;
/*     */         }
/*  80 */         if ("F".equals(spelling)) {
/*  81 */           this.kind = LITERAL;
/*     */         }
/*     */       } 
/*  84 */       if (this.kind == IDENTIFER) {
/*  85 */         for (String type : tipoVariable) {
/*  86 */           if (type.equals(spelling)) {
/*  87 */             this.kind = TIPOVARIABLE;
/*  88 */             StyleConstants.setForeground(this.attributes, new Color(0, 0, 230, 255));
/*     */           } 
/*     */         } 
/*     */       }
/*  92 */       if (this.kind == IDENTIFER) {
/*  93 */         for (String type : areas) {
/*  94 */           if (type.equals(spelling)) {
/*  95 */             this.kind = AREA;
/*  96 */             StyleConstants.setBold(this.attributes, true);
/*     */           } 
/*     */         } 
/*     */       }
/* 100 */       if (this.kind == LITERAL) {
/* 101 */         StyleConstants.setForeground(this.attributes, new Color(253, 1, 254, 255));
/*     */       }
/* 103 */       if (this.kind == COMENTARIO) {
/* 104 */         StyleConstants.setForeground(this.attributes, new Color(100, 100, 100, 255));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public SimpleAttributeSet getAttributes() {
/* 110 */     return this.attributes;
/*     */   }
/*     */   
/*     */   public int getFrom() {
/* 114 */     return this.from;
/*     */   }
/*     */   
/*     */   public int getLength() {
/* 118 */     return this.spelling.length();
/*     */   }
/*     */ 
/*     */   
/* 122 */   static byte IDENTIFER = 0;
/* 123 */   static byte OPERADOR = 1;
/* 124 */   static byte LITERAL = 2;
/* 125 */   static byte PRIMITIVA = 3;
/* 126 */   static byte VARIABLE = 4;
/* 127 */   static byte PALABRACLAVE = 5;
/* 128 */   static byte TIPOVARIABLE = 6;
/* 129 */   static byte COMENTARIO = 7;
/* 130 */   static byte EOF = 8;
/* 131 */   static byte AREA = 9;
/* 132 */   public static final String[] spellings = new String[] { "IDENTIFICADOR", "OPERADOR", "LITERAL", "PRIMITIVA", "VARIABLE", "PALABRACLAVE", "FIN DE ARCHIVO" };
/* 133 */   public static final String[] primitivas = new String[] { "EnviarMensaje", "RecibirMensaje", "BloquearEsquina", "LiberarEsquina", "Pos", "Informar", "AsignarArea", "Iniciar", "Leer", "Random", "mover", "derecha", "tomarFlor", "tomarPapel", "depositarFlor", "depositarPapel" };
/* 134 */   public static final String[] variables = new String[] { "PosAv", "PosCa", "HayFlorEnLaEsquina", "HayFlorEnLaBolsa", "HayPapelEnLaEsquina", "HayPapelEnLaBolsa", "HayObstaculo" };
/* 135 */   public static final String[] palabrasClave = new String[] { "comenzar", "variables", "fin", "programa", "procesos", "proceso", "ES", "S", "E", "areas", "robots", "robot" };
/* 136 */   public static final String[] areas = new String[] { "AreaP", "AreaC", "AreaPC" };
/* 137 */   public static final String[] tipoVariable = new String[] { "numero", "boolean" };
/* 138 */   public static final String[] comentario = new String[] { "{", "}" };
/*     */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\StyledToken.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */