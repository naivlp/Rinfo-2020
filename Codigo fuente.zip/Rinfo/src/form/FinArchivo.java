package form;

class FinArchivo extends Exception {}


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\FinArchivo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */