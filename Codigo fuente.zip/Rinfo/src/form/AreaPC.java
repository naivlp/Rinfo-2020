/*    */ package form;
/*    */ 
/*    */ import java.awt.Color;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AreaPC
/*    */   extends Area
/*    */ {
/*    */   public AreaPC(int ca1, int av1, int ca2, int av2, String name) {
/* 12 */     super(ca1, av1, ca2, av2, name);
/* 13 */     this.color = Color.ORANGE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\AreaPC.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */