/*    */ package form;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import javax.swing.BorderFactory;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JTable;
/*    */ import javax.swing.border.Border;
/*    */ import javax.swing.table.TableCellRenderer;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ColorRenderer
/*    */   extends JLabel
/*    */   implements TableCellRenderer
/*    */ {
/*    */   Border unselectedBorder;
/*    */   Border selectedBorder;
/*    */   boolean isBordered;
/*    */   
/*    */   public ColorRenderer(boolean isBordered) {
/* 22 */     this.unselectedBorder = null;
/* 23 */     this.selectedBorder = null;
/* 24 */     this.isBordered = true;
/* 25 */     this.isBordered = isBordered;
/* 26 */     setOpaque(true);
/*    */   }
/*    */ 
/*    */   
/*    */   public Component getTableCellRendererComponent(JTable table, Object color, boolean isSelected, boolean hasFocus, int row, int column) {
/* 31 */     Color newColor = (Color)color;
/* 32 */     setBackground(newColor);
/* 33 */     if (this.isBordered) {
/* 34 */       if (isSelected) {
/* 35 */         if (this.selectedBorder == null) {
/* 36 */           this.selectedBorder = BorderFactory.createMatteBorder(2, 5, 2, 5, table.getSelectionBackground());
/*    */         }
/* 38 */         setBorder(this.selectedBorder);
/*    */       } else {
/*    */         
/* 41 */         if (this.unselectedBorder == null) {
/* 42 */           this.unselectedBorder = BorderFactory.createMatteBorder(2, 5, 2, 5, table.getBackground());
/*    */         }
/* 44 */         setBorder(this.unselectedBorder);
/*    */       } 
/*    */     }
/* 47 */     setToolTipText("RGB value: " + newColor.getRed() + ", " + newColor.getGreen() + ", " + newColor.getBlue());
/* 48 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\ColorRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */