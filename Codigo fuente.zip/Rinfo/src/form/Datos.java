/*     */ package form;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Image;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.border.TitledBorder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Datos
/*     */   extends JPanel
/*     */   implements PropertyChangeListener
/*     */ {
/*     */   Ciudad city;
/*  47 */   JTextField lab5 = new JTextField("Av"); JLabel lab2; JLabel lab1; JLabel lab11; JLabel lab12; JLabel lab13; JLabel lab14;
/*  48 */   JTextField lab6 = new JTextField("Ca"); JLabel lab15; JLabel lab16; JLabel lab17; JLabel lab18; JLabel estado; ImageIcon icon;
/*  49 */   JLabel lab0 = new JLabel(); PanelImg pa; Robot x;
/*  50 */   Color C = Color.red; Datos(Ciudad city, Robot x) {
/*  51 */     Dimension dim = new Dimension(200, 100);
/*  52 */     setMaximumSize(dim);
/*  53 */     this.city = city;
/*  54 */     this.x = x;
/*  55 */     this.lab5.setText(Integer.toString(x.Av));
/*  56 */     this.lab6.setText(String.valueOf(x.Ca));
/*  57 */     GridBagConstraints gbc = new GridBagConstraints();
/*  58 */     setLayout(new GridBagLayout());
/*  59 */     setBorder(new TitledBorder(x.getNombre()));
/*  60 */     this.lab1 = new JLabel("Pos:");
/*  61 */     this.lab2 = new JLabel("(0" + x.PosAv() + " , 0" + x.PosCa() + ")");
/*  62 */     JLabel lab3 = new JLabel("Bolsa   ");
/*  63 */     JLabel lab4 = new JLabel("Esquina");
/*  64 */     (this.lab11 = new JLabel()).setText("F  ");
/*  65 */     this.lab11.setForeground(x.getColor());
/*  66 */     this.lab11.setOpaque(true);
/*  67 */     this.lab12 = new JLabel("P ");
/*  68 */     (this.lab13 = new JLabel()).setForeground(x.getColor());
/*  69 */     this.lab13.setText("F  ");
/*  70 */     this.lab14 = new JLabel("P ");
/*  71 */     (this.lab15 = new JLabel()).setForeground(x.getColor());
/*  72 */     this.lab15.setText("00");
/*  73 */     this.lab16 = new JLabel("00");
/*  74 */     (this.lab17 = new JLabel()).setForeground(x.getColor());
/*  75 */     this.lab17.setText("00");
/*  76 */     this.lab18 = new JLabel("00");
/*  77 */     (this.estado = new JLabel()).setText("Nuevo  ");
/*  78 */     int dir = x.getDireccion();
/*  79 */     switch (dir) {
/*     */       case 90:
/*  81 */         this.icon = new ImageIcon(getClass().getResource("/images/robotArriba.png"));
/*     */         break;
/*     */       
/*     */       case 270:
/*  85 */         this.icon = new ImageIcon(getClass().getResource("/images/robotAbajo.png"));
/*     */         break;
/*     */       
/*     */       case 0:
/*  89 */         this.icon = new ImageIcon(getClass().getResource("/images/robotDerecha.png"));
/*     */         break;
/*     */       
/*     */       default:
/*  93 */         this.icon = new ImageIcon(getClass().getResource("/images/robotIzquierda.png"));
/*     */         break;
/*     */     } 
/*     */     
/*  97 */     Image img = this.icon.getImage();
/*  98 */     Image newimg = img.getScaledInstance(16, 16, 4);
/*  99 */     ImageIcon newIcon = new ImageIcon(newimg);
/* 100 */     (this.pa = new PanelImg(newimg)).setMaximumSize(new Dimension(16, 16));
/* 101 */     this.pa.setMinimumSize(new Dimension(16, 16));
/* 102 */     this.pa.setPreferredSize(new Dimension(16, 16));
/* 103 */     this.pa.setBackground(x.color);
/* 104 */     gbc.gridwidth = 1;
/* 105 */     gbc.gridheight = 1;
/* 106 */     gbc.gridy = 0;
/* 107 */     gbc.gridx = 0;
/* 108 */     gbc.gridwidth = 2;
/* 109 */     add(this.pa, gbc);
/* 110 */     gbc.gridwidth = 2;
/* 111 */     gbc.gridx = 2;
/* 112 */     add(this.lab1, gbc);
/* 113 */     gbc.gridwidth = 1;
/* 114 */     gbc.gridx = 4;
/* 115 */     add(this.lab2, gbc);
/* 116 */     gbc.gridy = 1;
/* 117 */     gbc.gridwidth = 2;
/* 118 */     gbc.gridx = 0;
/* 119 */     add(lab3, gbc);
/* 120 */     gbc.gridx = 2;
/* 121 */     add(lab4, gbc);
/* 122 */     gbc.gridwidth = 1;
/* 123 */     gbc.gridx = 0;
/* 124 */     gbc.gridy = 2;
/* 125 */     add(this.lab11, gbc);
/* 126 */     gbc.gridx = 1;
/* 127 */     gbc.gridy = 2;
/* 128 */     add(this.lab12, gbc);
/* 129 */     gbc.gridx = 2;
/* 130 */     gbc.gridy = 2;
/* 131 */     add(this.lab13, gbc);
/* 132 */     gbc.gridx = 3;
/* 133 */     gbc.gridy = 2;
/* 134 */     add(this.lab14, gbc);
/* 135 */     gbc.gridx = 0;
/* 136 */     gbc.gridy = 3;
/* 137 */     add(this.lab15, gbc);
/* 138 */     gbc.gridx = 1;
/* 139 */     gbc.gridy = 3;
/* 140 */     add(this.lab16, gbc);
/* 141 */     gbc.gridx = 2;
/* 142 */     gbc.gridy = 3;
/* 143 */     add(this.lab17, gbc);
/* 144 */     gbc.gridx = 3;
/* 145 */     gbc.gridy = 3;
/* 146 */     add(this.lab18, gbc);
/* 147 */     gbc.gridwidth = 4;
/* 148 */     gbc.gridx = 0;
/* 149 */     gbc.gridy = 4;
/* 150 */     add(this.estado, gbc);
/*     */   }
/*     */   
/*     */   public void setAv(String str) {
/* 154 */     str = convert(str);
/* 155 */     this.lab5.setText(str);
/* 156 */     this.lab2.setText("(" + this.lab5.getText() + " , " + this.lab6.getText() + ")");
/* 157 */     this.city.form.repaint();
/*     */   }
/*     */   
/*     */   public String convert(String str) {
/* 161 */     if (str.equals("1")) {
/* 162 */       str = "01";
/*     */     }
/* 164 */     if (str.equals("2")) {
/* 165 */       str = "02";
/*     */     }
/* 167 */     if (str.equals("3")) {
/* 168 */       str = "03";
/*     */     }
/* 170 */     if (str.equals("4")) {
/* 171 */       str = "04";
/*     */     }
/* 173 */     if (str.equals("5")) {
/* 174 */       str = "05";
/*     */     }
/* 176 */     if (str.equals("6")) {
/* 177 */       str = "06";
/*     */     }
/* 179 */     if (str.equals("7")) {
/* 180 */       str = "07";
/*     */     }
/* 182 */     if (str.equals("8")) {
/* 183 */       str = "08";
/*     */     }
/* 185 */     if (str.equals("9")) {
/* 186 */       str = "09";
/*     */     }
/* 188 */     if (str.equals("0")) {
/* 189 */       str = "00";
/*     */     }
/* 191 */     return str;
/*     */   }
/*     */   
/*     */   public void setFloresEsq(String num) {
/* 195 */     num = convert(num);
/* 196 */     this.lab17.setText(num);
/* 197 */     this.city.form.repaint();
/*     */   }
/*     */   
/*     */   public void setPapelesEsq(String num) {
/* 201 */     num = convert(num);
/* 202 */     this.lab18.setText(num);
/* 203 */     this.city.form.repaint();
/*     */   }
/*     */   
/*     */   public void setFloresBolsa(String num) {
/* 207 */     num = convert(num);
/* 208 */     this.lab15.setText(num);
/* 209 */     this.city.form.repaint();
/*     */   }
/*     */   
/*     */   public void setPapelesBolsa(String num) {
/* 213 */     num = convert(num);
/* 214 */     this.lab16.setText(num);
/* 215 */     this.city.form.repaint();
/*     */   }
/*     */   
/*     */   public void setCa(String str) {
/* 219 */     str = convert(str);
/* 220 */     this.lab6.setText(str);
/* 221 */     this.lab2.setText("(" + this.lab5.getText() + " , " + this.lab6.getText() + ")");
/* 222 */     this.city.form.repaint();
/*     */   }
/*     */   
/*     */   public void setIcon(int dir) {
/* 226 */     switch (dir) {
/*     */       case 90:
/* 228 */         this.icon = new ImageIcon(getClass().getResource("/images/robotArriba.png"));
/*     */         break;
/*     */       
/*     */       case 270:
/* 232 */         this.icon = new ImageIcon(getClass().getResource("/images/robotAbajo.png"));
/*     */         break;
/*     */       
/*     */       case 0:
/* 236 */         this.icon = new ImageIcon(getClass().getResource("/images/robotDerecha.png"));
/*     */         break;
/*     */       
/*     */       default:
/* 240 */         this.icon = new ImageIcon(getClass().getResource("/images/robotIzquierda.png"));
/*     */         break;
/*     */     } 
/*     */     
/* 244 */     Image img = this.icon.getImage();
/* 245 */     Image newimg = img.getScaledInstance(16, 16, 4);
/* 246 */     ImageIcon newIcon = new ImageIcon(newimg);
/* 247 */     this.lab0.setIcon(newIcon);
/* 248 */     this.lab0.setIcon(newIcon);
/* 249 */     this.pa.setImage(newimg);
/* 250 */     this.city.form.repaint();
/*     */   }
/*     */ 
/*     */   
/*     */   public void propertyChange(PropertyChangeEvent evt) {
/* 255 */     String propertyName = evt.getPropertyName();
/* 256 */     String propertyValue = evt.getNewValue().toString();
/* 257 */     if (propertyName.equals("av")) {
/* 258 */       setAv(propertyValue);
/* 259 */       setCa(Integer.toString(this.x.Ca));
/* 260 */       int flores = this.city.getFlores(this.x.PosAv(), this.x.PosCa());
/* 261 */       setFloresEsq(Integer.toString(flores));
/* 262 */       int papeles = this.city.getPapeles(this.x.PosAv(), this.x.PosCa());
/* 263 */       setPapelesEsq(Integer.toString(papeles));
/*     */     }
/* 265 */     else if (propertyName.equals("ca")) {
/* 266 */       setCa(propertyValue);
/* 267 */       setAv(Integer.toString(this.x.Av));
/* 268 */       int flores = this.city.getFlores(this.x.PosAv(), this.x.PosCa());
/* 269 */       setFloresEsq(Integer.toString(flores));
/* 270 */       int papeles = this.city.getPapeles(this.x.PosAv(), this.x.PosCa());
/* 271 */       setPapelesEsq(Integer.toString(papeles));
/*     */     }
/* 273 */     else if (propertyName.equals("direccion")) {
/* 274 */       setIcon(Integer.parseInt(propertyValue));
/*     */     }
/* 276 */     else if (propertyName.equals("flores")) {
/* 277 */       int flores = this.city.getFlores(this.x.PosAv(), this.x.PosCa());
/* 278 */       setFloresEsq(Integer.toString(flores));
/* 279 */       setFloresBolsa(propertyValue);
/*     */     }
/* 281 */     else if (propertyName.equals("papeles")) {
/* 282 */       setPapelesBolsa(propertyValue);
/* 283 */       int papeles2 = this.city.getPapeles(this.x.PosAv(), this.x.PosCa());
/* 284 */       setPapelesEsq(Integer.toString(papeles2));
/*     */     }
/* 286 */     else if (propertyName.equals("EsquinaPapeles")) {
/* 287 */       int papeles2 = this.city.getPapeles(this.x.PosAv(), this.x.PosCa());
/* 288 */       setPapelesEsq(Integer.toString(papeles2));
/*     */     }
/* 290 */     else if (propertyName.equals("EsquinaFlores")) {
/* 291 */       int flores = this.city.getFlores(this.x.PosAv(), this.x.PosCa());
/* 292 */       setFloresEsq(Integer.toString(flores));
/*     */     }
/* 294 */     else if (propertyName.equals("color")) {
/* 295 */       this.pa.setBackground((Color)evt.getNewValue());
/* 296 */       this.C = (Color)evt.getNewValue();
/*     */     }
/* 298 */     else if (propertyName.equals("estado")) {
/* 299 */       System.out.println(evt.getOldValue());
/* 300 */       this.estado.setText((String)evt.getNewValue());
/* 301 */       repaint();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\Datos.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */