/*     */ package form;
/*     */ 
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.datatransfer.Clipboard;
/*     */ import java.awt.datatransfer.DataFlavor;
/*     */ import java.awt.datatransfer.StringSelection;
/*     */ import java.awt.datatransfer.Transferable;
/*     */ import java.awt.datatransfer.UnsupportedFlavorException;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.KeyListener;
/*     */ import java.awt.geom.Line2D;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JTextPane;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.filechooser.FileNameExtensionFilter;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.DefaultEditorKit;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.StyledDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class myTextBox
/*     */   extends JTextPane
/*     */   implements KeyListener
/*     */ {
/*     */   StyledDocument doc;
/*     */   StyledScan scanner;
/*     */   Ciudad city;
/*     */   MyTextPane mtp;
/*     */   MonitorActualizarVentana esperarRefresco;
/*     */   String path;
/*     */   
/*     */   public void setText(String t) {
/*  49 */     super.setText(t);
/*  50 */     this.mtp.setLineNumbers();
/*  51 */     updateStyles(0, t.length());
/*     */   }
/*     */   
/*     */   public int getLengthText() {
/*  55 */     return getText().length();
/*     */   }
/*     */   
/*     */   public myTextBox(Ciudad city, MyTextPane mtp) {
/*  59 */     this.esperarRefresco = MonitorActualizarVentana.getInstance();
/*  60 */     this.city = city;
/*  61 */     this.mtp = mtp;
/*  62 */     this.path = "";
/*     */     try {
/*  64 */       this.path = (new File(".")).getCanonicalPath();
/*     */     }
/*  66 */     catch (IOException ex) {
/*  67 */       Logger.getLogger(InspectorVariables.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   void appendAtCaretPosition(String str) {
/*  72 */     StyledDocument sdoc = getStyledDocument();
/*     */     try {
/*  74 */       sdoc.insertString(getCaretPosition(), str, null);
/*     */     }
/*  76 */     catch (BadLocationException ex) {
/*  77 */       Logger.getLogger(myTextBox.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void keyTyped(KeyEvent e) {
/*  83 */     if (e.getKeyChar() == '\n')
/*     */       try {
/*  85 */         String mySpaces = "";
/*     */         int c;
/*     */         String txt;
/*  88 */         for (c = getCaretPosition(), txt = getText(0, c), c -= 2; c >= 0 && txt.charAt(c) != '\n'; c--);
/*  89 */         for (; txt.charAt(++c) == ' '; c++) {
/*  90 */           mySpaces = mySpaces + " ";
/*     */         }
/*  92 */         appendAtCaretPosition(mySpaces);
/*     */       }
/*  94 */       catch (BadLocationException ex) {
/*  95 */         System.out.println("BadLocationException del keyTyped");
/*  96 */         Logger.getLogger(MyTextPane.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */       }  
/*     */   }
/*     */   
/* 100 */   static String archivoactual = CodePanel.archivoactual;
/*     */   void doSaveCommand() {
/* 102 */     archivoactual = CodePanel.archivoactual;
/* 103 */     if (archivoactual.equals("")) {
/* 104 */       doSaveAsCommand();
/*     */     }
/*     */     else {
/*     */       
/* 108 */       Writer out = null;
/*     */       try {
/*     */         try {
/* 111 */           out = new OutputStreamWriter(new FileOutputStream(archivoactual), "UTF-8");
/* 112 */           out.write(getText());
/*     */         } finally {
/* 114 */           out.close();
/*     */         } 
/* 116 */       } catch (Exception exception) {}
/*     */     } 
/*     */   }
/*     */   
/*     */   public void doSaveAsCommand() {
/* 121 */     JFileChooser chooser = new JFileChooser(this.path);
/* 122 */     FileNameExtensionFilter filter = new FileNameExtensionFilter("R-Info", new String[] { "rinfo" });
/* 123 */     chooser.setFileFilter(filter);
/*     */     
/* 125 */     if (chooser.showSaveDialog(this) == 0) {
/*     */       File fFileName;
/* 127 */       if ("Archivo RINFO".equals(chooser.getTypeDescription(chooser.getSelectedFile()))) {
/* 128 */         fFileName = chooser.getSelectedFile();
/*     */       } else {
/*     */         
/* 131 */         fFileName = new File(chooser.getSelectedFile() + ".rinfo");
/*     */       } 
/*     */       
/* 134 */       archivoactual = fFileName.getName();
/* 135 */       Writer out = null;
/*     */       try {
/*     */         try {
/* 138 */           out = new OutputStreamWriter(new FileOutputStream(fFileName), "UTF-8");
/* 139 */           out.write(getText());
/*     */         } finally {
/* 141 */           out.close();
/*     */         } 
/* 143 */       } catch (Exception exception) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void keyPressed(KeyEvent e) {
/* 149 */     String texto = "";
/* 150 */     if (e.getKeyCode() == 118) {
/* 151 */       this.esperarRefresco.despertar();
/*     */     }
/* 153 */     if (e.isControlDown() && e.getKeyCode() == 83) {
/* 154 */       doSaveCommand();
/*     */     }
/* 156 */     if (e.isControlDown() && e.getKeyCode() == 86) {
/* 157 */       Clipboard cb = Toolkit.getDefaultToolkit().getSystemClipboard();
/* 158 */       Transferable t = cb.getContents(this);
/*     */       try {
/* 160 */         DataFlavor dataFlavorStringJava = new DataFlavor("text/plain;class=java.lang.String");
/* 161 */         if (t.isDataFlavorSupported(dataFlavorStringJava)) {
/*     */           try {
/* 163 */             String str = (String)t.getTransferData(dataFlavorStringJava);
/* 164 */             String fin = System.getProperty("line.separator");
/* 165 */             str = str.replace(fin, "\n");
/* 166 */             String[] ss = str.split("\n");
/* 167 */             StringSelection strSel = new StringSelection(str);
/* 168 */             cb.setContents(strSel, null);
/* 169 */             (new DefaultEditorKit.PasteAction()).actionPerformed(null);
/* 170 */             this.mtp.updateSyntaxHighlighting();
/* 171 */             e.consume();
/*     */           }
/* 173 */           catch (UnsupportedFlavorException ex) {
/* 174 */             System.out.println("error CadePanel L 107x");
/* 175 */             Logger.getLogger(myTextBox.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */           }
/* 177 */           catch (IOException ex2) {
/* 178 */             System.out.println("error CadePanel L 107x");
/* 179 */             Logger.getLogger(myTextBox.class.getName()).log(Level.SEVERE, (String)null, ex2);
/*     */           }
/*     */         
/*     */         }
/* 183 */       } catch (ClassNotFoundException ex3) {
/* 184 */         System.out.println("error CadePanel L 107x");
/* 185 */         Logger.getLogger(myTextBox.class.getName()).log(Level.SEVERE, (String)null, ex3);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void keyReleased(KeyEvent e) {}
/*     */ 
/*     */   
/*     */   public void paintComponent(Graphics g) {
/* 195 */     super.paintComponent(g);
/* 196 */     Document sdoc = getDocument();
/* 197 */     String txt = "";
/* 198 */     ArrayList<Integer> spaces = new ArrayList<>();
/* 199 */     int len = sdoc.getLength();
/*     */     try {
/* 201 */       txt = sdoc.getText(0, len);
/*     */     }
/* 203 */     catch (BadLocationException ble) {
/* 204 */       System.out.println("BadLocationException del paintComponent en CODEPANEL");
/*     */     } 
/* 206 */     boolean contarEspacios = false;
/* 207 */     int esp = 0; int c;
/* 208 */     for (c = 0; c < txt.length(); c++) {
/* 209 */       switch (txt.charAt(c)) {
/*     */         case '\n':
/* 211 */           if (contarEspacios) {
/* 212 */             while (esp > 0) {
/* 213 */               if (esp % 2 == 0) {
/* 214 */                 spaces.remove(spaces.size() - 1);
/*     */               }
/* 216 */               esp--;
/*     */             } 
/*     */           }
/* 219 */           contarEspacios = true;
/* 220 */           esp = 0;
/*     */           break;
/*     */         
/*     */         case ' ':
/* 224 */           if (contarEspacios && ++esp % 2 == 0) {
/* 225 */             spaces.add(new Integer(c));
/*     */           }
/*     */           break;
/*     */ 
/*     */         
/*     */         case '\r':
/* 231 */           System.out.println("BARRA R");
/*     */           break;
/*     */         
/*     */         default:
/* 235 */           contarEspacios = false;
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 240 */     if (contarEspacios) {
/* 241 */       for (c = esp; c > 0; c--) {
/* 242 */         if (c % 2 == 0) {
/* 243 */           spaces.remove(spaces.size() - 1);
/*     */         }
/*     */       } 
/*     */     }
/* 247 */     Graphics2D g2 = (Graphics2D)g;
/* 248 */     g2.setColor(new Color(219, 219, 219, 255));
/* 249 */     g2.setStroke(new BasicStroke(1.0F));
/* 250 */     for (Integer space : spaces) {
/*     */       try {
/* 252 */         Rectangle r = modelToView(space.intValue());
/* 253 */         g2.setColor(new Color(255, 255, 255, 255));
/* 254 */         g2.draw(new Line2D.Double((r.x + 1), r.y, (r.x + 6), r.y));
/* 255 */         g2.setColor(new Color(200, 200, 200, 255));
/* 256 */         g2.draw(new Line2D.Double((r.x + 1), r.y, (r.x + 1), r.y + r.getHeight()));
/* 257 */         g2.draw(new Line2D.Double((r.x + 1), r.y + r.getHeight(), (r.x + 6), r.y + r.getHeight()));
/*     */       }
/* 259 */       catch (BadLocationException ex) {
/* 260 */         Logger.getLogger(MyTextPane.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void updateStyles(int from, int length) {
/* 266 */     if (length > 0) {
/* 267 */       this.doc = getStyledDocument();
/* 268 */       this.scanner = null;
/* 269 */       final int lastFrom = from;
/*     */       try {
/* 271 */         String xx = this.doc.getText(from, length);
/* 272 */         this.scanner = new StyledScan(xx, this.city);
/*     */       }
/* 274 */       catch (BadLocationException ex) {
/* 275 */         System.out.println("BadLocationException Exception");
/* 276 */         Logger.getLogger(MyTextPane.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */       } 
/* 278 */       if (this.scanner != null) {
/* 279 */         SwingUtilities.invokeLater(new Runnable()
/*     */             {
/*     */               public void run() {
/* 282 */                 myTextBox.this.parseStyles(lastFrom);
/*     */               }
/*     */             });
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void parseStyles(int lastFrom) {
/*     */     try {
/*     */       StyledToken tkn;
/* 292 */       while ((tkn = this.scanner.scan()).kind != StyledToken.EOF) {
/* 293 */         this.doc.setCharacterAttributes(lastFrom + tkn.getFrom(), tkn.getLength(), tkn.getAttributes(), true);
/*     */       }
/*     */     }
/* 296 */     catch (Exception ex) {
/* 297 */       Logger.getLogger(MyTextPane.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\myTextBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */