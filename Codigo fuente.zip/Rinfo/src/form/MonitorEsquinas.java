/*    */ package form;
/*    */ 
/*    */ import java.util.concurrent.locks.Condition;
/*    */ import java.util.concurrent.locks.ReentrantLock;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MonitorEsquinas
/*    */ {
/* 21 */   private final ReentrantLock lock = new ReentrantLock();
/* 22 */   final Condition condicion = this.lock.newCondition();
/* 23 */   MonitorActualizarVentana esperarRefresco = MonitorActualizarVentana.getInstance();
/* 24 */   final Condition barrera = this.lock.newCondition();
/* 25 */   Condition[][] espera = new Condition[101][101];
/* 26 */   private boolean[][] libre = new boolean[101][101]; private MonitorEsquinas() {
/* 27 */     for (int i = 1; i <= 100; i++) {
/* 28 */       for (int j = 1; j <= 100; j++) {
/* 29 */         this.espera[i][j] = this.lock.newCondition();
/* 30 */         this.libre[i][j] = true;
/*    */       } 
/*    */     } 
/*    */   }
/*    */   private static MonitorEsquinas instance;
/*    */   public static MonitorEsquinas getInstance() {
/* 36 */     return instance;
/*    */   }
/*    */   
/*    */   public static MonitorEsquinas crearMonitorEsquinas() {
/* 40 */     return instance = new MonitorEsquinas();
/*    */   }
/*    */   
/*    */   public void bloquear(int Av, int Ca) {
/* 44 */     this.lock.lock();
/*    */     try {
/* 46 */       System.out.println("Entre al bloquear");
/* 47 */       if (this.libre[Av][Ca]) {
/* 48 */         this.libre[Av][Ca] = false;
/*    */       } else {
/*    */         
/* 51 */         this.esperarRefresco.esperaEsquina();
/* 52 */         while (!this.libre[Av][Ca]) {
/* 53 */           this.espera[Av][Ca].await();
/*    */         }
/* 55 */         this.libre[Av][Ca] = false;
/* 56 */         this.esperarRefresco.setCant_ejecutandose(this.esperarRefresco.getCant_ejecutandose() + 1);
/*    */       } 
/* 58 */       System.out.println("Sali del bloquear");
/*    */     }
/* 60 */     catch (InterruptedException e) {
/* 61 */       System.out.println("Interrupted Exc ");
/* 62 */       throw new RuntimeException();
/*    */     } finally {
/*    */       
/* 65 */       this.lock.unlock();
/*    */     } 
/*    */   }
/*    */   
/*    */   public void liberar(int Av, int Ca) {
/* 70 */     this.lock.lock();
/*    */     try {
/* 72 */       this.libre[Av][Ca] = true;
/* 73 */       this.espera[Av][Ca].signalAll();
/*    */     } finally {
/*    */       
/* 76 */       this.lock.unlock();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\MonitorEsquinas.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */