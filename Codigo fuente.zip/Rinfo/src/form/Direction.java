package form;

public class Direction {
  public static final int EAST = 0;
  
  public static final int NORTH = 90;
  
  public static final int WEAST = 180;
  
  public static final int SOUTH = 270;
}


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\Direction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */