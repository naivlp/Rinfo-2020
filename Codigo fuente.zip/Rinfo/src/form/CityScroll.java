/*    */ package form;
/*    */ 
/*    */ import java.awt.Rectangle;
/*    */ import javax.swing.JScrollBar;
/*    */ import javax.swing.JScrollPane;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CityScroll
/*    */   extends JScrollPane
/*    */ {
/*    */   public Ciudad city;
/*    */   public CiudadView jc;
/*    */   MonitorActualizarVentana esperarRefresco;
/*    */   
/*    */   public CityScroll(Ciudad city) {
/* 19 */     this.esperarRefresco = MonitorActualizarVentana.getInstance();
/* 20 */     this.city = city;
/* 21 */     setViewportView(this.jc = new CiudadView(this.city));
/* 22 */     repaint();
/*    */   }
/*    */   
/*    */   public void refresh() {
/* 26 */     this.jc.repaint();
/* 27 */     this.city.form.compedos.iv.vent.repaint();
/*    */   }
/*    */   
/*    */   public void view(double px, double py) {
/* 31 */     int y = (int)(py * this.jc.getHeight2());
/* 32 */     int x = (int)(px * this.jc.getWidth2());
/* 33 */     Rectangle b = getViewport().getBounds();
/* 34 */     if (y + b.height > this.jc.getHeight2()) {
/* 35 */       y = this.jc.getHeight2() - b.height;
/*    */     }
/* 37 */     if (x + b.width > this.jc.getWidth2()) {
/* 38 */       x = this.jc.getWidth2() - b.width;
/*    */     }
/* 40 */     JScrollBar vbar = getVerticalScrollBar();
/* 41 */     JScrollBar hbar = getHorizontalScrollBar();
/* 42 */     vbar.setValue(y);
/* 43 */     hbar.setValue(x);
/* 44 */     this.city.form.compedos.iv.vent.repaint();
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\CityScroll.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */