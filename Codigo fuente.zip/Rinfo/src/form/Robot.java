/*     */ package form;
/*     */ 
/*     */ import arbol.Cuerpo;
/*     */ import arbol.DeclaracionProcesos;
/*     */ import arbol.DeclaracionVariable;
/*     */ import arbol.Identificador;
/*     */ import arbol.ParametroFormal;
/*     */ import arbol.Proceso;
/*     */ import arbol.Variable;
/*     */ import arbol.sentencia.Sentencia;
/*     */ import arbol.sentencia.primitiva.Mover;
/*     */ import java.awt.Color;
/*     */ import java.awt.Image;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyChangeSupport;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.ImageIcon;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Robot
/*     */ {
/*     */   private int ciclos;
/*     */   private ArrayList<Coord> misCalles;
/*     */   private DeclaracionProcesos procAST;
/*     */   private Cuerpo cueAST;
/*     */   private DeclaracionVariable varAST;
/*     */   private ImageIcon robotImage;
/*     */   private ArrayList<Coord> ruta;
/*     */   private ArrayList<ArrayList<Coord>> rutas;
/*     */   public int Av;
/*     */   public int Ca;
/*     */   private int direccion;
/*     */   private final PropertyChangeSupport pcs;
/*     */   private Ciudad city;
/*     */   private int floresEnBolsa;
/*     */   private int papelesEnBolsa;
/*     */   private int floresEnBolsaDeConfiguracion;
/*     */   private int papelesEnBolsaDeConfiguracion;
/*     */   private ArrayList<Area> areas;
/*     */   MonitorEsquinas esquinas;
/*     */   MonitorActualizarVentana esperarRefresco;
/*     */   public int id;
/*     */   
/*     */   public Robot(Ciudad city, String nombre) throws Exception {
/*  68 */     this.robotImage = new ImageIcon(getClass().getResource("/images/robotAbajo.png"));
/*  69 */     this.ruta = new ArrayList<>();
/*  70 */     this.rutas = new ArrayList<>();
/*  71 */     this.Av = 0;
/*  72 */     this.Ca = 0;
/*  73 */     this.direccion = 90;
/*  74 */     this.pcs = new PropertyChangeSupport(this);
/*  75 */     this.floresEnBolsa = 0;
/*  76 */     this.papelesEnBolsa = 0;
/*  77 */     this.floresEnBolsaDeConfiguracion = 0;
/*  78 */     this.papelesEnBolsaDeConfiguracion = 0;
/*  79 */     this.esquinas = MonitorEsquinas.getInstance();
/*  80 */     this.esperarRefresco = MonitorActualizarVentana.getInstance();
/*  81 */     this.offsetAv = 0;
/*  82 */     this.offsetCa = 0;
/*  83 */     this.misCalles = new ArrayList<>();
/*  84 */     this.areas = new ArrayList<>();
/*  85 */     this.Av = 0;
/*  86 */     this.Ca = 0;
/*  87 */     getRuta().add(new Coord(this.Av, this.Ca));
/*  88 */     setNombre(nombre);
/*  89 */     this.city = city;
/*  90 */     this.rutas.add(this.ruta);
/*  91 */     this.id = (getCity()).robots.size();
/*  92 */     this.color = getColorById(this.id);
/*  93 */     setDireccion(90);
/*  94 */     setFlores(getFloresEnBolsaDeConfiguracion());
/*  95 */     setPapeles(getPapelesEnBolsaDeConfiguracion());
/*  96 */     this.estado = "nuevo  ";
/*     */   }
/*     */   
/*     */   public void crear() throws UnknownHostException, IOException {
/* 100 */     this.dir = "";
/* 101 */     System.out.println(getId());
/* 102 */     if (this.id == 0) {
/* 103 */       int puerto = 4000;
/* 104 */       File archivo = null;
/* 105 */       FileReader fr = null;
/* 106 */       BufferedReader br = null;
/* 107 */       archivo = new File(System.getProperty("user.dir") + System.getProperty("file.separator") + "Conf.txt");
/*     */       try {
/* 109 */         fr = new FileReader(archivo);
/*     */       }
/* 111 */       catch (FileNotFoundException ex) {
/* 112 */         Logger.getLogger(Mover.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */       } 
/* 114 */       br = new BufferedReader(fr);
/* 115 */       String ip = null;
/*     */       String linea;
/* 117 */       while ((linea = br.readLine()) != null) {
/* 118 */         System.out.println(linea);
/* 119 */         String[] lineas = linea.split(" ");
/* 120 */         String robot = lineas[0];
/* 121 */         ip = lineas[1];
/* 122 */         System.out.println(" el robot es : " + robot + " y la ip es : " + ip);
/*     */       } 
/* 124 */       this.dir = "192.168.0.100";
/* 125 */       this.dir = ip;
/*     */     } else {
/*     */       
/* 128 */       System.out.println("Entre al else");
/* 129 */       this.dir = "192.168.0.104";
/* 130 */       char c = 'ྠ';
/*     */     } 
/* 132 */     try (Socket s = new Socket(this.dir, 4000)) {
/* 133 */       System.out.println("conectados");
/* 134 */       DataOutputStream dOut = new DataOutputStream(s.getOutputStream());
/* 135 */       dOut.writeByte(getId());
/* 136 */       dOut.flush();
/* 137 */       dOut.close();
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getCiclos() {
/* 142 */     return this.ciclos;
/*     */   }
/*     */   
/*     */   public void setCiclos(int ciclos) {
/* 146 */     this.ciclos = ciclos;
/*     */   }
/*     */   
/*     */   public Color getColorById(int id) {
/* 150 */     switch (id) {
/*     */       case 0:
/* 152 */         return Color.RED;
/*     */       
/*     */       case 1:
/* 155 */         return Color.BLUE;
/*     */       
/*     */       case 2:
/* 158 */         return Color.MAGENTA;
/*     */       
/*     */       case 3:
/* 161 */         return Color.CYAN;
/*     */       
/*     */       case 4:
/* 164 */         return new Color(102, 66, 25);
/*     */       
/*     */       case 5:
/* 167 */         return Color.MAGENTA;
/*     */     } 
/*     */     
/* 170 */     return Color.BLACK;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void almacenarMensaje(String nombreDestino, String valor) throws Exception {
/* 176 */     Dato d = new Dato(valor, nombreDestino);
/* 177 */     int id = (getCity().getRobotByNombre(nombreDestino)).id;
/* 178 */     this.monitor.llegoMensaje(id, d);
/*     */   }
/*     */   
/*     */   public void recibirMensaje(Identificador nombreVariable, int id, Identificador NombreRobot) throws Exception {
/* 182 */     this.monitor.recibirMensaje(nombreVariable, id, NombreRobot);
/*     */   }
/*     */   
/*     */   public void Informar(String msj) {
/* 186 */     getCity().Informar(msj, this.id);
/* 187 */     this.esperarRefresco.esperar(this.id);
/*     */   }
/*     */   
/*     */   public void bloquearEsquina(int Av, int Ca) {
/* 191 */     this.esquinas.bloquear(Av, Ca);
/* 192 */     this.esperarRefresco.esperar(this.id);
/* 193 */     (getCity()).form.jsp.refresh();
/*     */   }
/*     */   
/*     */   public void liberarEsquina(int Av, int Ca) {
/* 197 */     this.esquinas.liberar(Av, Ca);
/* 198 */     this.esperarRefresco.esperar(this.id);
/* 199 */     (getCity()).form.jsp.refresh();
/*     */   }
/*     */   
/*     */   public Cuerpo getCuerpo() {
/* 203 */     return this.cueAST;
/*     */   }
/*     */   
/*     */   public void agregarArea(Area a) {
/* 207 */     this.areas.add(a);
/* 208 */     for (int i = a.getAv1(); i <= a.getAv2(); i++) {
/* 209 */       for (int j = a.getCa1(); j <= a.getCa2(); j++) {
/* 210 */         this.misCalles.add(new Coord(i, j));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean esAreaVacia() {
/* 216 */     return this.areas.isEmpty();
/*     */   }
/*     */   
/*     */   public void crearMonitor(int cant) {
/* 220 */     this.monitor = MonitorMensajes.crearMonitorActualizarVentana(cant, this);
/*     */   }
/*     */   
/*     */   public void setCuerpo(Cuerpo cueAST) {
/* 224 */     this.cueAST = cueAST;
/*     */   }
/*     */   
/*     */   public DeclaracionVariable getVariables() {
/* 228 */     return this.varAST;
/*     */   }
/*     */   
/*     */   public void setVariables(DeclaracionVariable varAST) {
/* 232 */     this.varAST = varAST;
/*     */   }
/*     */   
/*     */   public int getFloresEnBolsaDeConfiguracion() {
/* 236 */     return this.floresEnBolsaDeConfiguracion;
/*     */   }
/*     */   
/*     */   public void setFloresEnBolsaDeConfiguracion(int floresEnBolsaDeConfiguracion) {
/* 240 */     setFlores(this.floresEnBolsaDeConfiguracion = floresEnBolsaDeConfiguracion);
/*     */   }
/*     */   
/*     */   public int getPapelesEnBolsaDeConfiguracion() {
/* 244 */     return this.papelesEnBolsaDeConfiguracion;
/*     */   }
/*     */   
/*     */   public void setPapelesEnBolsaDeConfiguracion(int papelesEnBolsaDeConfiguracion) {
/* 248 */     setPapeles(this.papelesEnBolsaDeConfiguracion = papelesEnBolsaDeConfiguracion);
/*     */   }
/*     */   
/*     */   public void reset() {
/* 252 */     this.misCalles = new ArrayList<>();
/* 253 */     this.ruta = new ArrayList<>();
/* 254 */     this.rutas = new ArrayList<>();
/* 255 */     this.areas = new ArrayList<>();
/* 256 */     this.rutas.add(this.ruta);
/* 257 */     setFlores(getFloresEnBolsaDeConfiguracion());
/* 258 */     setPapeles(getPapelesEnBolsaDeConfiguracion());
/*     */     try {
/* 260 */       setAv(0);
/* 261 */       setCa(0);
/*     */     }
/* 263 */     catch (Exception ex) {
/* 264 */       Logger.getLogger(Robot.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/* 266 */     setDireccion(90);
/*     */   }
/*     */   
/*     */   public Image getImage() {
/* 270 */     switch (getDireccion())
/*     */     { case 0:
/* 272 */         this.robotImage = new ImageIcon(getClass().getResource("/images/robotDerecha.png"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 288 */         return this.robotImage.getImage();case 90: this.robotImage = new ImageIcon(getClass().getResource("/images/robotArriba.png")); return this.robotImage.getImage();case 180: this.robotImage = new ImageIcon(getClass().getResource("/images/robotIzquierda.png")); return this.robotImage.getImage(); }  this.robotImage = new ImageIcon(getClass().getResource("/images/robotAbajo.png")); return this.robotImage.getImage();
/*     */   }
/*     */   
/*     */   public String getNombre() {
/* 292 */     return this.nombre;
/*     */   }
/*     */   
/*     */   public void setNombre(String nombre) {
/* 296 */     this.nombre = nombre;
/*     */   }
/*     */   
/*     */   public void iniciar(int x, int y) throws Exception {
/* 300 */     Pos(x, y);
/* 301 */     setNewX(x);
/* 302 */     setNewY(y);
/* 303 */     setFlores(getFlores());
/* 304 */     setPapeles(getPapeles());
/* 305 */     (getCity()).form.jsp.refresh();
/*     */   }
/*     */   
/*     */   public void choque(String nom, int id, int av, int ca) throws Exception {
/* 309 */     for (Robot r : (getCity()).robots) {
/* 310 */       if (r.id != id && r.Av == av && r.Ca == ca) {
/* 311 */         this.city.parseError(" Se produjo un choque entre el robot " + nom + " y el robot " + r.getNombre() + " en la avenida " + av + " y la calle " + ca);
/* 312 */         throw new Exception(" Se produjo un choque entre el robot " + nom + " y el robot " + r.getNombre() + " en la avenida " + av + " y la calle " + ca);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void mover() throws Exception {
/* 318 */     int av = PosAv();
/* 319 */     int ca = PosCa();
/* 320 */     switch (getDireccion()) {
/*     */       case 0:
/* 322 */         av++;
/*     */         break;
/*     */       
/*     */       case 180:
/* 326 */         av--;
/*     */         break;
/*     */       
/*     */       case 90:
/* 330 */         ca++;
/*     */         break;
/*     */       
/*     */       case 270:
/* 334 */         ca--;
/*     */         break;
/*     */     } 
/*     */     
/* 338 */     if (!puedeMover(av, ca, this.areas)) {
/* 339 */       this.city.parseError("No se puede ejecutar la instrucción \"mover\" debido a que no corresponde a un area asignada del robot");
/* 340 */       throw new Exception("No se puede ejecutar la instrucción \"mover\" debido a que no corresponde a un area asignada del robot");
/*     */     } 
/* 342 */     if (getCity().isFreePos(ca, av)) {
/* 343 */       addPos(av, ca);
/* 344 */       setFlores(getFlores());
/* 345 */       setPapeles(getPapeles());
/* 346 */       choque(this.nombre, this.id, this.Av, this.Ca);
/* 347 */       this.esperarRefresco.esperar(this.id);
/* 348 */       (getCity()).form.jsp.refresh();
/*     */       return;
/*     */     } 
/* 351 */     this.city.parseError("No se puede ejecutar la instrucción \"mover\" debido a que hay un obstáculo");
/* 352 */     throw new Exception("No se puede ejecutar la instrucción \"mover\" debido a que hay un obstáculo");
/*     */   }
/*     */   
/*     */   public boolean puedeMover(int av, int ca, ArrayList<Area> areas) {
/* 356 */     for (Coord c : this.misCalles) {
/* 357 */       if (c.getX() == av && c.getY() == ca) {
/* 358 */         return true;
/*     */       }
/*     */     } 
/* 361 */     return false;
/*     */   }
/*     */   
/*     */   public int[] getXCoord() {
/* 365 */     int[] x = new int[this.ruta.size()];
/* 366 */     for (int c = 0; c < this.ruta.size(); c++) {
/* 367 */       Coord p = this.ruta.get(c);
/* 368 */       x[c] = p.getX();
/*     */     } 
/* 370 */     return x;
/*     */   }
/*     */   
/*     */   public int[] getYCoord() {
/* 374 */     int[] y = new int[this.ruta.size() + 1];
/* 375 */     for (int c = 0; c < this.ruta.size(); c++) {
/* 376 */       Coord p = this.ruta.get(c);
/* 377 */       y[c] = p.getY();
/*     */     } 
/* 379 */     return y;
/*     */   }
/*     */   
/*     */   public void addPos(int av, int ca) throws Exception {
/*     */     try {
/* 384 */       int old = this.city.ciudad[av][ca].getFlores();
/* 385 */       setAv(av);
/* 386 */       setCa(ca);
/* 387 */       this.pcs.firePropertyChange("esquinaFlores", old, this.city.ciudad[av][ca].getFlores());
/*     */     }
/* 389 */     catch (Exception e) {
/* 390 */       throw new Exception("Una de las nuevas coordenadas cae fuera de la ciudad.Av: " + av + " Ca: " + ca + " Calles: " + this.city.getNumCa() + " Avenidas: " + this.city.getNumAv());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setAv(int av) throws Exception {
/* 395 */     if (av > this.city.getNumAv()) {
/* 396 */       throw new Exception();
/*     */     }
/* 398 */     if (av != PosAv()) {
/* 399 */       this.ruta.add(new Coord(av, PosCa()));
/* 400 */       if (av > PosAv()) {
/* 401 */         setDireccion(0);
/*     */       } else {
/*     */         
/* 404 */         setDireccion(180);
/*     */       } 
/*     */     } 
/* 407 */     setNewX(av);
/* 408 */     setNewY(this.Ca);
/*     */   }
/*     */   
/*     */   public void setNewX(int av) {
/* 412 */     int old = PosAv();
/* 413 */     this.Av = av;
/* 414 */     this.pcs.firePropertyChange("av", old, av);
/*     */   }
/*     */   
/*     */   public void setNewY(int ca) {
/* 418 */     int old = PosCa();
/* 419 */     this.Ca = ca;
/* 420 */     this.pcs.firePropertyChange("ca", old, ca);
/*     */   }
/*     */   
/*     */   public void setCa(int ca) throws Exception {
/* 424 */     if (ca > this.city.getNumCa()) {
/* 425 */       throw new Exception();
/*     */     }
/* 427 */     if (ca != PosCa()) {
/* 428 */       this.ruta.add(new Coord(PosAv(), ca));
/* 429 */       if (ca < PosCa()) {
/* 430 */         setDireccion(270);
/*     */       } else {
/*     */         
/* 433 */         setDireccion(90);
/*     */       } 
/*     */     } 
/* 436 */     setNewY(ca);
/* 437 */     setNewX(this.Av);
/*     */   }
/*     */   
/*     */   public void setDireccion(int direccion) {
/* 441 */     int old = this.direccion;
/* 442 */     this.direccion = direccion;
/* 443 */     this.pcs.firePropertyChange("direccion", old, direccion);
/*     */   }
/*     */   
/*     */   public void setEstado(String str) {
/* 447 */     String s = getEstado();
/* 448 */     this.estado = str;
/* 449 */     this.pcs.firePropertyChange("estado", s, str);
/*     */   }
/*     */   
/*     */   public String getEstado() {
/* 453 */     return this.estado;
/*     */   }
/*     */   
/*     */   public int getDireccion() {
/* 457 */     return this.direccion;
/*     */   }
/*     */   
/*     */   public void addPropertyChangeListener(PropertyChangeListener listener) {
/* 461 */     this.pcs.addPropertyChangeListener(listener);
/*     */   }
/*     */   
/*     */   public void removePropertyChangeListener(PropertyChangeListener listener) {
/* 465 */     this.pcs.removePropertyChangeListener(listener);
/*     */   }
/*     */   
/*     */   public void mirarEnDireccion(int direccion) throws Exception {
/*     */     int c;
/* 470 */     for (c = 0; c < 5 && getDireccion() != direccion; c++) {
/* 471 */       derecha();
/*     */     }
/* 473 */     if (c == 5) {
/* 474 */       throw new Exception("La dirección especificada no corresponde.");
/*     */     }
/*     */   }
/*     */   
/*     */   public void derecha() {
/* 479 */     switch (getDireccion()) {
/*     */       case 0:
/* 481 */         setDireccion(270);
/*     */         break;
/*     */       
/*     */       case 270:
/* 485 */         setDireccion(180);
/*     */         break;
/*     */       
/*     */       case 180:
/* 489 */         setDireccion(90);
/*     */         break;
/*     */       
/*     */       case 90:
/* 493 */         setDireccion(0);
/*     */         break;
/*     */     } 
/*     */     
/* 497 */     this.esperarRefresco.esperar(this.id);
/* 498 */     (getCity()).form.jsp.refresh();
/*     */   }
/*     */   
/*     */   public int PosCa() {
/* 502 */     return this.Ca;
/*     */   }
/*     */   
/*     */   public int PosAv() {
/* 506 */     return this.Av;
/*     */   }
/*     */   
/*     */   public void Pos(int Av, int Ca) throws Exception {
/* 510 */     if (!puedeMover(Av, Ca, this.areas)) {
/* 511 */       this.city.parseError("No se puede ejecutar la instrucción \"Pos\" debido a que no corresponde a un area asignada del robot");
/* 512 */       throw new Exception("No se puede ejecutar la instrucción \"Pos\" debido a que no corresponde a un area asignada del robot");
/*     */     } 
/* 514 */     if (getCity().isFreePos(Ca, Av)) {
/* 515 */       getRutas().add(getRuta());
/* 516 */       setRuta(new ArrayList<>());
/* 517 */       getRuta().add(new Coord(Av, Ca));
/* 518 */       setNewX(Av);
/* 519 */       setNewY(Ca);
/* 520 */       choque(this.nombre, this.id, Av, Ca);
/* 521 */       this.esperarRefresco.esperar(this.id);
/* 522 */       (getCity()).form.jsp.refresh();
/*     */       return;
/*     */     } 
/* 525 */     this.city.parseError("No se puede ejecutar la instrucción \"Pos\" debido a que hay un obstáculo");
/* 526 */     throw new Exception("No se puede ejecutar la instrucción \"Pos\" debido a que hay un obstáculo");
/*     */   }
/*     */   
/*     */   public ArrayList<Coord> getRuta() {
/* 530 */     return this.ruta;
/*     */   }
/*     */   
/*     */   public Ciudad getCity() {
/* 534 */     return this.city;
/*     */   }
/*     */   
/*     */   public void tomarFlor() throws Exception {
/* 538 */     if (getCity().levantarFlor(PosAv(), PosCa())) {
/* 539 */       setFlores(getFlores() + 1);
/* 540 */       this.esperarRefresco.esperar(this.id);
/*     */       return;
/*     */     } 
/* 543 */     setFlores(getFlores());
/* 544 */     throw new Exception("No se puede ejecutar la instrucción \"tomarFlor\" debido a que no hay ninguna flor en la esquina");
/*     */   }
/*     */   
/*     */   public int getFlores() {
/* 548 */     return this.floresEnBolsa;
/*     */   }
/*     */   
/*     */   public void setFlores(int flores) {
/* 552 */     int old = getFlores();
/* 553 */     this.floresEnBolsa = flores;
/* 554 */     this.pcs.firePropertyChange("flores", old, flores);
/*     */   }
/*     */   
/*     */   public void tomarPapel() throws Exception {
/* 558 */     if (getCity().levantarPapel(PosAv(), PosCa())) {
/* 559 */       setPapeles(getPapeles() + 1);
/* 560 */       this.esperarRefresco.esperar(this.id);
/*     */       return;
/*     */     } 
/* 563 */     setPapeles(getPapeles());
/* 564 */     throw new Exception("No se puede ejecutar la instrucción \"tomarPapel\" debido a que no hay ningun papel en la esquina");
/*     */   }
/*     */   
/*     */   public boolean HayPapelEnLaBolsa() {
/* 568 */     return (getPapeles() > 0);
/*     */   }
/*     */   
/*     */   public boolean HayFlorEnLaBolsa() {
/* 572 */     return (getFlores() > 0);
/*     */   }
/*     */   
/*     */   public int getPapeles() {
/* 576 */     return this.papelesEnBolsa;
/*     */   }
/*     */   
/*     */   public void setColor(Color col) {
/* 580 */     Color old = this.color;
/* 581 */     this.color = col;
/* 582 */     this.pcs.firePropertyChange("color", old, col);
/*     */   }
/*     */   
/*     */   public Color getColor() {
/* 586 */     return this.color;
/*     */   }
/*     */   
/*     */   public void setPapeles(int papeles) {
/* 590 */     int old = getPapeles();
/* 591 */     this.papelesEnBolsa = papeles;
/* 592 */     this.pcs.firePropertyChange("papeles", old, papeles);
/*     */   }
/*     */   
/*     */   public void depositarPapel() throws Exception {
/* 596 */     if (getPapeles() > 0) {
/* 597 */       setPapeles(getPapeles() - 1);
/* 598 */       getCity().dejarPapel(PosAv(), PosCa());
/* 599 */       this.esperarRefresco.esperar(this.id);
/*     */       return;
/*     */     } 
/* 602 */     this.city.parseError("No se puede ejecutar la instrucción \"depositarPapel\" debido a que no hay ningun papel en la bolsa");
/* 603 */     throw new Exception("No se puede ejecutar la instrucción \"depositarPapel\" debido a que no hay ningun papel en la bolsa");
/*     */   }
/*     */   
/*     */   public void depositarFlor() throws Exception {
/* 607 */     if (getFlores() > 0) {
/* 608 */       setFlores(getFlores() - 1);
/* 609 */       getCity().dejarFlor(PosAv(), PosCa());
/* 610 */       this.esperarRefresco.esperar(this.id);
/*     */       return;
/*     */     } 
/* 613 */     this.city.parseError("No se puede ejecutar la instrucción \"depositarFlor\" debido a que no hay ninguna en la bolsa de flores");
/* 614 */     throw new Exception("No se puede ejecutar la instrucción \"depositarFlor\" debido a que no hay ninguna en la bolsa de flores");
/*     */   }
/*     */   
/*     */   public ArrayList<ArrayList<Coord>> getRutas() {
/* 618 */     return this.rutas;
/*     */   }
/*     */   
/*     */   public void setRuta(ArrayList<Coord> ruta) {
/* 622 */     this.ruta = ruta;
/*     */   }
/*     */   
/*     */   public void setRutas(ArrayList<ArrayList<Coord>> rutas) {
/* 626 */     this.rutas = rutas;
/*     */   }
/*     */   
/*     */   public DeclaracionProcesos getProcAST() {
/* 630 */     return this.procAST;
/*     */   }
/*     */   
/*     */   public void setProcAST(DeclaracionProcesos procAST) throws CloneNotSupportedException {
/* 634 */     synchronized (this) {
/* 635 */       ArrayList<Proceso> ps = new ArrayList<>();
/* 636 */       for (Proceso j : procAST.getProcesos()) {
/* 637 */         DeclaracionVariable ddvv = j.getDV();
/* 638 */         Identificador I = new Identificador(j.getI().toString());
/* 639 */         ArrayList<ParametroFormal> pfs = new ArrayList<>();
/* 640 */         for (ParametroFormal pformal : j.getPF()) {
/* 641 */           Identificador In = new Identificador(pformal.getI().toString());
/* 642 */           ParametroFormal pf = new ParametroFormal(In, pformal.getT(), pformal.getTA());
/* 643 */           pfs.add(pf);
/*     */         } 
/* 645 */         ArrayList<Sentencia> ss = new ArrayList<>();
/* 646 */         for (Sentencia sen : j.getC().getS()) {
/* 647 */           System.out.println("Sentencia : " + sen.toString());
/* 648 */           Sentencia s = (Sentencia)sen.clone();
/* 649 */           ss.add(s);
/*     */         } 
/* 651 */         ArrayList<Variable> dvs = new ArrayList<>();
/* 652 */         for (Variable v : ddvv.variables) {
/* 653 */           Variable V = (Variable)v.clone();
/* 654 */           dvs.add(V);
/*     */         } 
/* 656 */         DeclaracionVariable ddvs = new DeclaracionVariable(dvs);
/* 657 */         Cuerpo cue = new Cuerpo(ss, ddvs);
/* 658 */         Proceso p = new Proceso(I, pfs, procAST, ddvs, cue);
/* 659 */         ps.add(p);
/*     */       } 
/* 661 */       DeclaracionProcesos dp = new DeclaracionProcesos(ps);
/* 662 */       this.procAST = dp;
/*     */     } 
/*     */   }
/*     */   
/*     */   public DeclaracionVariable getVarAST() {
/* 667 */     return this.varAST;
/*     */   }
/*     */   
/*     */   public void setVarAST(DeclaracionVariable varAST) {
/* 671 */     this.varAST = varAST;
/*     */   }
/*     */   
/*     */   public int getId() {
/* 675 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setId(int id) {
/* 679 */     this.id = id;
/*     */   }
/*     */ 
/*     */   
/* 683 */   private static int cant = 0;
/*     */   public int offsetAv;
/*     */   public int offsetCa;
/*     */   public String dir;
/*     */   public MonitorMensajes monitor;
/*     */   String nombre;
/*     */   Color color;
/*     */   public String estado;
/*     */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\Robot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */