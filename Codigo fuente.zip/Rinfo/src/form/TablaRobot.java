/*     */ package form;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.util.EventObject;
/*     */ import java.util.LinkedList;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.event.CellEditorListener;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.TableModelEvent;
/*     */ import javax.swing.event.TableModelListener;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import javax.swing.table.TableCellEditor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TablaRobot
/*     */   extends JPanel
/*     */   implements PropertyChangeListener
/*     */ {
/*     */   final String[] columnNames;
/*     */   GridBagConstraints gbc;
/*     */   Ciudad city;
/*     */   final DefaultTableModel modelo;
/*     */   
/*     */   TablaRobot(final Ciudad city) {
/*  38 */     this.columnNames = new String[] { "Robot", "Flores", "Papeles", "Color" };
/*  39 */     this.gbc = new GridBagConstraints();
/*  40 */     this.city = city;
/*  41 */     setLayout(new GridBagLayout());
/*  42 */     this.gbc.fill = 1;
/*  43 */     (this.modelo = new MiModelo()).addColumn("Robot");
/*  44 */     this.modelo.addColumn("Flores");
/*  45 */     this.modelo.addColumn("Papeles");
/*  46 */     this.modelo.addColumn("Color");
/*  47 */     this.city.addPropertyChangeListener(this);
/*  48 */     this.modelo.addTableModelListener(new TableModelListener()
/*     */         {
/*     */           public void tableChanged(TableModelEvent e) {
/*  51 */             int row = e.getFirstRow();
/*  52 */             int col = e.getColumn();
/*  53 */             if (col >= 0) {
/*  54 */               int x; Color co; Object value = TablaRobot.this.modelo.getValueAt(row, col);
/*  55 */               switch (col) {
/*     */                 case 1:
/*  57 */                   if (value == null) {
/*  58 */                     ((Robot)city.robots.get(row)).setFloresEnBolsaDeConfiguracion(0);
/*     */                     break;
/*     */                   } 
/*  61 */                   x = Integer.parseInt(value.toString());
/*  62 */                   ((Robot)city.robots.get(row)).setFloresEnBolsaDeConfiguracion(x);
/*     */                   break;
/*     */                 
/*     */                 case 2:
/*  66 */                   if (value == null) {
/*  67 */                     ((Robot)city.robots.get(row)).setPapelesEnBolsaDeConfiguracion(0);
/*     */                     break;
/*     */                   } 
/*  70 */                   x = Integer.parseInt(value.toString());
/*  71 */                   ((Robot)city.robots.get(row)).setPapelesEnBolsaDeConfiguracion(x);
/*     */                   break;
/*     */                 
/*     */                 case 3:
/*  75 */                   co = (Color)value;
/*  76 */                   ((Robot)city.robots.get(row)).setColor(co);
/*  77 */                   city.form.jsp.refresh();
/*     */                   break;
/*     */               } 
/*     */             
/*     */             } 
/*     */           }
/*     */         });
/*  84 */     Object[] datos = new Object[4];
/*  85 */     for (Robot rr : this.city.robots) {
/*  86 */       datos[0] = rr.getNombre();
/*  87 */       datos[1] = Integer.valueOf(0);
/*  88 */       datos[2] = Integer.valueOf(0);
/*  89 */       datos[3] = rr.getColor();
/*  90 */       this.modelo.addRow(datos);
/*     */     } 
/*  92 */     JTable table1 = new JTable(this.modelo);
/*  93 */     table1.setDefaultRenderer(Color.class, new ColorRenderer(true));
/*  94 */     table1.setDefaultEditor(Color.class, new ColorEditor());
/*  95 */     table1.setPreferredScrollableViewportSize(new Dimension(200, 80));
/*  96 */     add(new JScrollPane(table1), this.gbc);
/*     */   }
/*     */ 
/*     */   
/*     */   public void propertyChange(PropertyChangeEvent evt) {
/* 101 */     String propertyName = evt.getPropertyName();
/* 102 */     String propertyValue = evt.getNewValue().toString();
/* 103 */     if (propertyName.equals("numRobots")) {
/* 104 */       int i = Integer.parseInt(propertyValue) - 1;
/* 105 */       Robot rr = this.city.robots.get(i);
/* 106 */       Object[] datos = { rr.getNombre(), Integer.valueOf(0), Integer.valueOf(0), rr.getColor() };
/* 107 */       this.modelo.addRow(datos);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public class MiModelo
/*     */     extends DefaultTableModel
/*     */     implements TableCellEditor
/*     */   {
/* 116 */     private LinkedList suscriptores = new LinkedList();
/*     */ 
/*     */ 
/*     */     
/*     */     public void addCellEditorListener(CellEditorListener l) {
/* 121 */       this.suscriptores.add(l);
/*     */     }
/*     */     
/*     */     protected void editado(boolean cambiado) {
/* 125 */       ChangeEvent evento = new ChangeEvent(this);
/* 126 */       for (int i = 0; i < this.suscriptores.size(); i++) {
/* 127 */         CellEditorListener aux = this.suscriptores.get(i);
/* 128 */         if (cambiado) {
/* 129 */           aux.editingStopped(evento);
/*     */         } else {
/*     */           
/* 132 */           aux.editingCanceled(evento);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isCellEditable(int row, int column) {
/* 139 */       return (column > 0);
/*     */     }
/*     */ 
/*     */     
/*     */     public Class getColumnClass(int columna) {
/* 144 */       if (columna == 1) {
/* 145 */         return Integer.class;
/*     */       }
/* 147 */       if (columna == 2) {
/* 148 */         return Integer.class;
/*     */       }
/* 150 */       return getValueAt(0, columna).getClass();
/*     */     }
/*     */ 
/*     */     
/*     */     public int getColumnCount() {
/* 155 */       return TablaRobot.this.columnNames.length;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getColumnName(int col) {
/* 160 */       return TablaRobot.this.columnNames[col];
/*     */     }
/*     */ 
/*     */     
/*     */     public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
/* 165 */       throw new UnsupportedOperationException("Not supported yet.");
/*     */     }
/*     */     
/*     */     public Object getCellEditorValue(int aRow, int aColumn) {
/* 169 */       System.out.println(" ACA ESTOY");
/* 170 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean shouldSelectCell(EventObject anEvent) {
/* 175 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean stopCellEditing() {
/* 180 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void cancelCellEditing() {}
/*     */ 
/*     */     
/*     */     public void removeCellEditorListener(CellEditorListener l) {
/* 189 */       this.suscriptores.remove(l);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isCellEditable(EventObject anEvent) {
/* 194 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getCellEditorValue() {
/* 199 */       System.out.println("IMPRIMI");
/* 200 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\TablaRobot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */