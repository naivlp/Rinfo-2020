/*     */ package form;
/*     */ 
/*     */ import arbol.Programa;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.JToolBar;
/*     */ import javax.swing.border.TitledBorder;
/*     */ import javax.swing.filechooser.FileNameExtensionFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CodePanel
/*     */   extends JPanel
/*     */ {
/*     */   private JToolBar toolBar;
/*     */   public MyTextPane text;
/*     */   Ciudad city;
/*     */   MonitorActualizarVentana esperarRefresco;
/*     */   private JButton saveButton;
/*     */   private JButton newButton;
/*     */   private JButton openButton;
/*     */   private JButton runButton;
/*     */   private JButton resetButton;
/*     */   private JButton stepButton;
/*     */   private JButton stopButton;
/*     */   private final JSlider slider;
/*     */   private JButton pauseButton;
/*     */   private JButton compileButton;
/*     */   private JButton saveAsButton;
/*     */   JTextField NombreRobot;
/*     */   Thread thread;
/*     */   Thread threadVentana;
/*     */   Runnable exec1;
/*     */   Runnable exec2;
/*     */   Ejecucion exec;
/*     */   String path;
/*     */   
/*     */   public CodePanel(Ciudad city) throws Exception {
/*  84 */     this.esperarRefresco = MonitorActualizarVentana.getInstance();
/*  85 */     this.NombreRobot = new JTextField(5);
/*  86 */     this.thread = null;
/*  87 */     this.path = "";
/*  88 */     this.city = city;
/*  89 */     setLayout(new BorderLayout());
/*  90 */     this.toolBar = new JToolBar();
/*  91 */     ImageIcon icon = new ImageIcon(getClass().getResource("/images/newFile24.png"));
/*  92 */     (this.newButton = new JButton(icon)).setToolTipText("Nuevo (CTRL + N)");
/*  93 */     icon = new ImageIcon(getClass().getResource("/images/compile.png"));
/*  94 */     (this.compileButton = new JButton(icon)).setToolTipText("Compilar (F5)");
/*  95 */     icon = new ImageIcon(getClass().getResource("/images/openProject24.png"));
/*  96 */     (this.openButton = new JButton(icon)).setToolTipText("Abrir (CTRL + O)");
/*  97 */     icon = new ImageIcon(getClass().getResource("/images/guardar_como.png"));
/*  98 */     (this.saveAsButton = new JButton(icon)).setToolTipText("Guardar Como (CTRL + SHIFT + S)");
/*  99 */     icon = new ImageIcon(getClass().getResource("/images/save.png"));
/* 100 */     (this.saveButton = new JButton(icon)).setToolTipText("Guardar (CTRL + S)");
/* 101 */     icon = new ImageIcon(getClass().getResource("/images/runProject24.png"));
/* 102 */     (this.runButton = new JButton(icon)).setToolTipText("Ejecutar (F6)");
/* 103 */     icon = new ImageIcon(getClass().getResource("/images/escoba.png"));
/* 104 */     (this.resetButton = new JButton(icon)).setToolTipText("Reiniciar entorno");
/* 105 */     icon = new ImageIcon(getClass().getResource("/images/runProject25.png"));
/* 106 */     (this.stepButton = new JButton(icon)).setToolTipText("Ejecutar paso a paso");
/* 107 */     icon = new ImageIcon(getClass().getResource("/images/stop.png"));
/* 108 */     (this.stopButton = new JButton(icon)).setToolTipText("Parar programa");
/* 109 */     icon = new ImageIcon(getClass().getResource("/images/pause.png"));
/* 110 */     (this.pauseButton = new JButton(icon)).setToolTipText("Pausar programa");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 116 */       this.path = (new File(".")).getCanonicalPath();
/*     */     }
/* 118 */     catch (IOException ex) {
/* 119 */       Logger.getLogger(InspectorVariables.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/* 121 */     this.newButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 124 */             CodePanel.this.doNewCommand();
/*     */           }
/*     */         });
/* 127 */     this.openButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/*     */             try {
/* 131 */               CodePanel.this.doOpenCommand();
/*     */             }
/* 133 */             catch (IOException ex) {
/* 134 */               System.out.println("error en el abrir archivo");
/* 135 */               Logger.getLogger(CodePanel.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */             } 
/*     */           }
/*     */         });
/* 139 */     this.saveAsButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 142 */             CodePanel.this.doSaveAsCommand();
/*     */           }
/*     */         });
/* 145 */     this.saveButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 148 */             CodePanel.this.doSaveCommand();
/*     */           }
/*     */         });
/* 151 */     this.stopButton.setEnabled(false);
/* 152 */     this.stopButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 155 */             CodePanel.this.saveButton.setEnabled(true);
/* 156 */             CodePanel.this.newButton.setEnabled(true);
/* 157 */             CodePanel.this.openButton.setEnabled(true);
/* 158 */             CodePanel.this.runButton.setEnabled(false);
/* 159 */             CodePanel.this.resetButton.setEnabled(true);
/* 160 */             CodePanel.this.pauseButton.setEnabled(false);
/*     */             try {
/* 162 */               CodePanel.this.doStopStepByStep();
/*     */             }
/* 164 */             catch (Exception ex) {
/* 165 */               Logger.getLogger(CodePanel.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */             } 
/*     */           }
/*     */         });
/* 169 */     this.runButton.setEnabled(false);
/* 170 */     this.runButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/*     */             try {
/* 174 */               CodePanel.this.runButton.setEnabled(false);
/* 175 */               CodePanel.this.stepButton.setEnabled(false);
/* 176 */               CodePanel.this.doRunCommand();
/*     */             }
/* 178 */             catch (Exception ex) {
/* 179 */               Logger.getLogger(CodePanel.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */             } 
/*     */           }
/*     */         });
/* 183 */     this.stepButton.setEnabled(false);
/* 184 */     this.stepButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/*     */             try {
/* 188 */               CodePanel.this.saveButton.setEnabled(false);
/* 189 */               CodePanel.this.newButton.setEnabled(false);
/* 190 */               CodePanel.this.openButton.setEnabled(false);
/* 191 */               CodePanel.this.runButton.setEnabled(false);
/* 192 */               CodePanel.this.resetButton.setEnabled(false);
/* 193 */               CodePanel.this.stepButton.setEnabled(true);
/* 194 */               CodePanel.this.pauseButton.setEnabled(true);
/* 195 */               CodePanel.this.doStepCommand();
/*     */             }
/* 197 */             catch (Exception ex) {
/* 198 */               Logger.getLogger(CodePanel.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */             } 
/*     */           }
/*     */         });
/* 202 */     this.resetButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/*     */             try {
/* 206 */               CodePanel.this.doResetCommand();
/*     */             }
/* 208 */             catch (Exception ex) {
/* 209 */               Logger.getLogger(CodePanel.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 214 */     this.pauseButton.setEnabled(false);
/* 215 */     this.pauseButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/*     */             try {
/* 219 */               CodePanel.this.doPauseCommand();
/*     */             }
/* 221 */             catch (Exception ex) {
/* 222 */               Logger.getLogger(CodePanel.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */             } 
/*     */           }
/*     */         });
/* 226 */     this.compileButton.setEnabled(true);
/* 227 */     this.compileButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/*     */             try {
/* 231 */               CodePanel.this.doCompileCommand();
/*     */             }
/* 233 */             catch (Exception ex) {
/* 234 */               Logger.getLogger(CodePanel.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */             } 
/*     */           }
/*     */         });
/* 238 */     this.toolBar.add(this.newButton);
/* 239 */     this.toolBar.add(this.openButton);
/* 240 */     this.toolBar.add(this.saveAsButton);
/* 241 */     this.toolBar.add(this.saveButton);
/* 242 */     this.toolBar.add(this.compileButton);
/* 243 */     this.toolBar.add(this.runButton);
/* 244 */     this.toolBar.add(this.resetButton);
/*     */ 
/*     */     
/* 247 */     this.slider = new JSlider(0, 0, 100, 34);
/* 248 */     this.slider.setInverted(false);
/* 249 */     this.slider.setPaintTicks(true);
/* 250 */     this.slider.setMajorTickSpacing(10);
/* 251 */     this.slider.setMinorTickSpacing(10);
/* 252 */     this.slider.setPaintLabels(true);
/* 253 */     this.slider.setValue(50);
/* 254 */     this.toolBar.add(this.slider);
/* 255 */     this.toolBar.add(this.stepButton);
/* 256 */     this.toolBar.add(this.stopButton);
/* 257 */     this.toolBar.add(this.pauseButton);
/* 258 */     this.toolBar.add(new JPanel());
/* 259 */     add(this.toolBar, "North");
/* 260 */     add(this.text = new MyTextPane(this.city), "Center");
/*     */   }
/*     */   
/*     */   public void doNewCommand() {
/* 264 */     int dialogResult = JOptionPane.showConfirmDialog(null, "¿Estás seguro que deseas borrar todo el código?", "Advertencia", 0);
/* 265 */     if (dialogResult == 0) {
/* 266 */       archivoactual = "";
/* 267 */       this.text.setText("");
/* 268 */       this.city.areas = new ArrayList<>();
/* 269 */       this.city.form.jsp.refresh();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void doPauseCommand() {
/* 275 */     this.city.form.monitorCola.pausar_ejecucion();
/* 276 */     this.city.form.monitorCola.setEn_ejecucion(true);
/* 277 */     habilitarTodo();
/* 278 */     this.runButton.setEnabled(true);
/* 279 */     this.compileButton.setEnabled(false);
/*     */   }
/*     */ 
/*     */   
/*     */   private void formKeyPressed(KeyEvent evt) {}
/*     */   
/*     */   public void doStepCommand() throws Exception {
/* 286 */     this.compileButton.setEnabled(false);
/* 287 */     this.pauseButton.setEnabled(false);
/* 288 */     this.stopButton.setEnabled(true);
/* 289 */     this.esperarRefresco.setPasoAPaso(true);
/* 290 */     this.esperarRefresco.setApretoF7(false);
/* 291 */     this.esperarRefresco.setTimerOn(false);
/* 292 */     if (!this.esperarRefresco.isEn_ejecucion()) {
/* 293 */       this.thread.start();
/* 294 */       this.threadVentana.start();
/* 295 */       this.stepButton.setEnabled(true);
/*     */     } else {
/*     */       
/* 298 */       this.esperarRefresco.despertar();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void doStopStepByStep() throws Exception {
/* 304 */     this.city.form.monitorCola.termine_ejecucion();
/* 305 */     this.city.form.monitorCola.setEn_ejecucion(false);
/* 306 */     this.city.form.monitorCola.setSistemaPausado(false);
/* 307 */     for (Thread t : this.city.hilos) {
/* 308 */       t.interrupt();
/*     */     }
/* 310 */     this.city.hilos = new ArrayList<>();
/* 311 */     for (Robot rrr : this.city.robots) {
/* 312 */       rrr.setEstado("finalizado");
/*     */     }
/* 314 */     this.thread.interrupt();
/* 315 */     habilitarTodo();
/*     */   }
/*     */   
/*     */   public void doResetCommand() throws Exception {
/* 319 */     for (int i = 0; i <= 100; i++) {
/* 320 */       for (int j = 0; j <= 100; j++) {
/* 321 */         this.city.ciudad[i][j] = new Bolsa();
/*     */       }
/*     */     } 
/* 324 */     for (Robot rr : this.city.robots) {
/* 325 */       rr.reset();
/*     */     }
/* 327 */     this.city.form.jsp.refresh();
/*     */   }
/*     */   
/*     */   public void doOpenCommand() throws IOException {
/* 331 */     JFileChooser chooser = new JFileChooser(this.path);
/* 332 */     FileNameExtensionFilter filter = new FileNameExtensionFilter("R-Info", new String[] { "rinfo" });
/* 333 */     chooser.setFileFilter(filter);
/* 334 */     int status = chooser.showOpenDialog(this);
/* 335 */     if (status == 0) {
/* 336 */       File f = chooser.getSelectedFile();
/* 337 */       archivoactual = f.getAbsolutePath();
/* 338 */       this.path = f.getAbsolutePath();
/*     */       try {
/* 340 */         FileReader fin = new FileReader(f);
/*     */         
/* 342 */         BufferedReader br = new BufferedReader(fin);
/* 343 */         char[] buffer = new char[4096];
/*     */         
/* 345 */         String txt = "";
/*     */         
/*     */         int len;
/* 348 */         while ((len = br.read(buffer, 0, buffer.length)) != -1)
/*     */         {
/* 350 */           txt = txt + new String(buffer, 0, len);
/*     */         }
/* 352 */         txt = txt.replace("\r", "");
/* 353 */         this.text.setText(txt);
/*     */       }
/* 355 */       catch (Exception exc) {
/* 356 */         System.out.println("Exception en el doOpenCommand");
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/* 361 */   static String archivoactual = "";
/*     */   
/*     */   void doSaveCommand() {
/* 364 */     if (archivoactual.equals("")) {
/* 365 */       doSaveAsCommand();
/*     */     } else {
/*     */       
/* 368 */       Writer out = null;
/*     */       try {
/*     */         try {
/* 371 */           out = new OutputStreamWriter(new FileOutputStream(archivoactual), "UTF-8");
/* 372 */           out.write(this.text.getText());
/*     */         } finally {
/* 374 */           out.close();
/*     */         } 
/* 376 */       } catch (Exception exception) {}
/*     */     } 
/*     */   }
/*     */   
/*     */   public void doSaveAsCommand() {
/* 381 */     JFileChooser chooser = new JFileChooser(this.path);
/* 382 */     FileNameExtensionFilter filter = new FileNameExtensionFilter("R-Info", new String[] { "rinfo" });
/* 383 */     chooser.setFileFilter(filter);
/*     */     
/* 385 */     if (chooser.showSaveDialog(this.text) == 0) {
/*     */       File fFileName;
/* 387 */       if ("Archivo RINFO".equals(chooser.getTypeDescription(chooser.getSelectedFile()))) {
/* 388 */         fFileName = chooser.getSelectedFile();
/* 389 */         archivoactual = fFileName.getAbsolutePath();
/*     */       } else {
/*     */         
/* 392 */         fFileName = new File(chooser.getSelectedFile() + ".rinfo");
/*     */       } 
/* 394 */       Writer out = null;
/*     */       try {
/*     */         try {
/* 397 */           out = new OutputStreamWriter(new FileOutputStream(fFileName), "UTF-8");
/* 398 */           out.write(this.text.getText());
/*     */         } finally {
/* 400 */           out.close();
/*     */         } 
/* 402 */       } catch (Exception exception) {}
/*     */     } 
/*     */   }
/*     */   
/*     */   public void keyPressed(KeyEvent e) {}
/*     */   
/*     */   public void doCompileCommand() throws Exception {
/*     */     try {
/* 410 */       Programa[] prgAST = { null };
/* 411 */       String code = this.text.getText();
/* 412 */       MonitorEsquinas esquinas = MonitorEsquinas.crearMonitorEsquinas();
/* 413 */       if (code.length() > 0) {
/* 414 */         this.city.robots = new ArrayList<>();
/* 415 */         this.city.areas = new ArrayList<>();
/* 416 */         Parser[] parser = { null };
/*     */         try {
/* 418 */           if (this.city.getCantidad_robots() > 0) {
/* 419 */             this.city.form.c.conf.remove(9);
/* 420 */             (this.city.form.c.conf.JP = new TablaRobot(this.city)).setBorder(new TitledBorder("ROBOTS"));
/* 421 */             this.city.form.c.conf.add(this.city.form.c.conf.JP, this.city.form.c.conf.gbc);
/* 422 */             this.city.form.c.conf.JP.repaint();
/*     */           } 
/* 424 */           parser[0] = new Parser(code, this.city);
/* 425 */           prgAST[0] = parser[0].parse();
/* 426 */           this.city.robots = new ArrayList<>();
/* 427 */           this.city.areas = new ArrayList<>();
/* 428 */           this.city.form.c.conf.remove(9);
/* 429 */           (this.city.form.c.conf.JP = new TablaRobot(this.city)).setBorder(new TitledBorder("ROBOTS"));
/* 430 */           this.city.form.c.conf.add(this.city.form.c.conf.JP, this.city.form.c.conf.gbc);
/* 431 */           this.city.form.c.conf.JP.repaint();
/* 432 */           this.city.form.c.conf.repaint();
/* 433 */           this.city.form.compedos.iv.tempPanel.removeAll();
/* 434 */           ((InspectorVariables.RobotsEnEjecucion)this.city.form.compedos.iv.tempPanelRobots).removeAll();
/* 435 */           this.city.form.compedos.iv.datos_robots = new ArrayList<>();
/* 436 */           this.city.form.compedos.iv.tempPanel.add(this.city.form.compedos.iv.form());
/* 437 */           this.city.form.compedos.iv.tempPanelRobots = this.city.form.compedos.iv.form2();
/* 438 */           this.city.form.compedos.iv.repaint();
/* 439 */           this.city.robots = new ArrayList<>();
/* 440 */           this.city.areas = new ArrayList<>();
/* 441 */           parser[0] = new Parser(code, this.city);
/* 442 */           prgAST[0] = parser[0].parse();
/*     */           try {
/* 444 */             for (Robot r : this.city.robots) {
/* 445 */               r.crearMonitor(this.city.robots.size());
/*     */             }
/* 447 */             this.esperarRefresco.setCantidad(this.city.robots.size());
/* 448 */             this.city.form.monitorCola.setCant_robots(this.city.robots.size());
/* 449 */             System.out.println("cantidad de robots en la ciudad " + this.city.robots.size());
/* 450 */             this.city.form.monitorCola.setCant_ejecutandose(this.city.robots.size());
/* 451 */             System.out.println("cantidad ejecutandose " + this.city.robots.size());
/* 452 */             prgAST[0].setCity(this.city);
/* 453 */             prgAST[0].setCodigo(this);
/* 454 */             this.exec1 = new Ejecucion(prgAST[0], false, this);
/* 455 */             this.thread = new Thread(this.exec1);
/* 456 */             this.exec2 = new ttt(this.esperarRefresco, Integer.valueOf(this.slider.getValue()));
/* 457 */             this.threadVentana = new Thread(this.exec2);
/* 458 */             this.runButton.setEnabled(true);
/* 459 */             this.stepButton.setEnabled(true);
/*     */           }
/* 461 */           catch (Exception e) {
/* 462 */             parser[0].reportParseError("Error en Ejecutar!!:\n" + e);
/* 463 */             this.runButton.setEnabled(true);
/* 464 */             habilitarTodo();
/*     */           }
/*     */         
/* 467 */         } catch (Exception e) {
/* 468 */           parser[0].reportParseError("Error en compilación :\n" + e);
/* 469 */           this.runButton.setEnabled(true);
/* 470 */           habilitarTodo();
/*     */         } 
/* 472 */         this.city.form.jsp.refresh();
/*     */       } else {
/*     */         
/* 475 */         JOptionPane.showMessageDialog(this, "No hay código para compilar...");
/* 476 */         habilitarTodo();
/*     */       }
/*     */     
/* 479 */     } catch (Exception e2) {
/* 480 */       System.out.println("Error en catch");
/* 481 */       System.out.println(e2.toString());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void doRunCommand() throws Exception {
/* 486 */     this.stopButton.setEnabled(true);
/* 487 */     this.pauseButton.setEnabled(true);
/* 488 */     this.compileButton.setEnabled(false);
/* 489 */     if (this.esperarRefresco.isEn_ejecucion()) {
/* 490 */       this.esperarRefresco.despertarPause();
/*     */     } else {
/*     */       
/* 493 */       this.esperarRefresco.setTimerOn(true);
/* 494 */       this.thread.start();
/* 495 */       this.threadVentana.start();
/* 496 */       this.runButton.setEnabled(false);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void habilitarTodo() {
/* 501 */     this.saveButton.setEnabled(true);
/* 502 */     this.newButton.setEnabled(true);
/* 503 */     this.openButton.setEnabled(true);
/* 504 */     this.runButton.setEnabled(false);
/* 505 */     this.resetButton.setEnabled(true);
/* 506 */     this.stepButton.setEnabled(false);
/* 507 */     this.stopButton.setEnabled(false);
/* 508 */     this.pauseButton.setEnabled(false);
/* 509 */     this.compileButton.setEnabled(true);
/*     */   }
/*     */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\CodePanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */