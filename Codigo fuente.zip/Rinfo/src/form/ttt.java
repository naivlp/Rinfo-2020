/*    */ package form;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ttt
/*    */   implements Runnable
/*    */ {
/*    */   MonitorActualizarVentana m;
/*    */   
/*    */   public ttt(MonitorActualizarVentana m, Object object) {
/* 12 */     this.m = m;
/* 13 */     int velocidad = ((Integer)object).intValue();
/* 14 */     m.setSpeed(101 - velocidad);
/*    */   }
/*    */ 
/*    */   
/*    */   public void run() {
/* 19 */     if (this.m.isTimerOn())
/* 20 */       this.m.startTimer(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\form\ttt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */