/*    */ package arbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Identificador
/*    */   extends AST
/*    */ {
/*    */   String spelling;
/*    */   
/*    */   public Identificador(String spelling) {
/* 12 */     this.spelling = spelling;
/*    */   }
/*    */   
/*    */   public boolean equals(String str) {
/* 16 */     return this.spelling.equals(str);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 21 */     return this.spelling;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\Identificador.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */