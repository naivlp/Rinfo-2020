/*    */ package arbol.llamada;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.expresion.Expresion;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Pos
/*    */   extends Llamada
/*    */ {
/*    */   int ciclo;
/*    */   
/*    */   public int getCiclo() {
/* 17 */     return this.ciclo;
/*    */   }
/*    */ 
/*    */   
/*    */   public Llamada nuevo() throws Exception {
/* 22 */     return new Pos(getDV());
/*    */   }
/*    */ 
/*    */   
/*    */   public void ejecutar(ArrayList<Expresion> E) throws Exception {
/* 27 */     synchronized (this) {
/* 28 */       for (Expresion exp : E) {
/* 29 */         exp.setRobot(getRobot());
/*    */       }
/* 31 */       int x = Integer.parseInt(((Expresion)E.get(0)).getValue(this.DV));
/* 32 */       int y = Integer.parseInt(((Expresion)E.get(1)).getValue(this.DV));
/* 33 */       if (x <= 0 || x >= 101 || y <= 0 || y >= 101) {
/* 34 */         getPrograma().getCity().parseError("Se esperaba valor numerico mayor a 0 (cero) en la instrucción Pos y menor a 100(cien)");
/* 35 */         throw new Exception("Se esperaba valor numerico mayor a 0 (cero) en la instrucción Pos y menor a 100(cien)");
/*    */       } 
/* 37 */       if (getPrograma().getCity().HayObstaculo(x, y)) {
/* 38 */         getPrograma().getCity().parseError("No se puede ejecutar la instrucción Pos ya que en esa posición hay un Obstaculo");
/* 39 */         throw new Exception("No se puede ejecutar la instrucción Pos ya que en esa posición hay un Obstaculo");
/*    */       } 
/* 41 */       getRobot().Pos(x, y);
/*    */     } 
/*    */   }
/*    */   
/*    */   public Pos(DeclaracionVariable DV) {
/* 46 */     this.ciclo = 1;
/* 47 */     this.DV = DV;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\llamada\Pos.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */