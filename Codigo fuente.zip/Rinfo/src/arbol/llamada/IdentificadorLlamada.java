/*     */ package arbol.llamada;
/*     */ 
/*     */ import arbol.DeclaracionProcesos;
/*     */ import arbol.DeclaracionVariable;
/*     */ import arbol.Identificador;
/*     */ import arbol.ParametroFormal;
/*     */ import arbol.Proceso;
/*     */ import arbol.Tipo;
/*     */ import arbol.Variable;
/*     */ import arbol.expresion.Expresion;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IdentificadorLlamada
/*     */   extends Llamada
/*     */ {
/*     */   Identificador I;
/*     */   DeclaracionProcesos DP;
/*     */   
/*     */   public IdentificadorLlamada(Identificador I, DeclaracionVariable DV) {
/*  25 */     this.I = null;
/*  26 */     this.DP = null;
/*  27 */     this.I = I;
/*  28 */     this.DV = DV;
/*     */   }
/*     */ 
/*     */   
/*     */   public Llamada nuevo() throws Exception {
/*  33 */     return new IdentificadorLlamada(this.I, this.DV);
/*     */   }
/*     */ 
/*     */   
/*     */   public void ejecutar(ArrayList<Expresion> E) throws Exception {
/*  38 */     synchronized (this) {
/*  39 */       for (Expresion exp : E) {
/*  40 */         exp.setRobot(getRobot());
/*     */       }
/*  42 */       ArrayList<Variable> devolverValorOrigen = new ArrayList<>();
/*  43 */       ArrayList<Variable> devolverValorDestino = new ArrayList<>();
/*  44 */       String spelling = this.I.toString();
/*  45 */       Proceso proc = null;
/*  46 */       this.DP = getRobot().getProcAST();
/*  47 */       if (!this.DP.estaProceso(spelling)) {
/*  48 */         getPrograma().getCity().parseError("Error, instrucción desconocida: " + spelling);
/*  49 */         throw new Exception("Error, instrucción desconocida: " + spelling);
/*     */       } 
/*  51 */       proc = this.DP.getProceso(spelling);
/*  52 */       if (proc.getPF().size() != E.size()) {
/*  53 */         this.programa.getCity().parseError("Los parametros no coinciden en el proceso " + proc.getI().toString());
/*  54 */         throw new Exception("Los parametros actuales no coinciden con los parametros formales");
/*     */       } 
/*  56 */       if (proc.getPF().size() > 0) {
/*  57 */         for (int i = 0; i < proc.getPF().size(); i++) {
/*  58 */           if (((ParametroFormal)proc.getPF().get(i)).getTA().equals("ES")) {
/*     */             try {
/*  60 */               Variable a = this.DV.findByName(((Expresion)E.get(i)).getI().toString());
/*  61 */               if (!this.DV.EstaParametro(a.getI().toString())) {
/*  62 */                 getPrograma().getCity().parseError("Se esperaba una variable en la posición del parametro ES " + ((ParametroFormal)proc.getPF().get(i)).getI().toString());
/*  63 */                 throw new Exception("Se esperaba una variable en la posición del parametro ES " + ((ParametroFormal)proc.getPF().get(i)).getI().toString());
/*     */               } 
/*  65 */               if ((((ParametroFormal)proc.getPF().get(i)).getT()).tipo != (a.getT()).tipo) {
/*  66 */                 getPrograma().getCity().parseError("Se esperaba una variable de tipo " + ((ParametroFormal)proc.getPF().get(i)).getT().toString() + " en el parametro " + ((ParametroFormal)proc.getPF().get(i)).getI().toString());
/*  67 */                 throw new Exception("Se esperaba una variable de tipo " + ((ParametroFormal)proc.getPF().get(i)).getT().toString() + " en el parametro " + ((ParametroFormal)proc.getPF().get(i)).getI().toString());
/*     */               }
/*     */             
/*  70 */             } catch (Exception ex) {
/*  71 */               getPrograma().getCity().parseError("Se esperaba una variable de tipo " + ((ParametroFormal)proc.getPF().get(i)).getT().toString() + " en la posición del parametro ES " + ((ParametroFormal)proc.getPF().get(i)).getI().toString());
/*  72 */               throw new Exception(ex.toString());
/*     */             } 
/*     */           }
/*  75 */           if (((ParametroFormal)proc.getPF().get(i)).getTA().equals("E")) {
/*  76 */             if (((Expresion)E.get(i)).getT() == null) {
/*  77 */               if ((((Expresion)E.get(i)).getValue(this.DV).equals("V") || ((Expresion)E.get(i)).getValue(this.DV).equals("F")) && ((ParametroFormal)proc.getPF().get(i)).getT().toString().equals("numero")) {
/*  78 */                 getPrograma().getCity().parseError("El proceso " + ((ParametroFormal)proc.getPF().get(i)).getI().toString() + " esperaba recibir un parametro de tipo " + ((ParametroFormal)proc.getPF().get(i)).getT().toString());
/*  79 */                 throw new Exception("El proceso " + ((ParametroFormal)proc.getPF().get(i)).getI().toString() + " esperaba recibir un parametro de tipo " + ((ParametroFormal)proc.getPF().get(i)).getT().toString());
/*     */               } 
/*  81 */               if (!((Expresion)E.get(i)).getValue(this.DV).equals("V") && !((Expresion)E.get(i)).getValue(this.DV).equals("F") && ((ParametroFormal)proc.getPF().get(i)).getT().toString().equals("boolean")) {
/*  82 */                 getPrograma().getCity().parseError("El proceso " + ((ParametroFormal)proc.getPF().get(i)).getI().toString() + " esperaba recibir un parametro de tipo " + ((ParametroFormal)proc.getPF().get(i)).getT().toString());
/*  83 */                 throw new Exception("El proceso " + ((ParametroFormal)proc.getPF().get(i)).getI().toString() + " esperaba recibir un parametro de tipo " + ((ParametroFormal)proc.getPF().get(i)).getT().toString());
/*     */               }
/*     */             
/*  86 */             } else if (!((ParametroFormal)proc.getPF().get(i)).getT().toString().equals(((Expresion)E.get(i)).getT().toString())) {
/*  87 */               getPrograma().getCity().parseError("El proceso " + ((ParametroFormal)proc.getPF().get(i)).getI().toString() + " esperaba recibir un parametro de tipo " + ((ParametroFormal)proc.getPF().get(i)).getT().toString());
/*  88 */               throw new Exception("El proceso " + ((ParametroFormal)proc.getPF().get(i)).getI().toString() + " esperaba recibir un parametro de tipo " + ((ParametroFormal)proc.getPF().get(i)).getT().toString());
/*     */             } 
/*     */           }
/*     */         } 
/*     */       }
/*  93 */       if (E.size() > 0) {
/*  94 */         for (int aux = E.size(), j = 0; j < aux; j++) {
/*  95 */           Variable var = new Variable(((ParametroFormal)proc.getPF().get(j)).getI(), ((ParametroFormal)proc.getPF().get(j)).getT(), this.DV, null, null);
/*  96 */           var.setValue(((Expresion)E.get(j)).getValue(this.DV));
/*  97 */           ((ParametroFormal)this.DP.getProceso(spelling).getPF().get(j)).setValue(((Expresion)E.get(j)).getValue(this.DV));
/*  98 */           if (this.DP.getProceso(spelling).getDV().EstaVariable(((ParametroFormal)this.DP.getProceso(spelling).getPF().get(j)).getI().toString())) {
/*  99 */             this.DP.getProceso(spelling).getDV().findByName(((ParametroFormal)this.DP.getProceso(spelling).getPF().get(j)).getI().toString()).setValue(((Expresion)E.get(j)).getValue(this.DV));
/*     */           } else {
/*     */             
/* 102 */             (this.DP.getProceso(spelling).getDV()).variables.add(var);
/* 103 */             Variable var2 = new Variable(new Identificador("pepe"), new Tipo((byte)19), this.DV, null, null);
/* 104 */             var2.setValue("222222");
/* 105 */             (this.DP.getProceso(spelling).getDV()).variables.add(var2);
/*     */           } 
/* 107 */           if (((ParametroFormal)proc.getPF().get(j)).getTA().equals("ES")) {
/* 108 */             devolverValorOrigen.add(var);
/* 109 */             Variable var3 = (Variable)E.get(j);
/* 110 */             devolverValorDestino.add(var3);
/*     */           } 
/*     */         } 
/*     */       }
/* 114 */       proc.getC().setPrograma(getPrograma());
/* 115 */       proc.getC().setRobot(getRobot());
/* 116 */       proc.getC().ejecutar();
/* 117 */       if (devolverValorOrigen.size() > 0) {
/* 118 */         for (int x = devolverValorOrigen.size(), k = 0; k < x; k++) {
/* 119 */           ((Variable)devolverValorDestino.get(k)).setValue(((Variable)devolverValorOrigen.get(k)).getValue(proc.getDV()));
/*     */         }
/*     */       }
/* 122 */       if (devolverValorDestino.size() > 0)
/* 123 */         for (int z = devolverValorOrigen.size(), k = 0; k < z; k++) {
/* 124 */           Variable exp2 = devolverValorDestino.get(k);
/* 125 */           Variable exp3 = null;
/* 126 */           this.DV.findByName(exp2.getI().toString()).setValue(exp2.getValor());
/*     */         }  
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\llamada\IdentificadorLlamada.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */