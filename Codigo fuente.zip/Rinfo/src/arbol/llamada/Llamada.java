/*    */ package arbol.llamada;
/*    */ 
/*    */ import arbol.AST;
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.expresion.Expresion;
/*    */ import form.Robot;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Llamada
/*    */   extends AST
/*    */ {
/*    */   DeclaracionVariable DV;
/*    */   Robot r;
/*    */   
/*    */   public DeclaracionVariable getDV() {
/* 19 */     return this.DV;
/*    */   }
/*    */   
/*    */   public void setDV(DeclaracionVariable DV) {
/* 23 */     this.DV = DV;
/*    */   }
/*    */   
/*    */   public Robot getRobot() {
/* 27 */     return this.r;
/*    */   }
/*    */   
/*    */   public void setRobot(Robot r) {
/* 31 */     this.r = r;
/*    */   }
/*    */ 
/*    */   
/*    */   public void ejecutar(ArrayList<Expresion> E) throws Exception {}
/*    */   
/*    */   public Llamada nuevo() throws Exception {
/* 38 */     throw new Exception("error en nuevo llamada , similar al clone");
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\llamada\Llamada.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */