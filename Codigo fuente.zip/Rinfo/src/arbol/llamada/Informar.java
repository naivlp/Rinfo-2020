/*    */ package arbol.llamada;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.expresion.Expresion;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Informar
/*    */   extends Llamada
/*    */ {
/*    */   int ciclo;
/*    */   DeclaracionVariable DV;
/*    */   String msg;
/*    */   String str;
/*    */   
/*    */   public int getCiclo() {
/* 20 */     return this.ciclo;
/*    */   }
/*    */   
/*    */   public Informar(DeclaracionVariable DV, String s) {
/* 24 */     this.ciclo = 1;
/* 25 */     this.msg = "";
/* 26 */     this.str = "";
/* 27 */     this.DV = DV;
/* 28 */     this.str = s;
/*    */   }
/*    */ 
/*    */   
/*    */   public DeclaracionVariable getDV() {
/* 33 */     return this.DV;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setDV(DeclaracionVariable DV) {
/* 38 */     this.DV = DV;
/*    */   }
/*    */ 
/*    */   
/*    */   public void ejecutar(ArrayList<Expresion> E) throws Exception {
/* 43 */     synchronized (this) {
/* 44 */       this.msg = getRobot().getNombre() + " informa: ";
/* 45 */       this.msg += " " + this.str;
/* 46 */       for (Expresion exp : E) {
/* 47 */         exp.setRobot(getRobot());
/* 48 */         this.msg += " " + exp.getValue(this.DV) + " ";
/*    */       } 
/* 50 */       getRobot().Informar(this.msg);
/* 51 */       this.msg = "";
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Llamada nuevo() throws Exception {
/* 57 */     return new Informar(this.DV, this.str);
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\llamada\Informar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */