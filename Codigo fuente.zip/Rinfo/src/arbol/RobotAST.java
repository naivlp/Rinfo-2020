/*    */ package arbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RobotAST
/*    */   extends AST
/*    */ {
/*    */   private Cuerpo cuerpo;
/*    */   private DeclaracionVariable DV;
/*    */   private String nombre;
/*    */   private DeclaracionProcesos procAST;
/*    */   
/*    */   public RobotAST(Cuerpo c, DeclaracionVariable dv, String nom, DeclaracionProcesos procAST) {
/* 15 */     this.cuerpo = c;
/* 16 */     this.DV = dv;
/* 17 */     this.nombre = nom;
/* 18 */     this.procAST = procAST;
/*    */   }
/*    */   
/*    */   public DeclaracionVariable getDV() {
/* 22 */     return this.DV;
/*    */   }
/*    */   
/*    */   public void setDV(DeclaracionVariable DV) {
/* 26 */     this.DV = DV;
/*    */   }
/*    */   
/*    */   public Cuerpo getCuerpo() {
/* 30 */     return this.cuerpo;
/*    */   }
/*    */   
/*    */   public void setCuerpo(Cuerpo cuerpo) {
/* 34 */     this.cuerpo = cuerpo;
/*    */   }
/*    */   
/*    */   public String getNombre() {
/* 38 */     return this.nombre;
/*    */   }
/*    */   
/*    */   public void setNombre(String nombre) {
/* 42 */     this.nombre = nombre;
/*    */   }
/*    */   
/*    */   public DeclaracionProcesos getProcAST() {
/* 46 */     return this.procAST;
/*    */   }
/*    */   
/*    */   public void setProcAST(DeclaracionProcesos procAST) {
/* 50 */     this.procAST = procAST;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\RobotAST.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */