/*    */ package arbol;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeclaracionRobots
/*    */ {
/*    */   public ArrayList<RobotAST> robots;
/*    */   
/*    */   public DeclaracionRobots(ArrayList<RobotAST> robots) {
/* 14 */     this.robots = robots;
/*    */   }
/*    */   
/*    */   public ArrayList<RobotAST> getRobots() {
/* 18 */     return this.robots;
/*    */   }
/*    */   
/*    */   public void setRobots(ArrayList<RobotAST> robots) {
/* 22 */     this.robots = robots;
/*    */   }
/*    */   
/*    */   public boolean estaRobot(String spelling) {
/* 26 */     for (int i = 0; i < this.robots.size(); i++) {
/* 27 */       if (((RobotAST)this.robots.get(i)).getNombre().equals(spelling)) {
/* 28 */         return true;
/*    */       }
/*    */     } 
/* 31 */     return false;
/*    */   }
/*    */   
/*    */   public RobotAST getRobot(String spelling) {
/* 35 */     RobotAST proc = null;
/* 36 */     for (int i = 0; i < this.robots.size(); i++) {
/* 37 */       if (((RobotAST)this.robots.get(i)).getNombre().equals(spelling)) {
/* 38 */         return this.robots.get(i);
/*    */       }
/*    */     } 
/* 41 */     System.out.println("No devolvi nada en el getRobot del Declaracion Robots");
/* 42 */     return proc;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\DeclaracionRobots.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */