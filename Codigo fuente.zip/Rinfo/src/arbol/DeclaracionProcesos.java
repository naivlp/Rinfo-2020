/*    */ package arbol;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeclaracionProcesos
/*    */   extends AST
/*    */ {
/*    */   public ArrayList<Proceso> procesos;
/*    */   
/*    */   public ArrayList<Proceso> getProcesos() {
/* 14 */     return this.procesos;
/*    */   }
/*    */   
/*    */   public void setProcesos(ArrayList<Proceso> procesos) {
/* 18 */     this.procesos = procesos;
/*    */   }
/*    */   
/*    */   public DeclaracionProcesos(ArrayList<Proceso> procesos) {
/* 22 */     this.procesos = procesos;
/*    */   }
/*    */   
/*    */   public boolean estaProceso(String spelling) {
/* 26 */     for (int i = 0; i < this.procesos.size(); i++) {
/* 27 */       if (((Proceso)this.procesos.get(i)).I.spelling.equals(spelling)) {
/* 28 */         return true;
/*    */       }
/*    */     } 
/* 31 */     return false;
/*    */   }
/*    */   
/*    */   public Proceso getProceso(String spelling) {
/* 35 */     Proceso proc = null;
/* 36 */     for (int i = 0; i < this.procesos.size(); i++) {
/* 37 */       if (((Proceso)this.procesos.get(i)).I.spelling.equals(spelling)) {
/* 38 */         return this.procesos.get(i);
/*    */       }
/*    */     } 
/* 41 */     return proc;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\DeclaracionProcesos.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */