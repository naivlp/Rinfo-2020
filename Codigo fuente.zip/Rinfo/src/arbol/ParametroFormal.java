/*    */ package arbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParametroFormal
/*    */   extends AST
/*    */ {
/*    */   Identificador I;
/*    */   Tipo T;
/*    */   String TA;
/*    */   public String value;
/*    */   
/*    */   public Identificador getI() {
/* 15 */     return this.I;
/*    */   }
/*    */   
/*    */   public void setI(Identificador I) {
/* 19 */     this.I = I;
/*    */   }
/*    */   
/*    */   public Tipo getT() {
/* 23 */     return this.T;
/*    */   }
/*    */   
/*    */   public void setT(Tipo T) {
/* 27 */     this.T = T;
/*    */   }
/*    */   
/*    */   public String getTA() {
/* 31 */     return this.TA;
/*    */   }
/*    */   
/*    */   public void setTA(String TA) {
/* 35 */     this.TA = TA;
/*    */   }
/*    */   
/*    */   public String getValue() {
/* 39 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setValue(String value) {
/* 43 */     this.value = value;
/*    */   }
/*    */   
/*    */   public ParametroFormal(Identificador I, Tipo T, String TA) {
/* 47 */     this.I = I;
/* 48 */     this.T = T;
/* 49 */     this.TA = TA;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\ParametroFormal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */