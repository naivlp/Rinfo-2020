/*    */ package arbol;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Proceso
/*    */   extends AST
/*    */ {
/*    */   Identificador I;
/*    */   ArrayList<ParametroFormal> PF;
/*    */   DeclaracionProcesos DP;
/*    */   DeclaracionVariable DV;
/*    */   Cuerpo C;
/*    */   
/*    */   public Proceso(Identificador I, ArrayList<ParametroFormal> PF, DeclaracionProcesos DP, DeclaracionVariable DV, Cuerpo C) {
/* 18 */     this.I = I;
/* 19 */     this.PF = PF;
/* 20 */     this.DP = DP;
/* 21 */     this.DV = DV;
/* 22 */     this.C = C;
/*    */   }
/*    */   
/*    */   public Cuerpo getC() {
/* 26 */     return this.C;
/*    */   }
/*    */   
/*    */   public void setC(Cuerpo C) {
/* 30 */     this.C = C;
/*    */   }
/*    */   
/*    */   public DeclaracionProcesos getDP() {
/* 34 */     return this.DP;
/*    */   }
/*    */   
/*    */   public void setDP(DeclaracionProcesos DP) {
/* 38 */     this.DP = DP;
/*    */   }
/*    */   
/*    */   public DeclaracionVariable getDV() {
/* 42 */     return this.DV;
/*    */   }
/*    */   
/*    */   public void setDV(DeclaracionVariable DV) {
/* 46 */     this.DV = DV;
/*    */   }
/*    */   
/*    */   public Identificador getI() {
/* 50 */     return this.I;
/*    */   }
/*    */   
/*    */   public void setI(Identificador I) {
/* 54 */     this.I = I;
/*    */   }
/*    */   
/*    */   public ArrayList<ParametroFormal> getPF() {
/* 58 */     return this.PF;
/*    */   }
/*    */   
/*    */   public void setPF(ArrayList<ParametroFormal> PF) {
/* 62 */     this.PF = PF;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\Proceso.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */