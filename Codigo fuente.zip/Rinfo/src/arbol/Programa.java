/*     */ package arbol;
/*     */ 
/*     */ import form.Ciudad;
/*     */ import form.CodePanel;
/*     */ import form.Robot;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Programa
/*     */   extends AST
/*     */ {
/*     */   Identificador I;
/*     */   DeclaracionRobots DR;
/*     */   DeclaracionProcesos DP;
/*     */   DeclaracionVariable DV;
/*     */   DeclaracionAreas DA;
/*     */   Cuerpo C;
/*     */   Robot R;
/*     */   Ciudad city;
/*     */   CodePanel codigo;
/*     */   
/*     */   public Programa(Identificador I, DeclaracionProcesos DP, DeclaracionVariable DV, DeclaracionRobots DR, Ciudad city, Cuerpo C, DeclaracionAreas DA) {
/*  24 */     this.DP = null;
/*  25 */     setI(I);
/*  26 */     setC(C);
/*  27 */     if (DP != null) {
/*  28 */       setDP(DP);
/*     */     }
/*  30 */     if (DV != null) {
/*  31 */       setDV(DV);
/*     */     }
/*  33 */     setDR(DR);
/*  34 */     setDA(DA);
/*  35 */     this.city = city;
/*     */   }
/*     */   
/*     */   public DeclaracionAreas getDA() {
/*  39 */     return this.DA;
/*     */   }
/*     */   
/*     */   public void setDA(DeclaracionAreas DA) {
/*  43 */     this.DA = DA;
/*     */   }
/*     */   
/*     */   public Cuerpo getC() {
/*  47 */     return this.C;
/*     */   }
/*     */   
/*     */   public DeclaracionProcesos getDP() {
/*  51 */     return this.DP;
/*     */   }
/*     */   
/*     */   public DeclaracionVariable getDV() {
/*  55 */     return this.DV;
/*     */   }
/*     */   
/*     */   public DeclaracionRobots getDR() {
/*  59 */     return this.DR;
/*     */   }
/*     */   
/*     */   public void setDR(DeclaracionRobots DR) {
/*  63 */     this.DR = DR;
/*     */   }
/*     */   
/*     */   public Identificador getI() {
/*  67 */     return this.I;
/*     */   }
/*     */   
/*     */   public Robot getRobot() {
/*  71 */     return this.R;
/*     */   }
/*     */   
/*     */   public void setI(Identificador I) {
/*  75 */     this.I = I;
/*     */   }
/*     */   
/*     */   public void setC(Cuerpo C) {
/*  79 */     (this.C = C).setPrograma(this);
/*     */   }
/*     */   
/*     */   public void setDP(DeclaracionProcesos DP) {
/*  83 */     this.DP = DP;
/*     */   }
/*     */   
/*     */   public void setDV(DeclaracionVariable DV) {
/*  87 */     this.DV = DV;
/*     */   }
/*     */   
/*     */   public void setRobot(Robot R) {
/*  91 */     this.R = R;
/*     */   }
/*     */   
/*     */   public Ciudad getCity() {
/*  95 */     return this.city;
/*     */   }
/*     */   
/*     */   public void setCity(Ciudad c) {
/*  99 */     this.city = c;
/*     */   }
/*     */   
/*     */   public CodePanel getCodigo() {
/* 103 */     return this.codigo;
/*     */   }
/*     */   
/*     */   public void setCodigo(CodePanel codigo) {
/* 107 */     this.codigo = codigo;
/*     */   }
/*     */   
/*     */   public void ejecutar() throws Exception {
/* 111 */     getC().ejecutar();
/*     */   }
/*     */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\Programa.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */