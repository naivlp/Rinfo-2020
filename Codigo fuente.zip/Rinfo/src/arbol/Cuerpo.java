/*    */ package arbol;
/*    */ 
/*    */ import arbol.sentencia.Sentencia;
/*    */ import form.Robot;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Cuerpo
/*    */   extends AST
/*    */ {
/*    */   private ArrayList<Sentencia> S;
/*    */   DeclaracionVariable varAST;
/*    */   Robot rob;
/*    */   
/*    */   public Cuerpo(ArrayList<Sentencia> S, DeclaracionVariable varAST) {
/* 19 */     setS(S);
/* 20 */     this.varAST = varAST;
/*    */   }
/*    */   
/*    */   public void ejecutar() throws Exception {
/* 24 */     for (Sentencia single : this.S) {
/* 25 */       single.setDV(this.varAST);
/* 26 */       single.ejecutar();
/*    */     } 
/*    */   }
/*    */   
/*    */   public Robot getRobot() {
/* 31 */     return this.rob;
/*    */   }
/*    */   
/*    */   public void setRobot(Robot rob) {
/* 35 */     this.rob = rob;
/* 36 */     for (Sentencia single : this.S) {
/* 37 */       single.setRobot(this.rob);
/*    */     }
/*    */   }
/*    */   
/*    */   public ArrayList<Sentencia> getS() {
/* 42 */     return this.S;
/*    */   }
/*    */   
/*    */   public void setS(ArrayList<Sentencia> S) {
/* 46 */     this.S = S;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setPrograma(Programa P) {
/* 51 */     this.programa = P;
/* 52 */     for (Sentencia single : this.S) {
/* 53 */       single.setPrograma(P);
/*    */     }
/*    */   }
/*    */   
/*    */   public void setDV(DeclaracionVariable DV) {
/* 58 */     for (Sentencia single : this.S)
/* 59 */       single.setDV(DV); 
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\Cuerpo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */