/*    */ package arbol;
/*    */ 
/*    */ import form.Area;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeclaracionAreas
/*    */ {
/*    */   public ArrayList<Area> areas;
/*    */   
/*    */   public DeclaracionAreas(ArrayList<Area> areas) {
/* 15 */     this.areas = areas;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\DeclaracionAreas.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */