/*    */ package arbol.sentencia;
/*    */ 
/*    */ import arbol.AST;
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.Programa;
/*    */ import form.Robot;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Sentencia
/*    */   extends AST
/*    */ {
/*    */   DeclaracionVariable varAST;
/*    */   Robot r;
/*    */   
/*    */   public Robot getRobot() {
/* 18 */     return this.r;
/*    */   }
/*    */   
/*    */   public void setRobot(Robot r) {
/* 22 */     this.r = r;
/*    */   }
/*    */ 
/*    */   
/*    */   public void ejecutar() throws Exception {}
/*    */   
/*    */   public void setDV(DeclaracionVariable varAST) {
/* 29 */     this.varAST = varAST;
/*    */   }
/*    */   
/*    */   public DeclaracionVariable getDV() {
/* 33 */     return this.varAST;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setPrograma(Programa P) {
/* 38 */     this.programa = P;
/*    */   }
/*    */ 
/*    */   
/*    */   public Programa getPrograma() {
/* 43 */     return this.programa;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\sentencia\Sentencia.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */