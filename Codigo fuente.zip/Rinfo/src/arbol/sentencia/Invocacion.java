/*    */ package arbol.sentencia;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.Programa;
/*    */ import arbol.expresion.Expresion;
/*    */ import arbol.llamada.Llamada;
/*    */ import form.Robot;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Invocacion
/*    */   extends Sentencia
/*    */ {
/*    */   Llamada L;
/*    */   ArrayList<Expresion> E;
/*    */   
/*    */   public Invocacion(Llamada L, ArrayList<Expresion> E, DeclaracionVariable DV) {
/* 21 */     this.L = null;
/* 22 */     this.E = null;
/* 23 */     this.L = L;
/* 24 */     this.E = E;
/* 25 */     this.varAST = DV;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 30 */     synchronized (this) {
/* 31 */       ArrayList<Expresion> es = new ArrayList<>();
/* 32 */       for (Expresion ee : this.E) {
/* 33 */         Expresion e = (Expresion)ee.clone();
/* 34 */         e.setDV(this.varAST);
/* 35 */         es.add(e);
/*    */       } 
/* 37 */       Llamada ll = null;
/*    */       try {
/* 39 */         ll = this.L.nuevo();
/*    */       }
/* 41 */       catch (Exception ex) {
/* 42 */         System.out.println("Algo anda mal en el clone de invocacion");
/*    */       } 
/* 44 */       return new Invocacion(ll, es, getDV());
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void setRobot(Robot r) {
/* 50 */     for (Expresion ee : this.E) {
/* 51 */       ee.setRobot(r);
/*    */     }
/* 53 */     this.L.setRobot(r);
/*    */   }
/*    */ 
/*    */   
/*    */   public void ejecutar() throws Exception {
/* 58 */     synchronized (this) {
/* 59 */       for (Expresion ee : this.E) {
/* 60 */         ee.setRobot(getRobot());
/*    */       }
/* 62 */       this.L.setDV(getDV());
/* 63 */       this.L.ejecutar(this.E);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void setPrograma(Programa P) {
/* 69 */     this.L.setPrograma(P);
/* 70 */     for (Expresion exp : this.E)
/* 71 */       exp.setPrograma(P); 
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\sentencia\Invocacion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */