/*    */ package arbol.sentencia;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.expresion.Expresion;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Seleccion
/*    */   extends Sentencia
/*    */ {
/*    */   Expresion E;
/*    */   ArrayList<Sentencia> S1;
/*    */   ArrayList<Sentencia> S2;
/*    */   
/*    */   public Seleccion(Expresion E, ArrayList<Sentencia> S1, ArrayList<Sentencia> S2, DeclaracionVariable DV) {
/* 19 */     this.E = E;
/* 20 */     this.S1 = S1;
/* 21 */     this.S2 = S2;
/* 22 */     setDV(DV);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 27 */     ArrayList<Sentencia> S = new ArrayList<>();
/* 28 */     for (Sentencia sen : getS1()) {
/* 29 */       System.out.println("Sentencia  clonada : " + sen.toString());
/* 30 */       Sentencia ss = (Sentencia)sen.clone();
/* 31 */       S.add(ss);
/*    */     } 
/* 33 */     ArrayList<Sentencia> SS2 = new ArrayList<>();
/* 34 */     if (getS2() != null) {
/* 35 */       for (Sentencia sen2 : getS2()) {
/* 36 */         System.out.println("Sentencia  clonada : " + sen2.toString());
/* 37 */         Sentencia sss = (Sentencia)sen2.clone();
/* 38 */         SS2.add(sss);
/*    */       } 
/*    */     }
/* 41 */     Expresion EE = (Expresion)this.E.clone();
/* 42 */     return new Seleccion(EE, S, SS2, getDV());
/*    */   }
/*    */   
/*    */   public Expresion getE() {
/* 46 */     return this.E;
/*    */   }
/*    */   
/*    */   public void setE(Expresion E) {
/* 50 */     this.E = E;
/*    */   }
/*    */   
/*    */   public ArrayList<Sentencia> getS1() {
/* 54 */     return this.S1;
/*    */   }
/*    */   
/*    */   public void setS1(ArrayList<Sentencia> S1) {
/* 58 */     this.S1 = S1;
/*    */   }
/*    */   
/*    */   public ArrayList<Sentencia> getS2() {
/* 62 */     return this.S2;
/*    */   }
/*    */   
/*    */   public void setS2(ArrayList<Sentencia> S2) {
/* 66 */     this.S2 = S2;
/*    */   }
/*    */ 
/*    */   
/*    */   public void ejecutar() throws Exception {
/* 71 */     synchronized (this) {
/* 72 */       this.E.setPrograma(getPrograma());
/* 73 */       this.E.setRobot(getRobot());
/* 74 */       this.E.setDV(getDV());
/* 75 */       if (this.E.getValue(getDV()).equals("V")) {
/* 76 */         for (Sentencia single : this.S1) {
/* 77 */           single.setPrograma(getPrograma());
/* 78 */           single.setRobot(getRobot());
/* 79 */           single.setDV(getDV());
/* 80 */           single.ejecutar();
/*    */         }
/*    */       
/* 83 */       } else if (this.S2 != null) {
/* 84 */         for (Sentencia single : this.S2) {
/* 85 */           single.setPrograma(getPrograma());
/* 86 */           single.setRobot(getRobot());
/* 87 */           single.setDV(getDV());
/* 88 */           single.ejecutar();
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\sentencia\Seleccion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */