/*    */ package arbol.sentencia;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.Programa;
/*    */ import arbol.expresion.Expresion;
/*    */ import form.Robot;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IteradorCondicional
/*    */   extends Sentencia
/*    */ {
/*    */   Expresion E;
/*    */   ArrayList<Sentencia> S;
/*    */   
/*    */   public IteradorCondicional(Expresion E, ArrayList<Sentencia> S, DeclaracionVariable DV) {
/* 20 */     this.E = E;
/* 21 */     this.S = S;
/* 22 */     setDV(DV);
/*    */   }
/*    */ 
/*    */   
/*    */   public void ejecutar() throws Exception {
/* 27 */     this.E.setPrograma(getPrograma());
/* 28 */     this.E.setRobot(getRobot());
/* 29 */     while (this.E.getValue(getDV()).equals("V")) {
/* 30 */       for (Sentencia single : this.S) {
/* 31 */         single.setRobot(getRobot());
/* 32 */         single.ejecutar();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void setPrograma(Programa P) {
/* 39 */     this.programa = P;
/* 40 */     this.E.setPrograma(P);
/* 41 */     for (Sentencia sen : this.S) {
/* 42 */       sen.setPrograma(P);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void setRobot(Robot r) {
/* 48 */     super.setRobot(r);
/* 49 */     this.E.setRobot(r);
/* 50 */     for (Sentencia s : this.S) {
/* 51 */       s.setRobot(r);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void setDV(DeclaracionVariable DV) {
/* 57 */     this.varAST = DV;
/* 58 */     for (Sentencia s : this.S) {
/* 59 */       s.setDV(this.varAST);
/*    */     }
/* 61 */     this.E.setDV(DV);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 66 */     synchronized (this) {
/* 67 */       ArrayList<Sentencia> ss = new ArrayList<>();
/* 68 */       for (Sentencia single : this.S) {
/* 69 */         System.out.println("Intentando clonar en Iterador Condicional: " + single.toString());
/* 70 */         Sentencia sen = (Sentencia)single.clone();
/* 71 */         ss.add(sen);
/*    */       } 
/* 73 */       System.out.println("Intentando clonar la expresion en iterador condicional");
/* 74 */       Expresion e = (Expresion)this.E.clone();
/* 75 */       return new IteradorCondicional(e, ss, getDV());
/*    */     } 
/*    */   }
/*    */   
/*    */   public Expresion getE() {
/* 80 */     return this.E;
/*    */   }
/*    */   
/*    */   public void setE(Expresion E) {
/* 84 */     this.E = E;
/*    */   }
/*    */   
/*    */   public ArrayList<Sentencia> getS() {
/* 88 */     return this.S;
/*    */   }
/*    */   
/*    */   public void setS(ArrayList<Sentencia> S) {
/* 92 */     this.S = S;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\sentencia\IteradorCondicional.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */