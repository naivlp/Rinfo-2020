/*    */ package arbol.sentencia.primitiva;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IniciarRobot
/*    */   extends Primitiva
/*    */ {
/*    */   int x;
/*    */   int y;
/*    */   
/*    */   IniciarRobot(int x, int y) {
/* 13 */     this.x = x;
/* 14 */     this.y = y;
/*    */   }
/*    */ 
/*    */   
/*    */   public void ejecutar() throws Exception {
/* 19 */     getRobot().iniciar(this.x, this.y);
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\sentencia\primitiva\IniciarRobot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */