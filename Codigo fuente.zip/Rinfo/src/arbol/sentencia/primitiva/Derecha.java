/*    */ package arbol.sentencia.primitiva;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.UnknownHostException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Derecha
/*    */   extends Primitiva
/*    */ {
/* 15 */   int ciclo = 1;
/*    */ 
/*    */   
/*    */   public int getCiclo() {
/* 19 */     return this.ciclo;
/*    */   }
/*    */ 
/*    */   
/*    */   public void ejecutar() throws UnknownHostException, IOException {
/* 24 */     getRobot().derecha();
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 29 */     Derecha obj = new Derecha();
/* 30 */     return obj;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\sentencia\primitiva\Derecha.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */