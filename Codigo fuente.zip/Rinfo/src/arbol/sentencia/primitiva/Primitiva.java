/*    */ package arbol.sentencia.primitiva;
/*    */ 
/*    */ import arbol.Identificador;
/*    */ import arbol.sentencia.Sentencia;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Primitiva
/*    */   extends Sentencia
/*    */ {
/*    */   Identificador I;
/*    */   
/*    */   public Identificador getI() {
/* 15 */     return this.I;
/*    */   }
/*    */   
/*    */   public void setI(Identificador I) {
/* 19 */     this.I = I;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\sentencia\primitiva\Primitiva.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */