/*    */ package arbol.sentencia.primitiva;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.expresion.Expresion;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LiberarEsquina
/*    */   extends Primitiva
/*    */ {
/*    */   int ciclo;
/*    */   private int Av;
/*    */   private int Ca;
/*    */   DeclaracionVariable DV;
/*    */   Expresion E3;
/*    */   Expresion E4;
/*    */   
/*    */   public int getCiclo() {
/* 22 */     return this.ciclo;
/*    */   }
/*    */   
/*    */   public LiberarEsquina(Expresion E1, Expresion E2, DeclaracionVariable DV) throws Exception {
/* 26 */     this.ciclo = 1;
/* 27 */     this.DV = DV;
/* 28 */     this.E3 = E1;
/* 29 */     this.E4 = E2;
/*    */   }
/*    */   
/*    */   public int getAv() {
/* 33 */     return this.Av;
/*    */   }
/*    */   
/*    */   public void setAv(int Av) {
/* 37 */     this.Av = Av;
/*    */   }
/*    */   
/*    */   public int getCa() {
/* 41 */     return this.Ca;
/*    */   }
/*    */   
/*    */   public void setCa(int Ca) {
/* 45 */     this.Ca = Ca;
/*    */   }
/*    */ 
/*    */   
/*    */   public void ejecutar() throws Exception {
/* 50 */     synchronized (this) {
/* 51 */       this.DV = getRobot().getVariables();
/* 52 */       this.E3.setRobot(getRobot());
/* 53 */       this.E4.setRobot(getRobot());
/* 54 */       setAv(Integer.parseInt(this.E3.getValue(getDV())));
/* 55 */       setCa(Integer.parseInt(this.E4.getValue(getDV())));
/* 56 */       if (getAv() < 1 || getAv() > 100 || getCa() < 1 || getCa() > 100) {
/* 57 */         getPrograma().getCity().parseError("Se esperaban valores entre 1 y 100 en la primitiva LiberarEsquina");
/* 58 */         throw new Exception("Se esperaban valores entre 1(uno) y 100(cien) en la primitiva LiberarEsquina");
/*    */       } 
/* 60 */       getRobot().liberarEsquina(getAv(), getCa());
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() {
/* 66 */     synchronized (this) {
/* 67 */       LiberarEsquina b = null;
/*    */       try {
/* 69 */         Expresion ee1 = (Expresion)this.E3.clone();
/* 70 */         Expresion ee2 = (Expresion)this.E4.clone();
/* 71 */         b = new LiberarEsquina(ee1, ee2, this.DV);
/*    */       }
/* 73 */       catch (Exception ex) {
/* 74 */         Logger.getLogger(BloquearEsquina.class.getName()).log(Level.SEVERE, (String)null, ex);
/*    */       } 
/* 76 */       return b;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\sentencia\primitiva\LiberarEsquina.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */