/*    */ package arbol.sentencia.primitiva;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.Identificador;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RecibirMensaje
/*    */   extends Primitiva
/*    */ {
/*    */   Identificador NombreRobot;
/*    */   Identificador nombreVariable;
/*    */   
/*    */   public RecibirMensaje(Identificador E, DeclaracionVariable DV, Identificador I) {
/* 16 */     setDV(DV);
/* 17 */     this.NombreRobot = I;
/* 18 */     this.nombreVariable = E;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() {
/* 23 */     return new RecibirMensaje(this.nombreVariable, getDV(), this.NombreRobot);
/*    */   }
/*    */ 
/*    */   
/*    */   public void ejecutar() throws Exception {
/* 28 */     synchronized (this) {
/* 29 */       int id; if (!getRobot().getVariables().EstaVariable(this.nombreVariable.toString())) {
/* 30 */         getPrograma().getCity().parseError("La variable " + this.nombreVariable.toString() + " no esta declarada");
/* 31 */         throw new Exception("La variable " + this.nombreVariable.toString() + " no esta declarada");
/*    */       } 
/*    */       
/* 34 */       if (!this.NombreRobot.toString().equals("*")) {
/* 35 */         id = (getRobot().getCity().getRobotByNombre(this.NombreRobot.toString())).id;
/*    */       } else {
/*    */         
/* 38 */         id = -1;
/*    */       } 
/* 40 */       getRobot().recibirMensaje(this.nombreVariable, id, this.NombreRobot);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\sentencia\primitiva\RecibirMensaje.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */