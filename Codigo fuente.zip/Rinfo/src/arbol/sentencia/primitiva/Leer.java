/*    */ package arbol.sentencia.primitiva;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.expresion.Expresion;
/*    */ import form.LeerVentana;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Leer
/*    */   extends Primitiva
/*    */ {
/*    */   private Expresion E;
/*    */   private DeclaracionVariable DV;
/*    */   
/*    */   public Leer(DeclaracionVariable DV, Expresion E) throws Exception {
/* 17 */     setE(E);
/* 18 */     setDV(DV);
/* 19 */     DV.EstaParametro(E.getI().toString());
/*    */   }
/*    */ 
/*    */   
/*    */   public void ejecutar() throws Exception {
/* 24 */     LeerVentana leerVentana = new LeerVentana(getDV(), getE());
/*    */   }
/*    */   
/*    */   public Expresion getE() {
/* 28 */     return this.E;
/*    */   }
/*    */   
/*    */   public void setE(Expresion E) {
/* 32 */     this.E = E;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\sentencia\primitiva\Leer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */