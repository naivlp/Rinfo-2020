/*    */ package arbol.sentencia.primitiva;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TomarFlor
/*    */   extends Primitiva
/*    */ {
/* 12 */   int ciclo = 1;
/*    */ 
/*    */   
/*    */   public int getCiclo() {
/* 16 */     return this.ciclo;
/*    */   }
/*    */ 
/*    */   
/*    */   public void ejecutar() throws Exception {
/* 21 */     synchronized (this) {
/* 22 */       getRobot().tomarFlor();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 28 */     TomarFlor obj = new TomarFlor();
/* 29 */     return obj;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\sentencia\primitiva\TomarFlor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */