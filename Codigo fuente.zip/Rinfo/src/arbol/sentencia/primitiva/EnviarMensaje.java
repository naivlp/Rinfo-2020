/*    */ package arbol.sentencia.primitiva;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.Identificador;
/*    */ import arbol.expresion.Expresion;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnviarMensaje
/*    */   extends Primitiva
/*    */ {
/*    */   Identificador NombreRobot;
/*    */   Expresion E;
/*    */   
/*    */   public EnviarMensaje(Expresion E, DeclaracionVariable DV, Identificador NombreRobot) {
/* 17 */     setDV(DV);
/* 18 */     this.NombreRobot = NombreRobot;
/* 19 */     this.E = E;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() {
/* 24 */     return new EnviarMensaje(this.E, getDV(), this.NombreRobot);
/*    */   }
/*    */ 
/*    */   
/*    */   public void ejecutar() throws Exception {
/* 29 */     synchronized (this) {
/* 30 */       String nom = getRobot().getNombre();
/* 31 */       this.E.setDV(getDV());
/* 32 */       String x = this.E.getValue(getDV());
/* 33 */       getPrograma().getCity().getRobotByNombre(this.NombreRobot.toString()).almacenarMensaje(nom, x);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\sentencia\primitiva\EnviarMensaje.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */