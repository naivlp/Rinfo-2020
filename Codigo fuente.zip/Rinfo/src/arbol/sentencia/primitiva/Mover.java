/*    */ package arbol.sentencia.primitiva;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Mover
/*    */   extends Primitiva
/*    */ {
/* 12 */   int ciclo = 1;
/*    */ 
/*    */   
/*    */   public int getCiclo() {
/* 16 */     return this.ciclo;
/*    */   }
/*    */ 
/*    */   
/*    */   public void ejecutar() throws Exception {
/* 21 */     this.programa.getCity().setOk(false);
/* 22 */     getRobot().mover();
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 27 */     return new Mover();
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\sentencia\primitiva\Mover.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */