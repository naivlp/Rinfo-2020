/*    */ package arbol.sentencia.primitiva;
/*    */ 
/*    */ import arbol.Cuerpo;
/*    */ import arbol.DeclaracionProcesos;
/*    */ import arbol.DeclaracionRobots;
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.Identificador;
/*    */ import arbol.RobotAST;
/*    */ import arbol.Variable;
/*    */ import arbol.sentencia.Sentencia;
/*    */ import form.EjecucionRobot;
/*    */ import form.Robot;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Iniciar
/*    */   extends Primitiva
/*    */ {
/*    */   RobotAST r;
/*    */   int x;
/*    */   int y;
/*    */   Identificador Ident;
/*    */   DeclaracionRobots robAST;
/*    */   DeclaracionVariable varAST;
/*    */   
/*    */   public Iniciar(Identificador I, int x, int y, DeclaracionRobots robAST, DeclaracionVariable varAST) throws Exception {
/* 30 */     this.varAST = varAST;
/* 31 */     this.robAST = robAST;
/* 32 */     this.Ident = I;
/* 33 */     this.x = x;
/* 34 */     this.y = y;
/* 35 */     if (varAST.EstaVariable(I.toString())) {
/* 36 */       this.r = varAST.findByName(I.toString()).getR();
/* 37 */       System.out.println("para la variable " + I.toString() + " el robot es : " + this.r.getNombre());
/*    */       return;
/*    */     } 
/* 40 */     throw new Exception("El robot tiene que estar declarado en las variables");
/*    */   }
/*    */ 
/*    */   
/*    */   public void ejecutar() throws Exception {
/* 45 */     Robot rob = null;
/* 46 */     Cuerpo cu = this.r.getCuerpo();
/* 47 */     DeclaracionVariable dv = this.r.getDV();
/* 48 */     DeclaracionProcesos procAST = this.r.getProcAST();
/* 49 */     String nom = this.Ident.toString();
/* 50 */     if (this.programa.getCity().estaRobot(nom)) {
/* 51 */       System.out.println("El robot estaba " + nom + " y su tipo es : " + this.r.getNombre());
/* 52 */       rob = this.programa.getCity().getRobotByNombre(nom);
/*    */     } else {
/*    */       
/* 55 */       System.out.println("El robot no estaba : " + nom);
/*    */     } 
/* 57 */     if (rob.esAreaVacia()) {
/* 58 */       String msj = "El robot: " + rob.getNombre() + " no tiene area designada";
/* 59 */       getPrograma().getCity().parseError(msj);
/* 60 */       throw new Exception(msj);
/*    */     } 
/* 62 */     IniciarRobot ini = new IniciarRobot(this.x, this.y);
/* 63 */     ini.setRobot(rob);
/* 64 */     ArrayList<Sentencia> sent = new ArrayList<>();
/* 65 */     sent.add(ini);
/* 66 */     for (Sentencia single : cu.getS()) {
/* 67 */       System.out.println("Sentencia clone es : " + single.toString());
/* 68 */       Sentencia i = (Sentencia)single.clone();
/* 69 */       i.setPrograma(getPrograma());
/* 70 */       sent.add(i);
/*    */     } 
/* 72 */     ArrayList<Variable> dvs = new ArrayList<>();
/* 73 */     for (Variable b : dv.variables) {
/* 74 */       dvs.add((Variable)b.clone());
/*    */     }
/* 76 */     DeclaracionVariable fv = new DeclaracionVariable(dvs);
/* 77 */     System.out.println("La cantidad de sentencias de este cuerpo es: " + sent.size());
/* 78 */     cu = new Cuerpo(sent, fv);
/* 79 */     cu.setRobot(rob);
/* 80 */     rob.setVariables(fv);
/* 81 */     rob.setProcAST(procAST);
/* 82 */     rob.setCuerpo(cu);
/* 83 */     rob.getCuerpo().setPrograma(getPrograma());
/* 84 */     EjecucionRobot ejecucionRobot = new EjecucionRobot(rob, false, getPrograma().getCodigo());
/* 85 */     Thread thread = new Thread((Runnable)ejecucionRobot);
/* 86 */     this.programa.getCity().agregarHilo(thread);
/* 87 */     thread.start();
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\sentencia\primitiva\Iniciar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */