/*    */ package arbol.sentencia.primitiva;
/*    */ 
/*    */ import form.Area;
/*    */ import form.Robot;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AsignarArea
/*    */   extends Primitiva
/*    */ {
/*    */   Robot r;
/*    */   Area a;
/*    */   
/*    */   public AsignarArea(Robot robo, Area area) {
/* 16 */     this.r = robo;
/* 17 */     this.a = area;
/*    */   }
/*    */ 
/*    */   
/*    */   public void ejecutar() {
/* 22 */     this.r.agregarArea(this.a);
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\sentencia\primitiva\AsignarArea.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */