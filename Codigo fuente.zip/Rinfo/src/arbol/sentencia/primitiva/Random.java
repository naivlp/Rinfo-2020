/*    */ package arbol.sentencia.primitiva;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.Identificador;
/*    */ import arbol.expresion.Expresion;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Random
/*    */   extends Primitiva
/*    */ {
/*    */   Expresion E1;
/*    */   Expresion E2;
/*    */   
/*    */   public Random(Identificador I, DeclaracionVariable DV, Expresion E1, Expresion E2) throws Exception {
/* 19 */     setDV(DV);
/* 20 */     setI(I);
/* 21 */     setE1(E1);
/* 22 */     setE2(E2);
/* 23 */     boolean ok = getDV().EstaParametro(I.toString());
/* 24 */     if ((getDV().findByName(I.toString()).getT()).tipo != 19) {
/* 25 */       throw new Exception("Se esperaba una variable de tipo número en la primitiva random");
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void ejecutar() throws Exception {
/* 31 */     int desde = Integer.parseInt(getE1().getValue(getDV()));
/* 32 */     int hasta = Integer.parseInt(getE2().getValue(getDV()));
/* 33 */     int aux = (int)(Math.random() * (hasta - desde + 1) + desde);
/* 34 */     String str = String.valueOf(aux);
/* 35 */     getDV().findByName(this.I.toString()).setValue(str);
/*    */   }
/*    */   
/*    */   public Expresion getE1() {
/* 39 */     return this.E1;
/*    */   }
/*    */   
/*    */   public void setE1(Expresion E1) {
/* 43 */     this.E1 = E1;
/*    */   }
/*    */   
/*    */   public Expresion getE2() {
/* 47 */     return this.E2;
/*    */   }
/*    */   
/*    */   public void setE2(Expresion E2) {
/* 51 */     this.E2 = E2;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 56 */     Random obj = null;
/*    */     try {
/* 58 */       obj = new Random(getI(), getDV(), getE1(), getE2());
/*    */     }
/* 60 */     catch (Exception ex) {
/* 61 */       Logger.getLogger(Random.class.getName()).log(Level.SEVERE, (String)null, ex);
/*    */     } 
/* 63 */     return obj;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\sentencia\primitiva\Random.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */