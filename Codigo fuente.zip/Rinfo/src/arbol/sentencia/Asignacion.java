/*    */ package arbol.sentencia;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.Identificador;
/*    */ import arbol.Programa;
/*    */ import arbol.Variable;
/*    */ import arbol.expresion.Expresion;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Asignacion
/*    */   extends Sentencia
/*    */ {
/*    */   Identificador I;
/*    */   Expresion E;
/*    */   DeclaracionVariable DV;
/*    */   
/*    */   public Asignacion(Identificador I, Expresion E, DeclaracionVariable DV) {
/* 20 */     this.I = I;
/* 21 */     this.E = E;
/* 22 */     this.DV = DV;
/*    */   }
/*    */ 
/*    */   
/*    */   public void ejecutar() throws Exception {
/* 27 */     synchronized (this) {
/* 28 */       this.E.setRobot(getRobot());
/* 29 */       if (!this.DV.EstaParametro(this.I.toString())) {
/* 30 */         this.programa.getCity().parseError("Variable: " + this.I.toString() + "no encontrada");
/* 31 */         throw new Exception("Variable: " + this.I.toString() + "no encontrada");
/*    */       } 
/* 33 */       Variable tmp = this.DV.findByName(this.I.toString());
/* 34 */       String eValue = this.E.getValue(this.DV);
/* 35 */       if (tmp.getT().toString().equals("boolean") && !eValue.equals("V") && !eValue.equals("F")) {
/* 36 */         this.programa.getCity().parseError("Se esperaba un valor booleano en la variable/parametro : " + tmp.getI().toString());
/* 37 */         throw new Exception("Se esperaba un valor booleano en la variable/parametro : " + tmp.getI().toString());
/*    */       } 
/* 39 */       if (tmp.getT().toString().equals("numero")) {
/*    */         try {
/* 41 */           System.out.println("e value vale:  " + eValue);
/* 42 */           Integer.parseInt(eValue);
/*    */         }
/* 44 */         catch (Exception ex) {
/* 45 */           this.programa.getCity().parseError("Se esperaba un valor numerico en la variable/parametro : " + tmp.getI().toString());
/* 46 */           throw new Exception("Se esperaba un valor numerico en la variable/parametro : " + tmp.getI().toString());
/*    */         } 
/*    */       }
/* 49 */       this.DV.findByName(this.I.toString()).setValue(eValue);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 55 */     Object obj = null;
/* 56 */     Identificador II = new Identificador(this.I.toString());
/* 57 */     System.out.println("Intentando clonar expresion en asignacion");
/* 58 */     Expresion EE = (Expresion)this.E.clone();
/* 59 */     return new Asignacion(II, EE, this.DV);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setDV(DeclaracionVariable varAST) {
/* 64 */     this.DV = varAST;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setPrograma(Programa P) {
/* 69 */     this.programa = P;
/* 70 */     this.E.setPrograma(P);
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\sentencia\Asignacion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */