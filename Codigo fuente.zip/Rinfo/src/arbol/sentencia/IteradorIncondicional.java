/*    */ package arbol.sentencia;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.Programa;
/*    */ import arbol.expresion.Expresion;
/*    */ import form.Robot;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IteradorIncondicional
/*    */   extends Sentencia
/*    */ {
/*    */   Expresion E;
/*    */   ArrayList<Sentencia> S;
/*    */   
/*    */   public IteradorIncondicional(Expresion E, ArrayList<Sentencia> S, DeclaracionVariable DV) {
/* 20 */     this.E = E;
/* 21 */     this.S = S;
/* 22 */     setDV(DV);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setDV(DeclaracionVariable DV) {
/* 27 */     this.varAST = DV;
/* 28 */     for (Sentencia s : this.S) {
/* 29 */       s.setDV(this.varAST);
/*    */     }
/* 31 */     this.E.setDV(DV);
/*    */   }
/*    */ 
/*    */   
/*    */   public void ejecutar() throws Exception {
/* 36 */     int c = 0;
/* 37 */     this.E.setRobot(getRobot());
/* 38 */     for (c = 0; c < Integer.parseInt(this.E.getValue(getDV())); c++) {
/* 39 */       for (Sentencia single : this.S) {
/* 40 */         single.setRobot(getRobot());
/* 41 */         single.ejecutar();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 48 */     synchronized (this) {
/* 49 */       ArrayList<Sentencia> ss = new ArrayList<>();
/* 50 */       for (Sentencia single : this.S) {
/* 51 */         System.out.println("Intentando clonar en Iterador Incondicional: " + single.toString());
/* 52 */         Sentencia sen = (Sentencia)single.clone();
/* 53 */         ss.add(sen);
/*    */       } 
/* 55 */       return new IteradorIncondicional(this.E, ss, getDV());
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void setRobot(Robot r) {
/* 61 */     super.setRobot(r);
/* 62 */     this.E.setRobot(r);
/* 63 */     for (Sentencia s : this.S) {
/* 64 */       s.setRobot(r);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void setPrograma(Programa P) {
/* 70 */     this.E.setPrograma(P);
/* 71 */     for (Sentencia sen : this.S)
/* 72 */       sen.setPrograma(P); 
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\sentencia\IteradorIncondicional.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */