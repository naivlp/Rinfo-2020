/*    */ package arbol;
/*    */ 
/*    */ import javax.swing.JOptionPane;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AST
/*    */   implements Cloneable
/*    */ {
/*    */   protected Programa programa;
/*    */   
/*    */   public Programa getPrograma() {
/* 15 */     return this.programa;
/*    */   }
/*    */   
/*    */   public void setPrograma(Programa programa) {
/* 19 */     this.programa = programa;
/*    */   }
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 23 */     Object obj = null;
/*    */     try {
/* 25 */       System.out.println("Clone no definido");
/* 26 */       obj = super.clone();
/*    */     }
/* 28 */     catch (CloneNotSupportedException ex) {
/* 29 */       System.out.println(" no se puede duplicar");
/*    */     } 
/* 31 */     return obj;
/*    */   }
/*    */   
/*    */   public void reportError(String str) {
/* 35 */     JOptionPane.showMessageDialog(null, str, "ERROR", 0);
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\AST.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */