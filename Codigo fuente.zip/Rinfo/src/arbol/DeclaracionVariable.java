/*    */ package arbol;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import javax.swing.JOptionPane;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeclaracionVariable
/*    */   extends AST
/*    */ {
/*    */   public ArrayList<Variable> variables;
/*    */   
/*    */   public DeclaracionVariable(ArrayList<Variable> var) {
/* 16 */     this.variables = var;
/*    */   }
/*    */   
/*    */   public boolean EstaParametro(String act) throws Exception {
/*    */     int i;
/* 21 */     for (i = 0; i < this.variables.size(); i++) {
/* 22 */       if (((Variable)this.variables.get(i)).getI().equals(act)) {
/* 23 */         return true;
/*    */       }
/*    */     } 
/* 26 */     if (i == this.variables.size()) {
/* 27 */       reportError("Variable  '" + act + "'  no declarada.");
/* 28 */       throw new Exception("Variable '" + act + "' no declarada.");
/*    */     } 
/* 30 */     return false;
/*    */   }
/*    */   
/*    */   public boolean EstaVariable(String act) throws Exception {
/* 34 */     for (int i = 0; i < this.variables.size(); i++) {
/* 35 */       if (((Variable)this.variables.get(i)).getI().equals(act)) {
/* 36 */         return true;
/*    */       }
/*    */     } 
/* 39 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void reportError(String str) {
/* 44 */     JOptionPane.showMessageDialog(null, str, "ERROR", 0);
/*    */   }
/*    */   
/*    */   public Variable findByName(String act) throws Exception {
/* 48 */     for (int i = 0; i < this.variables.size(); i++) {
/* 49 */       if (((Variable)this.variables.get(i)).getI().toString().equals(act)) {
/* 50 */         return this.variables.get(i);
/*    */       }
/*    */     } 
/* 53 */     reportError("Variable  '" + act + "'  no declarada.");
/* 54 */     throw new Exception("Variable '" + act + "' no declarada.");
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\DeclaracionVariable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */