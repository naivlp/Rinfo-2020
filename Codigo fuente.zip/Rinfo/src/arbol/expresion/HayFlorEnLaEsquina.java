/*    */ package arbol.expresion;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.Tipo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HayFlorEnLaEsquina
/*    */   extends Expresion
/*    */ {
/*    */   public HayFlorEnLaEsquina() {
/* 13 */     setT(new Tipo((byte)20));
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue(DeclaracionVariable DV) {
/* 18 */     int Av = getRobot().PosAv();
/* 19 */     int Ca = getRobot().PosCa();
/* 20 */     boolean hayFlor = getRobot().getCity().HayFlorEnLaEsquina(Av, Ca);
/* 21 */     return hayFlor ? "V" : "F";
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean ejecutar() {
/* 26 */     synchronized (this) {
/* 27 */       String s1 = getValue(this.DV);
/* 28 */       boolean res = s1.equals("V");
/* 29 */       return res;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 35 */     return new HayFlorEnLaEsquina();
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\expresion\HayFlorEnLaEsquina.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */