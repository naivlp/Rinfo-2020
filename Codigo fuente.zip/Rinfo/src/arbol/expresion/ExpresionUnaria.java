/*    */ package arbol.expresion;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.expresion.operador.Operador;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExpresionUnaria
/*    */   extends Expresion
/*    */ {
/*    */   Operador O;
/*    */   Expresion E;
/*    */   
/*    */   public ExpresionUnaria(Operador O, Expresion E) {
/* 16 */     this.O = O;
/* 17 */     (this.E = E).setPrograma(getPrograma());
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue(DeclaracionVariable DV) throws Exception {
/* 22 */     this.O.setRobot(getRobot());
/* 23 */     this.E.setRobot(getRobot());
/* 24 */     return this.O.resultado(this.E.getValue(DV));
/*    */   }
/*    */   
/*    */   public Operador getO() {
/* 28 */     return this.O;
/*    */   }
/*    */   
/*    */   public void setO(Operador O) {
/* 32 */     this.O = O;
/*    */   }
/*    */   
/*    */   public Expresion getE() {
/* 36 */     return this.E;
/*    */   }
/*    */   
/*    */   public void setE(Expresion E) {
/* 40 */     this.E = E;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 45 */     synchronized (this) {
/* 46 */       System.out.println("Entre al clone de expresion unaria");
/* 47 */       Expresion E3 = (Expresion)getE().clone();
/* 48 */       return new ExpresionUnaria(getO(), E3);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\expresion\ExpresionUnaria.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */