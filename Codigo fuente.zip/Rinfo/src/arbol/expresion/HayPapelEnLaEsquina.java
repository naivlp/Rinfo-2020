/*    */ package arbol.expresion;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.Tipo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HayPapelEnLaEsquina
/*    */   extends Expresion
/*    */ {
/*    */   public HayPapelEnLaEsquina() {
/* 13 */     setT(new Tipo((byte)20));
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue(DeclaracionVariable DV) {
/* 18 */     synchronized (this) {
/* 19 */       int Av = getRobot().PosAv();
/* 20 */       int Ca = getRobot().PosCa();
/* 21 */       if (getRobot().getCity().HayPapelEnLaEsquina(Av, Ca)) {
/* 22 */         return "V";
/*    */       }
/* 24 */       return "F";
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 30 */     return new HayPapelEnLaEsquina();
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\expresion\HayPapelEnLaEsquina.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */