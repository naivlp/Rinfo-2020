/*    */ package arbol.expresion;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.Tipo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValorNumerico
/*    */   extends Expresion
/*    */ {
/*    */   String spelling;
/*    */   
/*    */   public ValorNumerico(String spelling) {
/* 15 */     this.spelling = spelling;
/* 16 */     setT(new Tipo((byte)19));
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue(DeclaracionVariable DV) {
/* 21 */     return this.spelling;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 26 */     return new ValorNumerico(this.spelling);
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\expresion\ValorNumerico.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */