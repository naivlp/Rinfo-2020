/*    */ package arbol.expresion;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.Tipo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValorBooleano
/*    */   extends Expresion
/*    */ {
/*    */   String spelling;
/*    */   
/*    */   public ValorBooleano(String spelling) {
/* 15 */     this.spelling = spelling;
/* 16 */     setT(new Tipo((byte)20));
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue(DeclaracionVariable DV) {
/* 21 */     return this.spelling;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 26 */     return new ValorBooleano(this.spelling);
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\expresion\ValorBooleano.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */