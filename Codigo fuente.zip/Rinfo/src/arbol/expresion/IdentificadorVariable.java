/*    */ package arbol.expresion;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.Identificador;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IdentificadorVariable
/*    */   extends Expresion
/*    */ {
/*    */   Identificador I;
/*    */   
/*    */   public IdentificadorVariable(Identificador I) {
/* 15 */     this.I = I;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 20 */     return new IdentificadorVariable(this.I);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue(DeclaracionVariable DV) throws Exception {
/* 25 */     throw new UnsupportedOperationException("Not supported yet.    GetValue IdentificadorVariable");
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\expresion\IdentificadorVariable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */