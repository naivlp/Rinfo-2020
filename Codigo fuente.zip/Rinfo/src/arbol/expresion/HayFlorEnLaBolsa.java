/*    */ package arbol.expresion;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.Tipo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HayFlorEnLaBolsa
/*    */   extends Expresion
/*    */ {
/*    */   public HayFlorEnLaBolsa() {
/* 13 */     setT(new Tipo((byte)20));
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue(DeclaracionVariable DV) {
/* 18 */     synchronized (this) {
/* 19 */       if (getRobot().HayFlorEnLaBolsa()) {
/* 20 */         return "V";
/*    */       }
/* 22 */       return "F";
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 28 */     return new HayFlorEnLaBolsa();
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\expresion\HayFlorEnLaBolsa.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */