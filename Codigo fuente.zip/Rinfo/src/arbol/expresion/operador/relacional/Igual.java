/*    */ package arbol.expresion.operador.relacional;
/*    */ 
/*    */ import arbol.expresion.operador.Operador;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Igual
/*    */   extends Operador
/*    */ {
/*    */   String c;
/*    */   
/*    */   public String resultado(String Op1, String Op2) {
/* 15 */     if (Op1.equals(Op2)) {
/* 16 */       this.c = "V";
/*    */     } else {
/*    */       
/* 19 */       this.c = "F";
/*    */     } 
/* 21 */     return this.c;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 26 */     return new Igual();
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\expresion\operador\relacional\Igual.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */