/*    */ package arbol.expresion.operador.relacional;
/*    */ 
/*    */ import arbol.expresion.operador.Operador;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MayorIgual
/*    */   extends Operador
/*    */ {
/*    */   String c;
/*    */   
/*    */   public String resultado(String Op1, String Op2) {
/* 15 */     int Op1x = Integer.parseInt(Op1);
/* 16 */     int Op2x = Integer.parseInt(Op2);
/* 17 */     if (Op1x >= Op2x) {
/* 18 */       this.c = "V";
/*    */     } else {
/*    */       
/* 21 */       this.c = "F";
/*    */     } 
/* 23 */     return this.c;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 28 */     return new MayorIgual();
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\expresion\operador\relacional\MayorIgual.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */