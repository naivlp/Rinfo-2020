/*    */ package arbol.expresion.operador.relacional;
/*    */ 
/*    */ import arbol.expresion.operador.Operador;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Distinto
/*    */   extends Operador
/*    */ {
/*    */   String c;
/*    */   
/*    */   public String resultado(String Op1, String Op2) {
/* 15 */     if (Op1.equals(Op2)) {
/* 16 */       this.c = "F";
/*    */     } else {
/*    */       
/* 19 */       this.c = "V";
/*    */     } 
/* 21 */     return this.c;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 26 */     return new Distinto();
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\expresion\operador\relacional\Distinto.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */