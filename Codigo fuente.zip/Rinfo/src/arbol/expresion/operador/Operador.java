/*    */ package arbol.expresion.operador;
/*    */ 
/*    */ import arbol.expresion.Expresion;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Operador
/*    */   extends Expresion
/*    */ {
/*    */   public String resultado(String Op1) throws Exception {
/* 12 */     return "undefined";
/*    */   }
/*    */   
/*    */   public String resultado(String Op1, String Op2) {
/* 16 */     return "undeefined";
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\expresion\operador\Operador.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */