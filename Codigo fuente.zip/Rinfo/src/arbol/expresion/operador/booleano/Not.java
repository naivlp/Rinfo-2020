/*    */ package arbol.expresion.operador.booleano;
/*    */ 
/*    */ import arbol.expresion.operador.Operador;
/*    */ import javax.swing.JOptionPane;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Not
/*    */   extends Operador
/*    */ {
/*    */   boolean a;
/*    */   boolean c;
/*    */   
/*    */   public String resultado(String Op1) throws Exception {
/* 18 */     if ("V".equals(Op1)) {
/* 19 */       this.c = true;
/*    */     } else {
/*    */       
/* 22 */       if (!"F".equals(Op1)) {
/* 23 */         parseError("Se esperaba un valor booleano para la operación negación");
/* 24 */         throw new Exception("Se esperaba un valor booleano para la operación negación");
/*    */       } 
/* 26 */       this.c = false;
/*    */     } 
/* 28 */     this.a = !this.c;
/* 29 */     return this.a ? "V" : "F";
/*    */   }
/*    */   
/*    */   public void parseError(String msg) {
/* 33 */     JOptionPane.showMessageDialog(null, "Run Time Error: " + msg, "error", 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 38 */     return new Not();
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\expresion\operador\booleano\Not.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */