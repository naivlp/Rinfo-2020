/*    */ package arbol.expresion.operador.booleano;
/*    */ 
/*    */ import arbol.expresion.operador.Operador;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class And
/*    */   extends Operador
/*    */ {
/*    */   boolean c;
/*    */   
/*    */   public String resultado(String Op1, String Op2) {
/* 15 */     boolean a = "V".equals(Op1);
/* 16 */     boolean b = "V".equals(Op2);
/* 17 */     this.c = (a && b);
/* 18 */     return this.c ? "V" : "F";
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 23 */     return new And();
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\expresion\operador\booleano\And.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */