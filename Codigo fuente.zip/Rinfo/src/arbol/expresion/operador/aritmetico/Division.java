/*    */ package arbol.expresion.operador.aritmetico;
/*    */ 
/*    */ import arbol.expresion.operador.Operador;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Division
/*    */   extends Operador
/*    */ {
/*    */   int c;
/*    */   
/*    */   public String resultado(String Op1, String Op2) {
/* 15 */     int a = Integer.parseInt(Op1);
/* 16 */     int b = Integer.parseInt(Op2);
/* 17 */     this.c = a / b;
/* 18 */     return String.valueOf(this.c);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 23 */     return new Division();
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\expresion\operador\aritmetico\Division.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */