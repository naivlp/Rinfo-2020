/*    */ package arbol.expresion;
/*    */ 
/*    */ import arbol.AST;
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.Identificador;
/*    */ import arbol.Tipo;
/*    */ import form.Robot;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Expresion
/*    */   extends AST
/*    */ {
/*    */   public DeclaracionVariable DV;
/*    */   public Tipo T;
/*    */   public Identificador I;
/*    */   public Robot r;
/*    */   
/*    */   public DeclaracionVariable getDV() {
/* 21 */     return this.DV;
/*    */   }
/*    */   
/*    */   public void setDV(DeclaracionVariable DV) {
/* 25 */     this.DV = DV;
/*    */   }
/*    */   
/*    */   public Identificador getI() {
/* 29 */     return this.I;
/*    */   }
/*    */   
/*    */   public void setI(Identificador I) {
/* 33 */     this.I = I;
/*    */   }
/*    */   
/*    */   public boolean ejecutar() {
/* 37 */     return true;
/*    */   }
/*    */   
/*    */   public String getValue(DeclaracionVariable DV) throws Exception {
/* 41 */     return "undefinedd";
/*    */   }
/*    */   
/*    */   public Tipo getT() {
/* 45 */     return this.T;
/*    */   }
/*    */   
/*    */   public void setT(Tipo T) {
/* 49 */     this.T = T;
/*    */   }
/*    */   
/*    */   public Robot getRobot() {
/* 53 */     return this.r;
/*    */   }
/*    */   
/*    */   public void setRobot(Robot r) {
/* 57 */     this.r = r;
/*    */   }
/*    */   
/*    */   public abstract Object clone() throws CloneNotSupportedException;
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\expresion\Expresion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */