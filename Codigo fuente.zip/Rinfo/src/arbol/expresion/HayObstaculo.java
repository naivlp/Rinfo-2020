/*    */ package arbol.expresion;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.Tipo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HayObstaculo
/*    */   extends Expresion
/*    */ {
/*    */   public HayObstaculo() {
/* 13 */     setT(new Tipo((byte)20));
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue(DeclaracionVariable DV) throws Exception {
/* 18 */     int Av = getRobot().PosAv();
/* 19 */     int Ca = getRobot().PosCa();
/* 20 */     if (getRobot().getCity().HayObstaculoEnLaEsquina(Av, Ca)) {
/* 21 */       return "V";
/*    */     }
/* 23 */     return "F";
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 28 */     HayObstaculo obj = new HayObstaculo();
/* 29 */     return obj;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\expresion\HayObstaculo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */