/*    */ package arbol.expresion;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.Tipo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PosCa
/*    */   extends Expresion
/*    */ {
/*    */   public PosCa() {
/* 13 */     setT(new Tipo((byte)19));
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue(DeclaracionVariable DV) {
/* 18 */     return String.valueOf(getRobot().PosCa());
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 23 */     synchronized (this) {
/* 24 */       PosCa obj = new PosCa();
/* 25 */       obj.setT(new Tipo((byte)19));
/* 26 */       return obj;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\expresion\PosCa.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */