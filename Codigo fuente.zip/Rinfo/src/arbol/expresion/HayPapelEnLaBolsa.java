/*    */ package arbol.expresion;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.Tipo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HayPapelEnLaBolsa
/*    */   extends Expresion
/*    */ {
/*    */   public HayPapelEnLaBolsa() {
/* 13 */     setT(new Tipo((byte)20));
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue(DeclaracionVariable DV) {
/* 18 */     if (getRobot().HayPapelEnLaBolsa()) {
/* 19 */       return "V";
/*    */     }
/* 21 */     return "F";
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 26 */     return new HayPapelEnLaBolsa();
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\expresion\HayPapelEnLaBolsa.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */