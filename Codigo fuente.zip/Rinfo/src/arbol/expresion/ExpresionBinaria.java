/*    */ package arbol.expresion;
/*    */ 
/*    */ import arbol.DeclaracionVariable;
/*    */ import arbol.Programa;
/*    */ import arbol.expresion.operador.Operador;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExpresionBinaria
/*    */   extends Expresion
/*    */ {
/*    */   Expresion E1;
/*    */   Expresion E2;
/*    */   Operador O;
/*    */   
/*    */   public ExpresionBinaria(Operador O, Expresion E1, Expresion E2) {
/* 18 */     this.E1 = E1;
/* 19 */     this.E2 = E2;
/* 20 */     this.O = O;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue(DeclaracionVariable DV) throws Exception {
/* 25 */     synchronized (this) {
/* 26 */       this.E1.setRobot(getRobot());
/* 27 */       this.E2.setRobot(getRobot());
/* 28 */       String E1Value = this.E1.getValue(DV);
/* 29 */       String E2Value = this.E2.getValue(DV);
/* 30 */       String res = this.O.resultado(E1Value, E2Value);
/* 31 */       return res;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void setPrograma(Programa P) {
/* 37 */     this.programa = P;
/* 38 */     this.E1.setPrograma(P);
/* 39 */     this.E2.setPrograma(P);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 44 */     synchronized (this) {
/* 45 */       System.out.println("Entre al clone de expresion binaria");
/* 46 */       Expresion E3 = (Expresion)this.E1.clone();
/* 47 */       Expresion E4 = (Expresion)this.E2.clone();
/* 48 */       return new ExpresionBinaria(this.O, E3, E4);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\expresion\ExpresionBinaria.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */