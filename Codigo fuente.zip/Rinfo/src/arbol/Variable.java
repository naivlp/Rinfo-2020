/*     */ package arbol;
/*     */ 
/*     */ import arbol.expresion.Expresion;
/*     */ import form.Robot;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.JOptionPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Variable
/*     */   extends Expresion
/*     */ {
/*     */   private String value;
/*     */   private boolean editable;
/*     */   Robot rob;
/*     */   RobotAST r;
/*     */   private String nombreTipoRobot;
/*     */   DeclaracionRobots dr;
/*     */   
/*     */   public Variable(Identificador I, Tipo T, DeclaracionVariable var, DeclaracionRobots robAST, String nombreTipoRobot) throws Exception {
/*  24 */     synchronized (this) {
/*  25 */       this.dr = robAST;
/*  26 */       this.DV = var;
/*  27 */       setI(I);
/*  28 */       this.value = "Undefined";
/*  29 */       if (T == null) {
/*  30 */         if (var.EstaVariable(I.toString())) {
/*  31 */           Variable tmp = var.findByName(I.toString());
/*  32 */           setT(tmp.getT());
/*  33 */           if ((getT()).tipo == 19) {
/*  34 */             this.value = "00";
/*     */           }
/*  36 */           if ((getT()).tipo == 20) {
/*  37 */             this.value = "F";
/*     */           }
/*     */         } 
/*     */       } else {
/*     */         
/*  42 */         setT(T);
/*  43 */         if ((getT()).tipo == 19) {
/*  44 */           this.value = "00";
/*     */         }
/*  46 */         if ((getT()).tipo == 20) {
/*  47 */           this.value = "F";
/*     */         }
/*  49 */         if ((getT()).tipo == 66) {
/*  50 */           this.r = robAST.getRobot(nombreTipoRobot);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public RobotAST getR() {
/*  57 */     return this.r;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValue(DeclaracionVariable var) throws Exception {
/*  62 */     String res = "undefineD";
/*  63 */     if (var.EstaParametro(this.I.toString())) {
/*  64 */       Variable tmp = var.findByName(this.I.toString());
/*  65 */       res = tmp.getValor();
/*  66 */       return res;
/*     */     } 
/*  68 */     reportError("Variable " + getI().toString() + " no declarada");
/*  69 */     throw new Exception("Variable " + getI().toString() + " no declarada");
/*     */   }
/*     */   
/*     */   public String getValor() {
/*  73 */     return this.value;
/*     */   }
/*     */   
/*     */   public void setValue(String str) {
/*  77 */     this.value = str;
/*     */   }
/*     */   
/*     */   public boolean esEditable() {
/*  81 */     return this.editable;
/*     */   }
/*     */   
/*     */   public void setEditable(boolean bool) {
/*  85 */     this.editable = bool;
/*     */   }
/*     */ 
/*     */   
/*     */   public void reportError(String str) {
/*  90 */     JOptionPane.showMessageDialog(null, str, "ERROR", 0);
/*     */   }
/*     */   
/*     */   public boolean isCompatible(Variable tmp) {
/*  94 */     switch (tmp.getT().getTipo()) {
/*     */       case 19:
/*     */       case 23:
/*  97 */         return (getT().getTipo() == 23 || getT().getTipo() == 19);
/*     */       
/*     */       case 20:
/*     */       case 32:
/*     */       case 33:
/* 102 */         return (getT().getTipo() == 20 || getT().getTipo() == 32 || getT().getTipo() == 33);
/*     */     } 
/*     */     
/* 105 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTipoRobot(String nombreTipoRobot) {
/* 111 */     this.nombreTipoRobot = nombreTipoRobot;
/*     */   }
/*     */   
/*     */   public String getTipoRobot() {
/* 115 */     return this.nombreTipoRobot;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object clone() {
/* 120 */     synchronized (this) {
/* 121 */       Variable obj = null;
/*     */       try {
/* 123 */         obj = new Variable(this.I, this.T, this.DV, this.dr, null);
/* 124 */         obj.setValue(getValor());
/*     */       }
/* 126 */       catch (Exception ex) {
/* 127 */         System.out.println("error en el clone de Variable!");
/* 128 */         Logger.getLogger(Variable.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */       } 
/* 130 */       return obj;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\Variable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */