/*    */ package arbol;
/*    */ 
/*    */ import form.Token;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Tipo
/*    */   extends AST
/*    */ {
/*    */   public byte tipo;
/*    */   
/*    */   public Tipo(byte tipo) {
/* 14 */     this.tipo = tipo;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 19 */     return Token.spellings[this.tipo];
/*    */   }
/*    */   
/*    */   public byte getTipo() {
/* 23 */     return this.tipo;
/*    */   }
/*    */   
/*    */   public void setTipo(byte tipo) {
/* 27 */     this.tipo = tipo;
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\arbol\Tipo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */