/*    */ package random;
/*    */ 
/*    */ import java.awt.Dimension;
/*    */ import javax.swing.ImageIcon;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.JTabbedPane;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Ventana
/*    */   extends JPanel
/*    */ {
/*    */   public Ventana() {
/* 19 */     JPanel principal = new JPanel();
/* 20 */     JLabel label1 = new JLabel("Esto es el panel principal");
/* 21 */     principal.add(label1);
/* 22 */     JPanel avanzado = new JPanel();
/* 23 */     JLabel label2 = new JLabel("Esto es el panel azanzado");
/* 24 */     principal.add(label2);
/* 25 */     JPanel privado = new JPanel();
/* 26 */     JLabel label3 = new JLabel("Esto es el panel privado");
/* 27 */     principal.add(label3);
/* 28 */     JTabbedPane jTabbedPane = new JTabbedPane();
/* 29 */     ImageIcon icon = new ImageIcon("flor.png");
/* 30 */     principal.setPreferredSize(new Dimension(410, 500));
/* 31 */     jTabbedPane.addTab("Avanzado", icon, avanzado);
/* 32 */     jTabbedPane.addTab("Privado", icon, privado);
/* 33 */     add(jTabbedPane);
/* 34 */     jTabbedPane.setTabLayoutPolicy(1);
/*    */   }
/*    */   
/*    */   public static void Crear() {
/* 38 */     JFrame marco = new JFrame("Ejemploo solapass");
/* 39 */     marco.setDefaultCloseOperation(3);
/* 40 */     marco.add(new Ventana(), "Center");
/* 41 */     marco.pack();
/* 42 */     marco.setVisible(true);
/*    */   }
/*    */   
/*    */   public static void main(String[] args) {
/* 46 */     Crear();
/*    */   }
/*    */ }


/* Location:              C:\Users\Dani\Desktop\Rinfo-2020-master\R-info 3.0.jar!\random\Ventana.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */